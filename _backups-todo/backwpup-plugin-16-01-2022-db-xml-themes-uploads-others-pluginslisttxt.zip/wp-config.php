<?php
// Enable WP_DEBUG mode
define('WP_DEBUG', true ); // remember to comment me out!
define('WP_CACHE', true); // WP-Optimize Cache
/** Enable W3 Total Cache */
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'rahils-notepad-wp' );
/** MySQL database username */
define( 'DB_USER', 'wp_nuadk' );
/** MySQL database password */
define( 'DB_PASSWORD', '88X#ZBT1b0T5&5Ka' );
/** MySQL hostname */
define( 'DB_HOST', 'localhost:3306' );
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );
/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '/05@Ox3J]&/b3]4d_IW*2y!KKuc49Vl8PN~T730gd3|4Yqa1]1Q3_7gBg;5gNE-+');
define('SECURE_AUTH_KEY', 'sn#dQMaRfTJ#kYCsfzS48(gk02|Hf17WY243KM*q70AdLZ/htXc2#4x6~Y|;3|x2');
define('LOGGED_IN_KEY', 'EDN:ha&fl@T-8oT[2%~k)+I[F7aggEV+]82oN:/@r(QicL76YV970/7!4d@XF3Q;');
define('NONCE_KEY', ')b;N2Gk)hcs]E5dz;-#d4peT9P;Uj90o~/_/nJmEGlxu0Gn0RQ&4QJ9r)1)-sk1w');
define('AUTH_SALT', 'z#4*#i-VkQ1-:/%+x;!*8mhU5@]6wojo|71bi*h7he18Jr;3LN4|+M]U5-;6M83;');
define('SECURE_AUTH_SALT', '4[lN!Ll7mr(|Uz]7!5u[FJ;j[HE+VXc#d5!]67ZNkfL:l0&twvZR@3%TM4d8|:be');
define('LOGGED_IN_SALT', '7_3!nVw_AIpD:ll4&r88fgV9cik9&(CZ8YN9%6AKLe3~qy-55*9A2452d4H:*KmK');
define('NONCE_SALT', '~0*Q_8o7fvOaQsFfdcE|+c0B79ho2Ml;*)i*-GJJCz1539Cf7)LNvGQ|9u5kMjl+');
/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpgc_';
define('WP_ALLOW_MULTISITE', true);
define('WP_AUTO_UPDATE_CORE', 'minor');
/* That's all, stop editing! Happy publishing. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}
/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';