---
id: 2389
title: 'Banksy: Animated'
date: 2014-09-20T03:27:27-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2389
permalink: /banksy-animated/
categories:
  - New Media
  - New Media Design
---
It would be fun to animate Banksy's art, and have them interact with the public.
<div style="text-align: center;"><a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-rat.svg"><img class="alignnone size-large wp-image-2390" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-rat.svg" alt="banksy rat" /></a>
Maybe the rat does mischievous things when people come near.
&nbsp;
&nbsp;
&nbsp;
<a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/bankst-animated.svg"><img class="alignnone size-large wp-image-2391" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-thekla.svg" alt="banksy thekla" /></a>
Maybe the Thekla can paddle along the river.

</div>