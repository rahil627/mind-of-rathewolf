---
id: 2701
title: The Suburbs Still Fail
date: 2014-11-07T05:29:07-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2701
permalink: /the-suburbs-still-fail/
categories:
  - Thoughts
---
<blockquote>
10/2
People from the suburbs, like farms of any developed country, create knowledge from what's around. Even with the development of the internet, people still lack much knowledge.
</blockquote>

An interesting phenomenon.

Even in the Information Age, the suburbs are still far from a progressive lifestyle. It is surprising how little has changed before and after the internet.

Is it because the people have become accustomed to the society and lack action to change from it? What goes on in the mind of a person who lives in an older society when they experience media from a more modern one? What does America mean to an Indonesian? What does the city mean to a suburbanite? Just some distant society which has no affect on one's own?

The most interesting observation is that people prioritize reality over media. Few people get ideas from media or other societies. Instead, it's what they experience in the reality of daily life form which they derive most of their knowledge.

Is it prioritization of reality over media or a lack of will to take action toward a different society?

For the most of the world, sadly, I imagine is the lack of free time to even think about it. In the suburbs of America, this is not the case.

The suburbs are always a perplexing society.

<blockquote>~2/14/13 to 8/6/13 in San Francisco the second time:
People in the suburbs worry about silly things.</blockquote>

The suburbs are conducive to laziness. The free-time is ill-used.