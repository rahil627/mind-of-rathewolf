---
id: 2768
title: Hourly Ethics
date: 2014-11-08T04:40:20-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2768
permalink: /hourly-ethics/
categories:
  - Ethics
  - Philosophy
---
<blockquote>10/10/13
Prioritize time! Do as much as you can in one day, simultaneously thinking about art, life, and people. Live by the hour.</blockquote>

It's nice to think all of the time. But I think it's nice to at least think about what you are doing and it's result every hour.

This is really great for a liberal education where several disciplines are wanted, as it provides a gestalts. Life, film, non-fiction all come together. Knowledge is confirmed in several forms.

One is also simply less likely to fall into routine slave-like work.