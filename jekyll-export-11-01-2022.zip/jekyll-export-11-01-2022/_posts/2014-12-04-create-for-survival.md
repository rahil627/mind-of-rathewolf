---
id: 3704
title: Create for Survival
date: 2014-12-04T19:47:09-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3704
permalink: /create-for-survival/
categories:
  - Action
  - Ethics
  - Philosophy
---
The nature of an animal is to survive.

To survive, animals take actions to increase survival.

Act for survival.

After one is able to survive, discontentment arises.

To cure the discontent, humans create (or sometimes consumption, heavily exercises, or a negative passion -- war).

The nature of a human in the developed world is to create.

Create for survival of a complex mind.

[todo: needs more thought]