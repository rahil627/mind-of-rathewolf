---
id: 2435
title: A Light Performance
date: 2014-09-20T05:19:56-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2435
permalink: /a-light-performance/
categories:
  - New Media
  - New Media Design
---
<div style="text-align: center;">
<a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/World-Trade-Center-light-performance.svg"><img src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/World-Trade-Center-light-performance1.svg" alt="World Trade Center light performance" class="alignnone size-large wp-image-2436" /></a>
</div>

Possible title: Spotlight for a Suspect