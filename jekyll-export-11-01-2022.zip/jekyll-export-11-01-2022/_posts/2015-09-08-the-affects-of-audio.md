---
id: 4650
title: The Affects of Audio
date: 2015-09-08T14:56:55-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4650
permalink: /the-affects-of-audio/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:11:"c339ad5972e";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:61:"https://medium.com/@rahil627/the-affects-of-audio-c339ad5972e";}'
categories:
  - Humanities
  - Mind and Matter
  - Philosophy
  - Thoughts
---
Just writing a little bit about an ancient thought that I re-discovered:

The affects of audio are really important. I think the only way I was able to spend so much time on the computer in the past, as opposed to taking in all of sensory experience nature offers, is because of music. It has the ability to dull the mind into doing rote tasks. Music should almost always be avoided, except for times when the mind is thinking too much, too manic, and need to just calm down.

While outside:
none:
focused on reality
alert of reality

one ear:
alert of reality
listening intently on audio content, if it fits current interests

two ears isolated:
reality becomes film


While in front of a computer:
none:
alert of reality nearby
alert of outside world
question why I am on the computer as opposed to making an impact in the world
question why I am not thinking fast

one ear (maybe two ears non-isolated):
alert of reality nearby
alert of outside world

two ears isolated.
focused on things displayed on the computer