---
id: 3527
title: Consistent Play Ethics
date: 2014-11-28T19:13:24-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3527
permalink: /consistent-play-ethics/
categories:
  - Ethics
---
<blockquote>~2/14/13 to 8/6/13 in San Francisco the second time:
Play with visual in processing and open frameworks until I find something I like.

Play with sounds until I find something I like.

Really just have to do it. Like a child. Make noises. Play.

Play with things until your taste finds something you like and explore that more, turn it into a product so that the world can see what you see. A telescope from an explorer.</blockquote>

