---
id: 6353
title: Media and Action
date: 2016-04-15T22:45:45-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6353
permalink: /media-and-action/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"f109dc25df09";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:58:"https://medium.com/@rahil627/media-and-action-f109dc25df09";}'
categories:
  - Action
  - Art
  - Communication
  - Critical Theory
  - Films
  - Games
  - Humanities
  - Linguistics
  - Media
  - Metaphysics
  - Philosophy
  - Philosophy of Film
  - Philosophy of Game
  - Social Philosophy
---
From a thought today:
<blockquote>"...The second essay is about whether 'personal essays' ever cause action: has anyone acted upon an <em>Essai</em> by Montaigne[?], as people acted when Blow made <em>Braid</em>, or when Vertov made <em>Man with a Movie Camera</em>? Did the games and films made in response [to them] merely create more communication, as opposed to action? No [and Yes?]. It's the accessibility of the medium that increases the chance of acting in response. 'I read the news today' is a different experience from watching <em>Night and Fog</em>, and that itself different from what I imagine and hope the experience of playing <em>This War of Mine</em>. The closer the experience of a medium is to real experience, the greater the chance of acting in response."</blockquote>



