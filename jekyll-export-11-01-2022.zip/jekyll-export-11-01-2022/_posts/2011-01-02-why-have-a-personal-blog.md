---
id: 38
title: Why have a personal blog?
date: 2011-01-02T06:33:22-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=38
permalink: /why-have-a-personal-blog/
categories:
  - Art
  - Literature
  - Personal
---
I just needed to write. Anyone can write a book. Maybe there’s some skills involved, like fitting wordplay and rhymes into a song's harmony…I just had to make sure I can write.

I don’t know what my next career is, or what I’m going to do when I get to San Francisco, but it probably involves writing. I could be writing scripts, making critiques, or documenting source code. It’s a skill that needs improving, and lasts forever.

A friend once started blogging. He said the reason he started was so he could write. He blogged for the sake of writing. It doesn’t matter who read it. He wrote his thoughts, observations, and published it on the internet.

Maybe my INTJ personality is good at writing. I can’t draw but I sure can place my thoughts onto paper, placing forth my judgement and personal observations.

Ugh, but non-fiction is boring. I hope I can write something cool, like an Alan Moore script!