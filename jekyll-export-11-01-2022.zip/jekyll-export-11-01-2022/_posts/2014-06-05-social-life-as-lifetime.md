---
id: 2098
title: Social Life as Lifetime
date: 2014-06-05T20:19:50-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2098
permalink: /social-life-as-lifetime/
categories:
  - Philosophy
  - Thoughts
---
<blockquote>If one does something without others, does it count as living?
<cite><em>an undated thought</em></cite></blockquote>

<blockquote>Human beings are by nature political animals.
<cite>Aristotle, <em>Politics (Πολιτικά)</em></cite>
</blockquote>