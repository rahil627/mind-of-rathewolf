---
id: 259
title: Can You Imagine Yourself as a Verbal Assassin?
date: 2011-10-24T17:59:55-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=259
permalink: /can-you-imagine-yourself-as-a-verbal-assassin/
categories:
  - Game Development
  - Games
tags:
  - actionscript game
  - art game
  - Babycastles
  - expiremental game
  - flashpunk
  - game jam
  - horse ebooks
  - independent game
  - Metal Gear
  - Parsons
  - The New School
---
<a href="http://www.rahilpatel.com/verbal_assassin.html">Play the game</a>.

The title of the post is the theme I chose at my first game jam, <a href="https://www.facebook.com/event.php?eid=261046020606382">Castle Lab: Parsons x Babycastles</a>.

I've also written more about my about experiencing <a href="http://www.rahilpatel.com/blog/my-first-game-jam">my first game jam</a>.

EDIT: To reduce frustration, I added controls to repeat the last command. Subsequently, the game's length has been reduced to five seconds!