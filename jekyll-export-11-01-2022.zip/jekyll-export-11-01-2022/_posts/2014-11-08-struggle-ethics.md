---
id: 2824
title: Struggle Ethics
date: 2014-11-08T05:47:39-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2824
permalink: /struggle-ethics/
categories:
  - Ethics
---


<blockquote>>9/3/13
When I'm with people I want to have fun. When in alone I desire struggle. I seek how I feel at the moment.</blockquote>



<blockquote>9/24/13
A fascination for human struggle. The human condition. I live and work harder for it. I feed on it through films that depict struggle, or meeting people during my travels, living with the lower class, talking to other travelers, office workers, people on the street, to the point of despising anyone wealthier. The suburbs show no visible struggle, so I perform poorly as a result. Cities and less developed countries have struggle. Will I be productive in a more happy country such as Taiwan? Or will the safety of it bore me as suburbs do. I thought the freedom of Taiwan would be advantageous. Perhaps if I keep many social contact I will fight for time with people. Still, I think I need to live outside, on the street.</blockquote>

<blockquote>10/20/13
I can't concentrate anymore. I'm not fighting for life anymore. Taiwan is making me lazy. I need to stick to myself, my New York ambitious self.

I've lived such a good life in Taiwan I forgot what struggle is. The people who struggle.

Perhaps I need to struggle to create something grand again.</blockquote>

Constant struggle is key for artists, isn't it?

<blockquote>
10/21/13
Taipei is a happy place to be, but it makes it uninteresting.

Do not conform. Stay an outsider. Criticize society.</blockquote>

When society has a high average visible happiness, does that correlate to a low average amount of artists?