---
id: 6134
title: Reality as Proof
date: 2016-01-08T08:46:05-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6134
permalink: /reality-as-proof/
categories:
  - Personal
  - Thoughts
---
<blockquote>no need to argue, the proof is reality*</blockquote>

