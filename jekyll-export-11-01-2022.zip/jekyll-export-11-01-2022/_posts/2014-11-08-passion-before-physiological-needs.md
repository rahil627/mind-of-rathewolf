---
id: 2810
title: Passion before Physiological Needs
date: 2014-11-08T05:37:45-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2810
permalink: /passion-before-physiological-needs/
categories:
  - Health
  - Philosophy
---
<blockquote>
~2/14/13 to 8/6/13 in San Francisco the second time:
The most important thing is having  a project to be passionate about. Then everything else, exercise, diet, social become secondary.</blockquote>

<blockquote>10/15/13
Why the recent laziness? Why am I not consuming as much? Need air conditioning? I didn't before! Pure motivation. Be more timely.</blockquote>

Proven many times by every dramatic film.