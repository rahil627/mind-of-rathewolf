---
id: 4882
title: 'Winter&#8217;s Bone'
date: 2015-10-04T19:36:22-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4882
permalink: /winters-bone/
categories:
  - Art
  - Film Reviews
  - Films
---
[todo: need to review thoughts]

Thoughts during a viewing of Winter’s Bone:

Their school is not much different from my own: army training classes (ROTC, whatever that acronym was for), teaching young female students how to carry a child, general guidance in life. I didn’t touch any of that.

The mother has to take care of kids, a dog, and a horse. She must wash clothes, cut wood, comb her mother’s hair (optional). This is life without technology. Not enough free time or simultaneous time to consume media.

Law as major problem. How can the law allow the father to put the house on bail. Does the police not care for people?

~”Never ask to what ought to be offered.” This is a moral the mother teaches to her son, even in the face of hunger. I don’t believe it. Technology should be shared, along with food and housing.
Temporarily gave horse to neighbor for care because low on money. Neighbor offers to take care and allows to use technology to chop wood more efficiently. Food is low too. Difficult to survive.
Must teach kids how to survive. This community is barely surviving, in the most developed nation. These kinds of places actually exist in Suffolk, Virginia.

Asks to come in to friend’s house.

Actually, that was normal in College Park too. Though, on film, it seems so unnatural, unsocial.

Even the mother must ask her husband to use “his” truck, to help her friend by giving a ride. Hmm, maybe she asks to come in because the father owns the house. Well, the father’s parents gave it to them. So much property non-sharing already.

It really is the survival of the fittest, as opposed to communism.
Mmm indeed gender difference in marriage.

Uncle has a gun. Went to army? Treats humans like animals without feelings.

Can’t escape to city? This community is barely surviving. No media about cities? Or any better place for living?

Men settle “business” while women stay at home. Feels like such an ancient society, like that Kurosawa film Dodeskaden, yet it exists.

Blood. The big man.

Skinning and gutting a squirrel is indeed weird to a new person, unnatural.

Gossip as belief of who has power? Or gossip as fear from law?
—

I stopped writing perhaps before buildup of climax. Not so much because it was somewhat socially realistic and thrilling, but because it contained many elements of a thriller narrative and tropes, such as a good uncle that acts bad uncle (think Professor Snape), a badass gang with a gang leader, and so on. Yet it somehow mixed in quite an unfamiliar setting in the Ozarks of the U.S, making it feel quite real. I guess I’m not ready for narratives, and rather stick to film essays.
--

A quick Google search brings <a href="https://www.facebook.com/notes/matt-decker/10-things-winters-bone-got-completely-wrong-about-the-ozarks/10150625789986771">a Facebook post of an Ozark resident listing many differences from reality</a>. In neorealism, is it more important to depict reality or use a film formula to ensure smooth viewing?