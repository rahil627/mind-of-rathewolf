---
id: 2798
title: Simultaneous Ethics
date: 2014-11-08T05:23:56-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2798
permalink: /simultaneous-ethics/
categories:
  - Ethics
---
<blockquote>10/13/13
Work and create, be social, travel. Do it all simultaneously. You need some routine.</blockquote>

The goal is to do everything all of the time: create, socialize, and consume.

When one focuses on one, the others starve.

Technology helps greatly here.