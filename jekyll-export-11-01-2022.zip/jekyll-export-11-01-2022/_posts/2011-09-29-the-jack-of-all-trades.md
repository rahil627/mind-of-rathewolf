---
id: 173
title: The Jack of all Trades
date: 2011-09-29T02:36:00-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=173
permalink: /the-jack-of-all-trades/
categories:
  - Game Development
  - Games
tags:
  - actionscript
  - actionscript video game
  - capitalism
  - experimental gameplay
  - experimental gameplay project
  - finding yourself
  - flash
  - flash video game
  - independent game development
  - independent video game
---
<a href="http://www.rahilpatel.com/the_jack_of_all_trades.html">Play the game</a>.

This game is my submission for the Experimental Gameplay Project. The theme is <a href = http://experimentalgameplay.com/blog/2011/09/story-game-in-september-2011/>story game.</a>

It is the first game I've ever created. It took most of the 7 unemployed days to complete. I did not use a game engine, hence the prevalence of bugs. I learned and used ActionScript. Special thanks to the developers of <a href = http://www.flashdevelop.org/wikidocs/index.php?title=Main_Page>FlashDevelop</a>. Without it, I would have given up.

The game involves thoughts and experiences I've gone through recently. Mostly about finding yourself in a capitalist world. Although looking at the end product, the story seems like an overdone trope, something that belongs to the cheap clones theme. Still, I hope it resonates something within the player.

Hint: Look for your heart, not the golden trophy. (although I shouldn't have to give a hint, I feel my level design is bad)

EDIT: ...And the <a href="http://experimentalgameplay.com/blog/2011/09/story-game-roundup/">results</a> are in!