---
id: 3228
title: The Most Powerful Forms of Art
date: 2014-11-25T04:48:05-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3228
permalink: /the-most-powerful-forms-of-art/
categories:
  - Aesthetics
  - Art
  - Thoughts
---
The characteristics are:
One that contains knowledge
One that directly affects humans via physical interaction.
One that is social
One that is beautiful

These are also forms of pleasure.

Physical interaction can be satisfied without manmade objects; The sublimity of nature is enough. So is eating and exercise.

In another view:
One that affects the mind, and
One that affects the body

The potency of art depends on the potency of the characteristics of the art and the audience. A more sensual art more strongly affects a more sensual person. A more mindful art more strongly affects a more rational person more. Beautiful and social arts affects everyone.

The more potent, the greater chance of reacting to it.

If social, potency, and therefore chance of reacting, is multiplied.

Hmm, is a social experience the end?

Or the beginning of another?
--

Also see <a href="http://www.rahilpatel.com/blog/street-artists-are-powerful" title="Street Artists are Powerful">Street Artists are Powerful</a>.
--

<blockquote>Size of media matters. Big screens. Planetarium. Art at d-structure.</blockquote>

The scale of art is a powerful sensual effect