---
id: 3194
title: The Sublime
date: 2014-11-23T15:08:54-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3194
permalink: /the-sublime/
categories:
  - Thoughts
  - Travel
---


<blockquote>
8/2/14
The tourism of Taiwan is beautiful. It's built around the nature of it. Roads follow rivers through mountains, shops exist beside places where the earth was shaped in amazing ways. They hire architects from other countries to lead projects. How could I have lived in cities, spend time in front of screens, for so long?</blockquote>

