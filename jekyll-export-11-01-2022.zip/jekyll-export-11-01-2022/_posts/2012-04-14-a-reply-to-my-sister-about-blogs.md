---
id: 2015
title: A Reply to My Sister About Blogs
date: 2012-04-14T11:43:46-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2015
permalink: /a-reply-to-my-sister-about-blogs/
categories:
  - Conversation
---
<blockquote>Hah, you're way more excited about this then I am. I'm still not interested.

My gripe about blogs is that I find 99% of them useless, including my own. I've never followed a blog, I've only stumbled upon specific well-written posts by people that I admire. If "how to hold a hamburger properly" was chosen to be "freshly pressed" then I deem Wordpress's standards for content is low, aiming for popularity instead of quality. I don't seek popularity; I only care for those few people who actually searched specifically for something I wrote.

Again, blogging is my lowest priority. Before I can write anything, I have to create/do something first.
<cite>[same as publishing date? (14/4/2012)]</cite>
</blockquote>