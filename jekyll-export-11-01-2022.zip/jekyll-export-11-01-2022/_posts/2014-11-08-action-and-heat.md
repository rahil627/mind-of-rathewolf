---
id: 2527
title: Action and Heat
date: 2014-11-08T04:45:53-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2527
permalink: /action-and-heat/
categories:
  - Action
  - Philosophy
---
<blockquote>10/10/13
I'm alone again, wondering the city. It's hot, I overeat...</blockquote>

<blockquote>10/10/13
I think it was simply the heat that drove me insane. I need to stay focused, even in the heat. Buy a cheap cap. Find my safari hat. Take water. Avoid eating.</blockquote>

Heat is a sensual experience, and it causes one to do things. For one, to get something cold to drink or drink for homeostasis.

Further, it sure does feel that heat causes action, maybe even a bit more instinctual.

Some historians say that climate matters, scientists say it doesn't. Broadly thinking, Africa compared to Europe.

I think the heat combined with the city has some detrimental effects.

<blockquote>10/14/13
You've become so lazy. Sit in air conditioner. The heat is destroying you. Take a lighter backpack.</blockquote>

I believe in this thought, I meant lazy in not doing work toward current direction, that the heat was driving me to do other things.

[posting as stub, thoughts may be appended later]

<blockquote>~7/12 sometime in India:
The effects of heat: stop from working, difficult breathing, loss of appetite.</blockquote>

[posting as stub, thoughts may be appended later]