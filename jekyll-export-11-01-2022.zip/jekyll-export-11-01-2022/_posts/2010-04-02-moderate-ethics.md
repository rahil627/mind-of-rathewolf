---
id: 6520
title: 'Moderate Ethics [Early Ethics]'
date: 2010-04-02T09:30:46-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6520
permalink: /moderate-ethics/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"d835c5bc1d64";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:57:"https://medium.com/@rahil627/moderate-ethics-d835c5bc1d64";}'
categories:
  - Ethics
  - Humanities
  - Philosophy
---
<blockquote>be moderate about everything [recurring thought]
<cite>4/2/2010 (dd/mm/yyyy)</cite></blockquote>
Perhaps the <a href="https://en.m.wikipedia.org/wiki/Golden_mean">Golden Mean</a> was an early ethical stance of mine.


<blockquote>It's peculiar that people who live a high tech busy life, may aspire to live a rural slow life, and vice versa. maybe lifestyles too should be taken in moderation. for 20 years you can live in the a developed city, then for another 20 years live on a farm. It doesn't have to be a consecutive 20 years, vacations count.

Vacations were created to balance out work and rest. Everything should be taken in moderation.
<cite>6/3/2010</cite></blockquote>