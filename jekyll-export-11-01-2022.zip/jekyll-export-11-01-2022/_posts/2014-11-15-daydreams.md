---
id: 2660
title: Daydreams
date: 2014-11-15T10:16:23-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2660
permalink: /daydreams/
categories:
  - Psychology
---
<blockquote>At home before leaving America:
Perhaps daydreaming is what the mind does when it is not occupied, not motivated.</blockquote>

Seems to occur after experiencing life (whether real or media) and then placing oneself in a lifeless area. As if there is no outlet for creativity (dialog, sense-data), so it comes out as a dream.

Sensory deprivation experiments agree.