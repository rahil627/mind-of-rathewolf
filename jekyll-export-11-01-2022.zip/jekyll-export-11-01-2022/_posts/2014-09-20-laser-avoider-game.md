---
id: 2425
title: Laser Avoider Game
date: 2014-09-20T02:41:28-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2425
permalink: /laser-avoider-game/
categories:
  - Game Design
  - Games
  - New Media
  - New Media Design
---
There should be games with moving lasers [pointers]. Dodging in real life would be so fun!

<div style="text-align: center;"><a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/laser-dodging-game.svg"><img class="alignnone size-large wp-image-2426" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/laser-dodging-game.svg" alt="laser dodging game" /></a></div>

Further designs:
Can use mirrors!