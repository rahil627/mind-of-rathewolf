---
id: 2421
title: Prince of Parkour
date: 2014-09-20T04:10:51-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2421
permalink: /prince-of-parkour/
categories:
  - New Media
  - New Media Design
---
There should be interactive projector games, where people move projectors, and in which the images animate according to its surroundings.

In this game, characters can walk, run, and climb along the walls of buildings.
<div style="text-align: center;"><a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/prince-of-parkour.svg"><img class="alignnone size-large wp-image-2422" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/prince-of-parkour.svg" alt="prince of parkour" /></a></div>