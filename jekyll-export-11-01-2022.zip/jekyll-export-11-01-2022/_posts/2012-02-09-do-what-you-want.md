---
id: 6697
title: Do What You Want
date: 2012-02-09T09:06:10-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6697
permalink: /do-what-you-want/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:11:"d5f87c3f110";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:57:"https://medium.com/@rahil627/do-what-you-want-d5f87c3f110";}'
categories:
  - Ethics
  - Humanities
  - Philosophy
---
<blockquote>The trait I cherish most about Ivar: he does what he wants to, without any external influences.
<cite>'thoughts from iPhone possibly older than 2-9-12.txt'</cite>
</blockquote>
