---
id: 6539
title: Early Life Trajectories
date: 2011-09-28T09:30:34-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6539
permalink: /early-life-trajectories/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"8dfa704d0770";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:65:"https://medium.com/@rahil627/early-life-trajectories-8dfa704d0770";}'
categories:
  - Art
  - Humanities
  - Life
  - Personal
  - Thoughts
---
<blockquote>Art is not a job, it's a personal urge.

A solution for an artist living in a capitalist country: Work for a short-term high-income contract, then live simply and work on art for a long period of time.
<cite>28/9/2011</cite></blockquote>
</blockquote>

