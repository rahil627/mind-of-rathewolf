---
id: 1401
title: Copie conforme (Certified Copy)
date: 2013-12-30T12:08:35-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=1401
permalink: /copie-conforme/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"221a2160bbce";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";s:71:"https://medium.com/@rahil627/copie-conforme-certified-copy-221a2160bbce";}'
categories:
  - Film Reviews
  - Films
---
After feeling a bit woozy watching great modern films by Asian directors Kim Ki Duk, Tsai Ming Liang, and Hou Xiao Xian, I was quite glad to watch Copie conforme (Certified Copy). A film with a normal thrill curve. A guilty pleasure. Perhaps the best of it's kind.

The film is flawless. Like the director's last film A Separation (edit: This is wrong. That film turns out to be by Asghar Farhadi, another amazing Iranian director. The films are so similar! I assumed.), it focuses on a relationship in a single day. Again, very screenplay-heavy, the camera keeping the couple in the shot, shot naturally requiring less cinematography and more acting. The film plays like a ride with seemingly extremely few cuts; It's straightforward. It feels as if there's nothing to analyze.

But I'll try, a little.

The screenplay requires the actors to be top-notch to endure long takes, maintain realism, and especially to keep the film entirely ambiguous.

The film feels quite universal, containing very familiar characters and events. I consider myself schizoid with characteristics very close to the male: I'm cold, use rationality over emotions, and have narrow interests.  Not all males are as cold as me or the male in the film, but I bet many people can identify with many of either one of the character's characteristics. Moreover, I bet people know someone very much like the two characters shown.

Certainly there are some slightly unbelievable things such as the symbolism of art in the film and the strangers met giving advice, one to the male, one to the female, making the screenplay perfect for what occurs in a single day, just as A Separation did. However, it didn't bother me. I was enthralled.

I only wish Karaistami continues to show me a day in the life of a relationship, or any person.