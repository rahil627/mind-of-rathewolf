---
id: 2485
title: Sight before Language
date: 2014-11-08T04:35:59-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2485
permalink: /sight-before-language/
categories:
  - Epistemology
  - Mind and Matter
  - Philosophy
  - Thoughts
---
<blockquote>10/9/13
Kim Ki Duk's films barely have any words. Language is unnecessary.</blockquote>

In the gaining of knowledge, I believe verbal language is inferior to visual. One is visually aware once as a baby opens their eyes, knowledge pours through, ideas are conveyed instantly, faster than language ever could have. Verbal language comes much later. 

I think this is the reason my personal history went as so: biking, playing video games, watching films (supplemented with Wikipedia) in college, then living and working in cities, and later, abroad, then finally listening to audiobooks.

[Stopping here. I imagine more thoughts will lead me here again.]

