---
id: 2898
title: Experience and Action
date: 2014-11-09T04:45:57-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2898
permalink: /experience-and-action/
categories:
  - Action
  - Philosophy
  - Social Philosophy
---
from an <a href="http://www.rahilpatel.com/blog/households-and-inaction">old thought about households and inaction</a>:
<blockquote>Though with technology one can talk which may result in fruitful actions, it is less likely than physically being together.</blockquote>

Why is the physical presence of people a stronger incentive to action than media?

This thought comes close to thoughts about public spaces and DIY spaces.

[todo: come back!]