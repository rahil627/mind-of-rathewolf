---
id: 2784
title: Maximize Social Time Ethics
date: 2014-11-08T05:06:32-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2784
permalink: /social-ethics/
categories:
  - Ethics
  - Social Philosophy
---
<blockquote>10/10/13
I hate doing anything alone.
...
I think with a cafe job I would be more calm, happy. Live more, worry less.

I don't want to be alone again. Keep talking to people!

Still haven't learned how to live and work simultaneously.</blockquote>





<blockquote>10/12
A hostel or NGO would be fun. It's closer to life than new media, and involves interaction with people.</blockquote>





<blockquote>10/15
Keep meeting people. Keep talking. Keep staying in social spaces, or outside.

I can't stand being inside a room anymore. I must stay outside, day and night. Sleep outside, somewhere, in the public, with people.

I can't spend time alone. At least, not on a computer, or not after a long day of living.

You must stay social. Otherwise the day is wasted. Keep talking to people.

I must find a way to keep life exciting!

I've lost interest in the world. I don't want to even get out of bed. I need to be more social. I need more work. I need to keep doing things.

Another day wasted. Failed to be social. Failed to be excited about traveling. Poop.</blockquote>





In Taiwan, I came to a point where I didn't want to do anything alone. Social determinism at max effect?

Sure, I had choice of the people, what to talk about, and what to do, but that made everything limited to mutual interests.

I was happy as long as I was social. It was as simple as that.