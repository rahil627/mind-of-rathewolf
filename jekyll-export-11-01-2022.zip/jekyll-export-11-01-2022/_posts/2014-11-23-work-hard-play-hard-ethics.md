---
id: 3169
title: Work Hard Play Hard Ethics
date: 2014-11-23T02:30:15-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3169
permalink: /work-hard-play-hard-ethics/
categories:
  - Ethics
---
<blockquote>Hong Kong at midnight, first night:
Young Chinese professional kids are ending their nights with food. Work hard, play hard. Fashionable clothing. Night shift workers. New York atmosphere. Less dirty, same personalities. I don't want any part of it.</blockquote>

Not good.