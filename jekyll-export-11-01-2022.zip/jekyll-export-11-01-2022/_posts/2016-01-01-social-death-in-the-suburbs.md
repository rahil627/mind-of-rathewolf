---
id: 3883
title: Social Death in the Suburbs
date: 2016-01-01T04:53:28-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3883
permalink: /social-death-in-the-suburbs/
categories:
  - Personal
  - Thoughts
---
[I think this was written directly to the blog, not from my thoughts file, perhaps written soon after coming home, in the suburbs]

<blockquote>"He who is unable to live in society, or who has no need because he is sufficient for himself, must be either a beast or a god." - Aristotle</blockquote>
Or socially die.

<blockquote>"That to study philosophy is nothing but to prepare one's self to die." - Cicero</blockquote>
When a person is socially detached from nuclear family and institutions in a suburban or similar environment, the person has no other society to be part of.

The city is a society, which may be viewed as the form of a institution or family.