---
id: 2999
title: Everything I Own
date: 2014-11-19T23:46:55-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2999
permalink: /everything-i-own/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"74e8afc9789d";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:58:"https://medium.com/@rahil627/everything-i-own-74e8afc9789d";}'
categories:
  - Travel
---
Not including: furniture (my Dad bought them), house supplies (I bought a lot of junk, but it seems to slowly gets put to use in the house), media (discovered Voice Dream and pirate eBook library too late), some clothes that fit well, and things that will be rid of soon.

Estimate: 80 things.
Goal: 50. Poop.

<blockquote>Buy a stereo system. It's worth it. If not, high quality headphones. Zack's stereo system and my stereo system at home make a much larger impression for me. Ship my stereo system to SF?</blockquote>

EVERYTHING THAT I OWN:
“big 3” and more:
backpack - HyperLite 3400 (contenders: Exos 58, Z Packs Arc Blast)
sleeping bag / quilt - enlightened equipment’s Revelation (tears too easily! Already have two pieces of electrical tape repairs on it), it's also kind of made to be used with a slepeing pad, because it's doesn't fully wrap around the body, which makes the mummy function quite silly for people who sleep on their side.
  - could try to upgrade to Convert with straps
  - comes with stuff sack
tent - Tarptent Double Rainbow (carbon fiber pole, no liner)
  - comes with stakes and guy lines and stuff sacks
daypack - HIKPRO 20L/6.5oz (contenders: one from z packs vs sea to summit silnylon modded with foam pads)

travel and survival:
sleeping pad - Therm-A-Rest NeoAir Xlite (Regular) - can double as backpack padding
silk liner - Cacoon Silk MummyLiner (eBayed it), though I should have bought Cacoon TravelSheet
groundsheet - (plycro, tvvek, etc.) - tyvek, don’t need if the tent has a bathtub floor, but can use at any time like a picnic sheet (can be ordered from the people who sell z packs)
ultralight pillow - Exped Air Pillow Medium, Lewis N. Clark travel pillow (lost, the microfiber made it far more comfortable than my current pillow)
p/spork - TOAKS Titanium Spork vs Snow Peak Titanium Spork vs Sea to Summit Alpha Light Utensils (.3oz)
p/compass (with tiny ruler) - Suunto A-10 Compass
*lost the water pack/water filter - Sawyer mini (includes water pack)
water bottle -  Nalgene On The Fly Water Bottle
*lost/secondary water pack - Platypus PlusBottle 1L
*lost (oh no! After so many years too.)/flashlight - fenix LD01

firestarter kit*:
Light My Fire Swedish FireSteel 2.0 Scout 3,000 Strike Fire Starter
x/stormproof matches - check walmart?
zip lock bag
—
first aid kit:
kit - First Aid, by Total Resources International (Walmart)
sticky gauze roll
zip lock bag
—

film equipment:
camcorder - Panasonic v750
mic - zoom h4n
shotgun mic -  Rode VideoMic Pro
lava mic - cheap AT somethings
various cables

*storage/monopod - Manfrotto monopod compact new series advanced (MMCOMPACTADV-BK) - .75lb, 6lb load
  - doubles as boom mic. Can replace with hiking poles with screws in them.
video head - none
x/tiny(?) video gorilla pod

electronics:
travel and surge protector -  REI OREI M8 and some extra fuses
laptop - Macbook Pro (mid-2010 -> late 2013) with SSD
smartphone - iPhone (4 (robbed by taxi driver in Bangkok) -> 5)
*yeah, kinda useless/?/tablet / eReader - iPad Mini - useless? Isn’t it enough to read / listen from an iPhone?
*requires small repair and lost/in ear head phones - Custom Art Music One (need to repair wire), VSonic VC1000 (tiny, great, but lost), RBH EP-2 (returned! not sure if I tested it or not)
x/travel speaker - UE (Ultimate Ears) Mini Boom (returned, put the money into custom in-ear headphones, though after much travel with in-ears, it sure would be nice to have a portable speaker)
external hard drive enclosures (and docks) - usb to SATA cable, blacX (if one isn’t traveling much), MiniPro or G-Technology Mini or Portable for firewire / usb 3 or Akitio neutrino u3+ (all three look identical, except portable)
mp3 player - sansa clip, PAC's SNI-1/3.5 preamp noise filter from crutchfield
*buy another/flash drive - Patriot XT (gave to Dad?), SanDisk Extreme USB 3.0 (uncle borrowed and never returned after I asked several times)
*/usb battery and charger- Intocircuit Power Castle 11200mAh (lost one? still have one more?)

hygiene:
electric toothbrush - oral-b braun 7400 [10oz]
[toiletries 13oz]
toothbrush - Nimbus Microfine toothbrush Regular
floss
toilet paper
hair brush - from old airport kit
razor/grooming kit - Wahl Travel Trimmer
deodarant - 3oz Crystal Body
soap - Dr. Bronner's Organic Castile Liquid Soap Almond 4 oz
  - also bought a soap cover

repair kit:
multitool - Leatherman squirt p4, Leatherman Style CS, Leatherman Skeletool CX + Bit Kit + Bit Driver Extension [10oz!?]
duct tape
sewing kit - Dritz sewing kit (Walmart)
zip tie

other tools:
paracord
travel laundry clothesline - flexo-line

supplies:
batteries
travel battery charger - Sanyo Eneloop travel charger
laundry bag / reusable bag - Outdoor Products stuff sack (Walmart)
pencil - papermate visibility, Pentel Sharp Kerry, dad's
ear plugs - Hearos Ultimate Softness

clothes:
wallet - Slimmy Original, next time should make one out of a tyvek mail envelope!
*lost one, need to call that train station/barefoot shoes - vibram KSO EVO, (KSO allows water to permeate from the bottom so that even stepping in a puddle defeats it transforming it into a smelly mess. Future alternatives: vibram KSO, vibram Treksport, new balance minimus 10v2, )
travel towel - one from local outdoors shop, *lost at home?/Eagle Creek travel towel (large)
swimming trunks
5 polyester shorts
1 polyester long sleeve
2 thermals
3 light cotton shirts
1 thin material indian clothes (kurta-paijama / churidars)
? underwear
5 light cotton underwear
winter jacket
rain jacket

*storage/1 cotton shorts
*storage/1 light pants
  - should ask Mom to send the girly tight pair
*storage/1 normal cotton graphic t-shirts
*storage/2 cotton indian clothes (kurta-paijama / churidars)
*storage/toe socks

maybe:
mouse - logitech mx518 (todo: should gift to the CouchSurfer in XiZhi), microsoft OEM
*forgot/mousepad - steel series qck mini mouse pad, NOT xtracpads pro
x/drawing tablet - wacom bamboo

removed from bag:
x/sink stopper - Magellen's flexible sink stopper
daypack - Targus Groove cvr600 (used since high school, but replaced it in Nepal, trashing it because I had used duck tape on the bottom), some awesome one from Nepal, HIKPRO 20L (6.5oz)
backpack raincover - Outdoor Products backpack raincover (Walmart)
  - replace with garbage bag?

want but no money:
jacket - outdoorsgearslab shows amazing 8oz jackets!
hiking poles - Black Diamond Ultra Distance - sounds good for elevation changes and random debauchery, but otherwise I don’t feel I’d use it much

bag weight:

camping equipment:
540g sleeping bag
~1100g tent
~450-1000g backpack
340g sleeping pad
--
2430-2980g

toiletries:
10oz electric brush
13oz toiletries
? soap
10oz multitool
4oz few[?] cables
0oz sewing kit
4oz first aid kit
external drive 1
external drive 2
surge protector

computer equipment:
2040g laptop charger
112g iphone
331g tablet
600g battery usb
230g speaker

film equipment:
600g camcorder
150g cable hdmi
*700g z4n + 300g charger
300g mic shotgun
350g lava mics
*650g monopod
--
3250g

clothes:
540g polyester shorts x3 + polyester swimming shorts
480g lightweight cotton shorts x1
270g light grey pants [stored]
360g thermal pants x2
430g lightweight graphic t-shirts x2-3
540g indian clothes x3
180g raincoat vs 430g rain jacket
winter jacket
winter pants

30.5lb
- externals
- jacket
- umbrella (random model that I stole, small, button open / collapse function)
- bottles
- more
- underwear
- deodarant
- camera
--
35lb