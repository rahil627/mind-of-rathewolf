---
id: 2985
title: Cash Crannies
date: 2014-11-25T07:53:36-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2985
permalink: /cash-crannies/
categories:
  - Thoughts
---
<blockquote>
9/16
Perhaps an efficient way to make money is to stumble upon niches in life. Some may not even require a specific skill. Examples: Indian wedding photographer, writer of graduate admissions for Chinese students, English tutor for rich foreigners.</blockquote>


