---
id: 6567
title: Cities as the Ideal Environment for Artists
date: 2012-08-10T10:03:29-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6567
permalink: /cities-as-the-ideal-environment-for-artists/
categories:
  - Art
  - Humanities
  - Personal
  - Thoughts
---
<blockquote>Cities contain artists and the means of creating art.
<cite>10/8/2012</cite>
</blockquote>