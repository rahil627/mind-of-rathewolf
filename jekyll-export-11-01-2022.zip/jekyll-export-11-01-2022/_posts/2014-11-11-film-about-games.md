---
id: 2965
title: Film about Games
date: 2014-11-11T07:18:22-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2965
permalink: /film-about-games/
categories:
  - Film Ideas
  - Films
---
I had a thought about making films about games.

The first short film had the theme that games leads to actions more so than books. It had two classmates from New York, one Chinese, one Hispanic. The Chinese one more book'ish, the Hispanic less. It shows the life of each. Then, there is an incedent they both pass individually. The Hispanic kid acts upon it quite intelligently, using the nearby city to his advantage. The Chinese ignores it.

I presented it to a local New York venue. I told them that perhaps I created them, and not games, because I grew up in the suburbs on film. That was my primary education. And somehow, I was stuck in the past.

I showed them another film, the draft of one, to test. The film was about also about games. It showed how ideas were transmitted through experience of playing games. In the end of the film, the film reached the limits of it's medium in transmitting ideas. The end had a frame that displayed press start to continue playing.