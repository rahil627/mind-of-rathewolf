---
id: 3766
title: Chaos and Organization
date: 2014-12-13T15:19:31-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3766
permalink: /chaos-and-organization/
categories:
  - Ethics
---
Open spaces provide chaos.

Closed spaces provide organization.

The mind is an organizing machine.

Change between open and closed spaces balance chaos and organization.

Travel provides chaos.

Houses provide organization.

Cities provide flux.
--

It seems the goal of academia is to organize information into words, artists organize information into art forms, urban planners into organize materials into cities. When will we just embrace chaos and live in anarchy one day at a time?
--

Media can provide chaos too. It is up to the mind to organize it.

I've said that <a href="http://www.rahilpatel.com/blog/information-organization-mediums-creativity-and-experience" title="Information Organization, Mediums, Creativity, and Experience">the more divergent the data of the unknown product, yet still maintaining an idea the better the aesthetic.</a>

I've been reading books lately, so Calvino comes to mind.

The power of poetry (or poetic prose) is in it's conciseness -- it is able to convey an idea with a few words.

A power often associated with conciseness is the ability to redirect the user to another idea. To continually do this is a kind of flux.