---
id: 6136
title: No Todo List Ethics
date: 2016-01-08T09:12:04-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6136
permalink: /no-todo-list-ethics/
categories:
  - Ethics
  - Humanities
  - Personal
  - Philosophy
  - Thoughts
---
<blockquote>no todo list ethics</blockquote>

