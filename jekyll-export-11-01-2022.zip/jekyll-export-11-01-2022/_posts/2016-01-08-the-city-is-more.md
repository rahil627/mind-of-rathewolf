---
id: 6122
title: The City is More
date: 2016-01-08T10:35:12-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6122
permalink: /the-city-is-more/
categories:
  - Uncategorized
---
<blockquote>Neighborhood in City: Adds more complex[?] community, more political* (decision-making at a higher level), larger problems, more complex problems, more distraction, more diversity? (not really, for Taiwan), more shared economy, more people (can use media), more social? (more shallow?), less materially creative. - a thought during my three months in Taipei</blockquote>