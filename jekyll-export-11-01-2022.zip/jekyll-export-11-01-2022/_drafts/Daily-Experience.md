---
id: 3757
title: Daily Experience
date: 2014-12-15T04:00:40-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3757
permalink: /?p=3757
categories:
  - Uncategorized
---
<blockquote>Morning depression. It occurs when one does not get out of the house in the morning. Most people walk, jog, exercise, commute. I like to explore. Without satisfying this psychological need, one can become depressed, especially when living alone. Over-think what t odo or where to go. One should just go, get out of the house. Cities are nice as one does not have to walk far to encounter people [an experience]. Asia works well too, with its scooters. The suburbs can be troublesome, as there are few public spaces to go to.

As soon as I went outside the house, into the the light, I felt better. Light is important.

Local projects.

Today I wasted away. Not enough local interaction. The problem of being a lone independent gamer emerges: I crumb when I am working alone. It is the same problem encountered when Jon was here. We were deprived of friends. So we abounded the game idea and created a game workshop.

I do not think today was a waste. It’s progress. Thinking about what I want to do next.</blockquote>

<blockquote>When working mode, I give up time so easily, not actively thinking why, just working.</blockquote>

Experience and not experiencing.

