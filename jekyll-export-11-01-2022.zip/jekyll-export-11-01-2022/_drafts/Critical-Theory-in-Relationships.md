---
id: 6109
title: Critical Theory in Relationships
date: 2016-06-01T00:54:42-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6109
permalink: /?p=6109
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
I recently had a good conversation with a good friend. When thinking about what I desire from her, it is this: I desire for her to increase her potential, to be able to develop, and the ideal method to do that is by increasing her freedom, and the practical method to do that is to move her to the city. It seems what I desire in personal relationships is the same in society.

There is no gift-giving, the gift is human development.

When I spend time in a relationship, I want to learn from that person's experience, share my own, guide the person to the right direction in knowledge and in space. This is probably why I enjoy social organizing: by connecting people with the right wisdom, through material (media, urban material) and people, I push them in directions they desire or perhaps will desire.

definitions from Wikipedia:
Critical Theory -  "to liberate human beings from the circumstances that enslave them...Critical theory maintains that ideology is the principal obstacle to human liberation."

Altruism - "or selflessness is the principle or practice of concern for the welfare of others."