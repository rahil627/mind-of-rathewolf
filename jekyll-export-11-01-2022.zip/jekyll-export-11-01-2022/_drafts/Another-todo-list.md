---
id: 4113
title: Another todo list
date: 2015-09-17T09:37:09-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4113
permalink: /?p=4113
categories:
  - Uncategorized
---
時間再到了，我在感覺我得

It's that time again where I find myself in a capitalistic society, and must participate in inhuman activities to survive. The result? Another todo list! Let's jam.

1. 寫現在的全動機
2. 查思想，茶做什麼成功，做那事
3. 用努力讓工作比較社會的

current motives:
- choose a cheap, calm place to live in the city (Richmond / Sunset of SF or Queens / Sunset Park of NY) with cheap food and access to Fablab and Hackerspace and Pan's meeting room.
  - keep an eye out for apartments which could double as a public space
- create a schedule of courses and discussions in these spaces, using the appropriate Google Calendar,
- be a part of my local community -- create an online post and physical sign on a local bulletin board and a physical sign outside the apartment I live in that lists my skills (babysit, work, computers, websites, marketing, etc.), my belongings (to share), my space (to share and talk), and my interests

make everything I do social or profitable:

funny neighborhood profitable ideas:
- make and sell Indian food
  - ask buffet lady
  - can make day or night stand for special items
- make and sell various ready to drink teas, including chai
- game-making night market stand
- go to the east coast (nature) and make useful items from natural or recycled materials and sell it at the market -- insect repellent, body wash, shampoo, deodorant, travel gear (light and heavy travel)

self-education made social:
- self-made book curriculum with discussions of topics
- self-made film curriculum shown at my apartment

things to be done in spaces:
- choose courses of choice from master's programs I like, and create groups at the matching space, i.e. D&T studio at Fablab, play with software workshops at hackerspace?

civic ideas:
- create several maps for Taipei
  - neighborhoods
- write the biographies of local vendors
- continue Humans of Taipei?
- graffiti for urban planning causes, until I learn how to organize
- try MIT media software to facilitate community building
- see news for problem-solution ideas
- fix walking / biking / scootering path problem
- create and give no-vehicle signs to day and night market entrances

learn about Taipei's organizations

