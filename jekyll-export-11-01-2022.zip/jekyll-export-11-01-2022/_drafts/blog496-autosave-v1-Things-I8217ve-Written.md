---
id: 8081
title: 'Things I&#8217;ve Written'
date: 2018-02-10T12:27:15-05:00
author: rahil627
layout: revision
guid: http://www.rahilpatel.com/blog/496-autosave-v1
permalink: /496-autosave-v1/
---
