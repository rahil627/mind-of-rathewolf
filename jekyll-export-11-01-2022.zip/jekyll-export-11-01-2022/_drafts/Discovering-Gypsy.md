---
id: 6299
title: Discovering Gypsy
date: 2016-03-28T16:21:09-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6299
permalink: /?p=6299
categories:
  - Uncategorized
---
Did I just stumble upon an ideal ethnicity of people?

My CouchSurfing host...

There were two thoughts: 1. The Romani people were nomadic and creative. 2. They were have a history of being excluded (slaved, exiled, ethnic cleansing / genocide, beat, etc.) from other countries (including France in 2010?).

1.
Creative in communication:

Creative in human language: Mix language to continually create a new language, piecing together their own, and the country they live in, using whatever works.

Creative in artistic communication: Charlie Chaplin, many guitarists, violinists, certain traditional culture of music, painting, writers, crafts such as metal smith and woodworking, etc.

Creative in sports: with a sports game as a constraint for expression, they excel in sports.

Creativity in life: where I imagine most of the creativity goes is in their life. Their life is an ongoing performance, of creating dialog, actions, doing things.

2.
Because they were creative, nomadic peoples, they were excluded from non-creative, settled societies. They did not find capitalistic production enticing. It does not fit the life of impulse and creativity. So, they suffered, terribly.

What's intriguing here is why other cultures excluded them. 