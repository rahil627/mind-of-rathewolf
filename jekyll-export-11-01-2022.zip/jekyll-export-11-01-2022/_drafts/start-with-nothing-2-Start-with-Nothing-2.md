---
id: 4822
title: Start with Nothing 2
date: 2015-09-19T15:15:37-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4822
permalink: /?p=4822
categories:
  - Uncategorized
---
<blockquote>For the political economists, however, the natural soci-&nbsp;ety belonged not to the beginnings of history, but was emerging from the industrial revolution—capitalism.</blockquote>
&nbsp; - from The Revolutioary Ideas of Marx by Alex Callinicos.

This reminded me of an old idea, that anything political (and aesthetic?) must start from primitive societies, otherwise I feel the thought is useless because it doesn't encompass all societies, often limiting the thoughts to the authors own narrow worldview.