---
id: 8192
title: 'Things I&#8217;ve Written'
date: 2021-12-31T03:40:07-05:00
author: rahil627
layout: revision
guid: http://rahilpatel.com/blog/496-revision-v1/
permalink: /496-revision-v1/
---
