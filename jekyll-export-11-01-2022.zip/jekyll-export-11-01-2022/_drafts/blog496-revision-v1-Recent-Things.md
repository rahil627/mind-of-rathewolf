---
id: 8221
title: Recent Things
date: 2022-01-02T07:41:00-05:00
author: rahil627
layout: revision
guid: http://rahilpatel.com/blog/496-revision-v1/
permalink: /496-revision-v1/
---
