---
id: 3648
title: The Ideal Creative Environment
date: 2014-12-04T00:40:42-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3648
permalink: /?p=3648
categories:
  - Uncategorized
---
