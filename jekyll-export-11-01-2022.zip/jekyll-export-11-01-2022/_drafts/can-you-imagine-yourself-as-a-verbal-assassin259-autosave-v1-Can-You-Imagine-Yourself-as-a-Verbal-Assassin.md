---
id: 8152
title: Can You Imagine Yourself as a Verbal Assassin?
date: 2020-03-02T19:40:29-05:00
author: rahil627
layout: revision
guid: http://rahilpatel.com/blog/259-autosave-v1
permalink: /259-autosave-v1/
---
<a href="http://www.rahilpatel.com/verbal_assassin.html">Play the game</a>.

The title of the post is the theme I chose at my first game jam, <a href="https://www.facebook.com/event.php?eid=261046020606382">Castle Lab: Parsons x Babycastles</a>.

I've also written more about my about experiencing <a href="http://www.rahilpatel.com/blog/my-first-game-jam">my first game jam</a>.

EDIT: To reduce frustration, I added controls to repeat the last command. Subsequently, the game's length has been reduced to five seconds!