---
id: 496
title: 'Things I&#8217;ve Written'
date: 2012-02-07T02:32:59-05:00
author: Rahil
layout: page
guid: http://www.rahilpatel.com/blog/?page_id=496
inline_featured_image:
  - "0"
---
