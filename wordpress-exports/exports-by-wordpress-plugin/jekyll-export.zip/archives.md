---
id: 761
title: More Things
date: 2012-04-25T04:43:09-04:00
author: Rahil
layout: page
guid: http://www.rahilpatel.com/blog/?page_id=761
---
These things could help make finding things more easy.

<div id="toc_container" class="toc_transparent have_bullets">
  <p class="toc_title">
  </p>
  
  <ul class="toc_list">
    <li>
      <a href="#things_that_i_often_change_or_keep_up_to_date_or_should">Things that I often change or keep up to date, or should</a>
    </li>
    <li>
      <a href="#things_that_can_be_searched">Things that can be searched</a>
    </li>
    <li>
      <a href="#things_that_have_been_archived">Things that have been archived</a>
    </li>
    <li>
      <a href="#things_that_have_been_categorized">Things that have been categorized</a>
    </li>
  </ul>
</div>

## <span id="things_that_i_often_change_or_keep_up_to_date_or_should">Things that I often change or keep up to date, or should</span>

[A Curriculum of Experience](http://www.rahilpatel.com/blog/a-curriculum-of-experience)  
&#8211; [A Liberal Arts Self Study Curriculum](http://www.rahilpatel.com/blog/a-liberal-arts-self-study-curriculum)  
[A Self-Assessment](http://www.rahilpatel.com/blog/a-self-assessment)  
[A Self-Assessment II](http://www.rahilpatel.com/blog/a-self-assessment-ii)

<div id='1' class='widgets_on_page wop_tiny1  wop_small1  wop_medium1  wop_large1  wop_wide1'>
  <ul>
    <li id="search-2" class="widget widget_search">
      <h2 class="widgettitle">
        <span id="things_that_can_be_searched">Things that can be searched</span>
      </h2>
    </li>
    
    <li id="archives-2" class="widget widget_archive">
      <h2 class="widgettitle">
        <span id="things_that_have_been_archived">Things that have been archived</span>
      </h2>
      
      <label class="screen-reader-text" for="archives-dropdown-2">Things that have been archived</label> <select id="archives-dropdown-2" name="archive-dropdown"> <option value="">Select Month</option> <option value='http://rahilpatel.com/blog/2016/12'> December 2016 </option> <option value='http://rahilpatel.com/blog/2016/11'> November 2016 </option> <option value='http://rahilpatel.com/blog/2016/10'> October 2016 </option> <option value='http://rahilpatel.com/blog/2016/09'> September 2016 </option> <option value='http://rahilpatel.com/blog/2016/08'> August 2016 </option> <option value='http://rahilpatel.com/blog/2016/06'> June 2016 </option> <option value='http://rahilpatel.com/blog/2016/05'> May 2016 </option> <option value='http://rahilpatel.com/blog/2016/04'> April 2016 </option> <option value='http://rahilpatel.com/blog/2016/03'> March 2016 </option> <option value='http://rahilpatel.com/blog/2016/02'> February 2016 </option> <option value='http://rahilpatel.com/blog/2016/01'> January 2016 </option> <option value='http://rahilpatel.com/blog/2015/12'> December 2015 </option> <option value='http://rahilpatel.com/blog/2015/11'> November 2015 </option> <option value='http://rahilpatel.com/blog/2015/10'> October 2015 </option> <option value='http://rahilpatel.com/blog/2015/09'> September 2015 </option> <option value='http://rahilpatel.com/blog/2015/08'> August 2015 </option> <option value='http://rahilpatel.com/blog/2015/07'> July 2015 </option> <option value='http://rahilpatel.com/blog/2015/05'> May 2015 </option> <option value='http://rahilpatel.com/blog/2015/03'> March 2015 </option> <option value='http://rahilpatel.com/blog/2015/01'> January 2015 </option> <option value='http://rahilpatel.com/blog/2014/12'> December 2014 </option> <option value='http://rahilpatel.com/blog/2014/11'> November 2014 </option> <option value='http://rahilpatel.com/blog/2014/10'> October 2014 </option> <option value='http://rahilpatel.com/blog/2014/09'> September 2014 </option> <option value='http://rahilpatel.com/blog/2014/07'> July 2014 </option> <option value='http://rahilpatel.com/blog/2014/06'> June 2014 </option> <option value='http://rahilpatel.com/blog/2014/05'> May 2014 </option> <option value='http://rahilpatel.com/blog/2014/04'> April 2014 </option> <option value='http://rahilpatel.com/blog/2014/03'> March 2014 </option> <option value='http://rahilpatel.com/blog/2014/02'> February 2014 </option> <option value='http://rahilpatel.com/blog/2014/01'> January 2014 </option> <option value='http://rahilpatel.com/blog/2013/12'> December 2013 </option> <option value='http://rahilpatel.com/blog/2013/11'> November 2013 </option> <option value='http://rahilpatel.com/blog/2013/09'> September 2013 </option> <option value='http://rahilpatel.com/blog/2013/08'> August 2013 </option> <option value='http://rahilpatel.com/blog/2013/07'> July 2013 </option> <option value='http://rahilpatel.com/blog/2013/06'> June 2013 </option> <option value='http://rahilpatel.com/blog/2013/04'> April 2013 </option> <option value='http://rahilpatel.com/blog/2013/02'> February 2013 </option> <option value='http://rahilpatel.com/blog/2012/10'> October 2012 </option> <option value='http://rahilpatel.com/blog/2012/08'> August 2012 </option> <option value='http://rahilpatel.com/blog/2012/05'> May 2012 </option> <option value='http://rahilpatel.com/blog/2012/04'> April 2012 </option> <option value='http://rahilpatel.com/blog/2012/03'> March 2012 </option> <option value='http://rahilpatel.com/blog/2012/02'> February 2012 </option> <option value='http://rahilpatel.com/blog/2011/12'> December 2011 </option> <option value='http://rahilpatel.com/blog/2011/11'> November 2011 </option> <option value='http://rahilpatel.com/blog/2011/10'> October 2011 </option> <option value='http://rahilpatel.com/blog/2011/09'> September 2011 </option> <option value='http://rahilpatel.com/blog/2011/07'> July 2011 </option> <option value='http://rahilpatel.com/blog/2011/06'> June 2011 </option> <option value='http://rahilpatel.com/blog/2011/05'> May 2011 </option> <option value='http://rahilpatel.com/blog/2011/01'> January 2011 </option> <option value='http://rahilpatel.com/blog/2010/12'> December 2010 </option> <option value='http://rahilpatel.com/blog/2010/07'> July 2010 </option> <option value='http://rahilpatel.com/blog/2010/05'> May 2010 </option> <option value='http://rahilpatel.com/blog/2010/04'> April 2010 </option> <option value='http://rahilpatel.com/blog/2010/03'> March 2010 </option> <option value='http://rahilpatel.com/blog/2010/02'> February 2010 </option> <option value='http://rahilpatel.com/blog/2009/12'> December 2009 </option> <option value='http://rahilpatel.com/blog/2009/10'> October 2009 </option> <option value='http://rahilpatel.com/blog/2007/08'> August 2007 </option> <option value='http://rahilpatel.com/blog/2007/07'> July 2007 </option> <option value='http://rahilpatel.com/blog/2007/06'> June 2007 </option> </select>
    </li>
    <li id="categories-5" class="widget widget_categories">
      <h2 class="widgettitle">
        <span id="things_that_have_been_categorized">Things that have been categorized</span>
      </h2>
      
      <ul>
        <li class="cat-item cat-item-207">
          <a href="http://rahilpatel.com/blog/category/humanities" title="philosophy, art, history, languages (not philosophy of language or linguisitics), health, travel experiences, qualitative social sciences, broader social sciences / The humanities are academic disciplines that study human culture. In Middle Ages, the term contrasted with divinity and referred to what is now called classics, the main area of secular study in universities at the time. Today, the humanities are more frequently contrasted with natural, physical and sometimes social sciences as well as professional training. / The humanities use methods that are primarily critical, or speculative, and have a significant historical element[2]—as distinguished from the mainly empirical approaches of the natural sciences">Humanities</a> (344) <ul class='children'>
            <li class="cat-item cat-item-140">
              <a href="http://rahilpatel.com/blog/category/humanities/art">Art</a> (155) <ul class='children'>
                <li class="cat-item cat-item-113">
                  <a href="http://rahilpatel.com/blog/category/humanities/art/films">Films</a> (46) <ul class='children'>
                    <li class="cat-item cat-item-172">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/films/film-ideas">Film Ideas</a> (1)
                    </li>
                    <li class="cat-item cat-item-11">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/films/film-reviews" title="Post Film Thoughts">Film Reviews</a> (35)
                    </li>
                    <li class="cat-item cat-item-106">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/films/filmmaking">Filmmaking</a> (3)
                    </li>
                    <li class="cat-item cat-item-163">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/films/philosophy-of-film">Philosophy of Film</a> (6)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-46">
                  <a href="http://rahilpatel.com/blog/category/humanities/art/games">Games</a> (35) <ul class='children'>
                    <li class="cat-item cat-item-165">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/games/game-design">Game Design</a> (7)
                    </li>
                    <li class="cat-item cat-item-112">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/games/game-development">Game Development</a> (12)
                    </li>
                    <li class="cat-item cat-item-147">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/games/game-ideas">Game Ideas</a> (4)
                    </li>
                    <li class="cat-item cat-item-144">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/games/game-reviews">Game Reviews</a> (3)
                    </li>
                    <li class="cat-item cat-item-159">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/games/game-philosophy">Philosophy of Game</a> (7)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-150">
                  <a href="http://rahilpatel.com/blog/category/humanities/art/literature">Literature</a> (41) <ul class='children'>
                    <li class="cat-item cat-item-160">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/literature/essays" title="An essay has been defined in a variety of ways. One definition is a &quot;prose composition with a focused subject of discussion&quot; or a &quot;long, systematic discourse&quot;.[1] It is difficult to define the genre into which essays fall. Aldous Huxley, a leading essayist, gives guidance on the subject.[2] He notes that &quot;the essay is a literary device for saying almost everything about almost anything&quot;, and adds that &quot;by tradition, almost by definition, the essay is a short piece&quot;.">Essays</a> (18)
                    </li>
                    <li class="cat-item cat-item-244">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/literature/literature-reviews">Literature Reviews</a> (3)
                    </li>
                    <li class="cat-item cat-item-253">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/literature/philosophy-of-literature">Philosophy of Literature</a> (6)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-251">
                  <a href="http://rahilpatel.com/blog/category/humanities/art/music">Music</a> (2) <ul class='children'>
                    <li class="cat-item cat-item-252">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/music/philosophy-of-music">Philosophy of Music</a> (2)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-149">
                  <a href="http://rahilpatel.com/blog/category/humanities/art/new-media">New Media</a> (16) <ul class='children'>
                    <li class="cat-item cat-item-166">
                      <a href="http://rahilpatel.com/blog/category/humanities/art/new-media/new-media-design">New Media Design</a> (12)
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            
            <li class="cat-item cat-item-183">
              <a href="http://rahilpatel.com/blog/category/humanities/design" title="not art, definitely not science. can have aesthetic, functional, economic and sociopolitical dimensions">Design</a> (13) <ul class='children'>
                <li class="cat-item cat-item-242">
                  <a href="http://rahilpatel.com/blog/category/humanities/design/environmental-design" title="Environmental design is the process of addressing surrounding environmental parameters when devising plans, programs, policies, buildings, or products...Environmental design can also refer to the applied arts and sciences dealing with creating the human-designed environment. These fields include architecture, geography, urban planning, landscape architecture, and interior design.">Environmental Design</a> (3)
                </li>
                <li class="cat-item cat-item-248">
                  <a href="http://rahilpatel.com/blog/category/humanities/design/product-design">Product Design</a> (1) <ul class='children'>
                    <li class="cat-item cat-item-249">
                      <a href="http://rahilpatel.com/blog/category/humanities/design/product-design/product-ideas">Product Ideas</a> (1)
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            
            <li class="cat-item cat-item-157">
              <a href="http://rahilpatel.com/blog/category/humanities/health">Health</a> (3)
            </li>
            <li class="cat-item cat-item-193">
              <a href="http://rahilpatel.com/blog/category/humanities/history">History</a> (5)
            </li>
            <li class="cat-item cat-item-148">
              <a href="http://rahilpatel.com/blog/category/humanities/philosophy">Philosophy</a> (251) <ul class='children'>
                <li class="cat-item cat-item-168">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/aesthetics" title="aka Philosophy of Art. Aesthetics is a branch of philosophy dealing with the nature of art, beauty, and taste, with the creation and appreciation of beauty. It is more scientifically defined as the study of sensory or sensori-emotional values, sometimes called judgments of sentiment and taste.">Aesthetics</a> (14)
                </li>
                <li class="cat-item cat-item-228">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied" title="just a category header for things that usually start with &quot;Philosophy of&quot;">Applied Philosophy</a> (50) <ul class='children'>
                    <li class="cat-item cat-item-139">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-education">Philosophy of Education</a> (34)
                    </li>
                    <li class="cat-item cat-item-229">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-history">Philosophy of History</a> (4)
                    </li>
                    <li class="cat-item cat-item-224">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-language" title="Philosophy of language is concerned with four central problems: the nature of meaning, language use, language cognition, and the relationship between language and reality. For continental philosophers, however, the philosophy of language tends to be dealt with, not as a separate topic, but as a part of logic (see the section &quot;Language and continental philosophy&quot; below)...Philosophy of language pays more attention to natural languages or to languages in general, while semiotics is deeply concerned with non-linguistic signification. Philosophy of language also bears connections to linguistics, while semiotics might appear closer to some of the humanities (including literary theory) and to cultural anthropology.">Philosophy of Language</a> (4)
                    </li>
                    <li class="cat-item cat-item-233">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-science" title="Philosophy of science is a branch of philosophy concerned with the foundations, methods, and implications of science. The central questions of this study concern what qualifies as science, the reliability of scientific theories, and the ultimate purpose of science. This discipline overlaps with metaphysics, ontology, and epistemology, for example, when it explores the relationship between science and truth.">Philosophy of Science</a> (6) <ul class='children'>
                        <li class="cat-item cat-item-219">
                          <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-science/philosophy-social-science" title="The philosophy of social science is the study of the logic and method of the social sciences, such as sociology, anthropology, and political science. Philosophers of social science are concerned with the differences and similarities between the social and the natural sciences, causal relationships between social phenomena, the possible existence of social laws, and the ontological significance of structure and agency.">Philosophy of Social Science</a> (6)
                        </li>
                      </ul>
                    </li>
                    
                    <li class="cat-item cat-item-196">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-applied/philosophy-technology" title="social science counterpart: Science, Technology, and Society">Philosophy of Technology</a> (7)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-199">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/autonomy">Autonomy</a> (3)
                </li>
                <li class="cat-item cat-item-197">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/communication" title="includes semiotics, media studies, language, philosophy of language. Communication is the purposeful activity of information exchange between two or more participants in order to convey or receive the intended meanings through a shared system of signs and semiotic rules.">Communication</a> (44) <ul class='children'>
                    <li class="cat-item cat-item-171">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/communication/media" title="aka comparative media studies. Researchers may also develop and employ theories and methods from disciplines including cultural studies, rhetoric (including digital rhetoric), philosophy, literary theory, psychology, political science, political economy, economics, sociology, anthropology, social theory, art history and criticism, film theory, feminist theory, and information theory.">Media</a> (30)
                    </li>
                    <li class="cat-item cat-item-259">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/communication/verbal-communication">Verbal Communication</a> (5) <ul class='children'>
                        <li class="cat-item cat-item-240">
                          <a href="http://rahilpatel.com/blog/category/humanities/philosophy/communication/verbal-communication/linguistics" title="Semiotics is closely related to the field of linguistics, which, for its part, studies the structure and meaning of language more specifically. The semiotic tradition explores the study of signs and symbols as a significant part of communications...Semiotics differs from linguistics in that it generalizes the definition of a sign to encompass signs in any medium or sensory modality.">Linguistics</a> (3)
                        </li>
                        <li class="cat-item cat-item-226">
                          <a href="http://rahilpatel.com/blog/category/humanities/philosophy/communication/verbal-communication/semiotics" title="Semiotics is closely related to the field of linguistics, which, for its part, studies the structure and meaning of language more specifically. The semiotic tradition explores the study of signs and symbols as a significant part of communications...Semiotics differs from linguistics in that it generalizes the definition of a sign to encompass signs in any medium or sensory modality.">Semiotics</a> (2)
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-247">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/eastern-philosophy">Eastern Philosophy</a> (3)
                </li>
                <li class="cat-item cat-item-241">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/environmental-pyschology" title="Environmental psychology is an interdisciplinary field focused on the interplay between individuals and their surroundings...Since its conception, the field has been committed to the development of a discipline that is both value oriented and problem oriented, prioritizing research aimed at solving complex environmental problems in the pursuit of individual well-being within a larger society.[1] When solving problems involving human-environment interactions, whether global or local, one must[according to whom?] have a model of human nature that predicts the environmental conditions under which humans will behave. This model can help design, manage, protect and/or restore environments that enhance reasonable behavior, predict the likely outcomes when these conditions are not met, and diagnose problem situations.">Environmental Psychology</a> (5)
                </li>
                <li class="cat-item cat-item-177">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/epistemology">Epistemology</a> (17) <ul class='children'>
                    <li class="cat-item cat-item-236">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/epistemology/philosophy-empericism" title="Empiricism is a theory that states that knowledge comes only or primarily from sensory experience.">Empericism</a> (1)
                    </li>
                    <li class="cat-item cat-item-237">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/epistemology/philosophy-rationalism" title="In epistemology, rationalism is the view that &quot;regards reason as the chief source and test of knowledge&quot;[1] or &quot;any view appealing to reason as a source of knowledge or justification&quot;.">Rationalism</a> (2)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-169">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/ethics">Ethics</a> (69) <ul class='children'>
                    <li class="cat-item cat-item-179">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/ethics/humanitarianism">Humanitarianism</a> (1)
                    </li>
                    <li class="cat-item cat-item-198">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/ethics/rationality">Rationality</a> (10)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-187">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/experience-philosophy">Experience</a> (12)
                </li>
                <li class="cat-item cat-item-234">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/history-philosophy" title="not philosophy of history!">History of Philosophy</a> (1)
                </li>
                <li class="cat-item cat-item-238">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/metaphysics" title="Metaphysics is a traditional branch of philosophy concerned with explaining the fundamental nature of being and the world that encompasses it,[1] although the term is not easily defined.[2] Traditionally, metaphysics attempts to answer two basic questions in the broadest possible terms:[3]

Ultimately, what is there?
What is it like?">Metaphysics</a> (44) <ul class='children'>
                    <li class="cat-item cat-item-164">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/metaphysics/action" title="aka Philosophy of Action. An action is something which is done by an agent. In common speech, the term action is often used interchangeably with the term behavior. In the philosophy of action, the behavioural sciences, and the social sciences, however, a distinction is made: behavior is defined as automatic and reflexive activity, while action is defined as intentional, purposive, conscious and subjectively meaningful activity[citation needed]. Thus, throwing a ball is an instance of action; it involves an intention, a goal, and a bodily movement guided by the agent. On the other hand, catching a cold is not considered an action because it is something which happens to a person, not something done by one.">Action</a> (24)
                    </li>
                    <li class="cat-item cat-item-246">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/metaphysics/determinism-and-free-will" title="Determinism is the philosophical position that for every event, including human interactions, there exist conditions that could cause no other event. &quot;There are many determinisms, depending on what pre-conditions are considered to be determinative of an event or action.&quot;[1] Deterministic theories throughout the history of philosophy have sprung from diverse and sometimes overlapping motives and considerations. Some forms of determinism can be empirically tested with ideas from physics and the philosophy of physics. The opposite of determinism is some kind of indeterminism (otherwise called nondeterminism). Determinism is often contrasted with free will.">Determinism and Free Will</a> (5)
                    </li>
                    <li class="cat-item cat-item-175">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/metaphysics/philosophy-of-mind" title="Philosophy of mind is a branch of philosophy that studies the nature of the mind, mental events, mental functions, mental properties, consciousness, and their relationship to the physical body, particularly the brain. The mind–body problem, i.e. the relationship of the mind to the body, is commonly seen as one key issue in philosophy of mind, although there are other issues concerning the nature of the mind that do not involve its relation to the physical body, such as how consciousness is possible and the nature of particular mental states.[2][3][4]">Mind and Matter</a> (22) <ul class='children'>
                        <li class="cat-item cat-item-245">
                          <a href="http://rahilpatel.com/blog/category/humanities/philosophy/metaphysics/philosophy-of-mind/physicalism-and-materialism" title="In philosophy, physicalism is the ontological thesis that &quot;everything is physical&quot;, that there is &quot;nothing over and above&quot; the physical,[1] or that everything supervenes on the physical.[2] Physicalism is a form of ontological monism—a &quot;one substance&quot; view of the nature of reality as opposed to a &quot;two-substance&quot; (dualism) or &quot;many-substance&quot; (pluralism) view. Both the definition of &quot;physical&quot; and the meaning of physicalism have been debated.

Physicalism is closely related to materialism. Physicalism grew out of materialism with the success of the physical sciences in explaining observed phenomena. The terms are often used interchangeably, although they are sometimes distinguished, for example on the basis of physics describing more than just matter (including energy and physical law). Common arguments against physicalism include both the philosophical zombie argument[3] and the multiple observers argument,[4] that the existence of a physical being may imply zero or more distinct conscious entities.">Physicalism and Materialism</a> (2)
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-235">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/philosophy-movement" title="A philosophical movement is either the appearance or increased popularity of a specific school of philosophy, or a fairly broad but identifiable sea-change in philosophical thought on a particular subject. Major philosophical movements are often characterized with reference to the nation, language, or historical era in which they arose.">Philosophical Movements</a> (3)
                </li>
                <li class="cat-item cat-item-216">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/political-economy">Political Economy</a> (1)
                </li>
                <li class="cat-item cat-item-173">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/political-philosophy" title="study of topics such as politics, liberty, justice, property, rights, law, and the enforcement of a legal code by authority">Political Philosophy</a> (14) <ul class='children'>
                    <li class="cat-item cat-item-200">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/political-philosophy/civics" title="Civics is the study of the theoretical and practical aspects of citizenship, its rights and duties; the duties of citizens to each other as members of a political body and to the government.">Civics</a> (7)
                    </li>
                    <li class="cat-item cat-item-222">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/political-philosophy/social-anarchism" title="Social anarchism (sometimes referred to as socialist anarchism[1]) is a non-state form of socialism[2] and is generally considered to be the branch of anarchism which sees individual freedom as being dependent upon mutual aid.[3] Social anarchist thought generally emphasizes community and social equality.">Social Anarchism</a> (2)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-145">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/psychology" title="Psychology is the study of mind and behavior. I guess it stands it&#039;s own between philosophy of mind and social philosophy.">Psychology</a> (31) <ul class='children'>
                    <li class="cat-item cat-item-142">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/psychology/schizoid-personality-disorder">Schizoid Personality Disorder</a> (15)
                    </li>
                    <li class="cat-item cat-item-176">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/psychology/time-perception">Time Perception</a> (3)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-156">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy" title="the science counterpart is sociology -- the scientific study of social behavior or society, including its origins, development, organization, networks, and institutions.

I use it a catch-all of anything social or cultural (social studies, cultural studies).">Social Philosophy</a> (80) <ul class='children'>
                    <li class="cat-item cat-item-146">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/anthropology" title="Anthropology is the study of humanity.[1][2][3] Its main subdivisions are social and cultural anthropology,[1][2][3] which describes the workings of societies around the world, linguistic anthropology, which investigates the influence of language in social life, and biological or physical anthropology,[1][2][3] which concerns long-term development of the human organism">Anthropology</a> (11)
                    </li>
                    <li class="cat-item cat-item-215">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/area" title="can throw travel writing here. interdisciplinary fields of research and scholarship pertaining to particular geographical, national/federal, or cultural regions.">Area</a> (5)
                    </li>
                    <li class="cat-item cat-item-191">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/community">Community</a> (5)
                    </li>
                    <li class="cat-item cat-item-192">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/critical-theory" title="originated in philosophy, taken up by sociology -- a school of thought that stresses the reflective assessments and critique of society and culture by applying knowledge from the social sciences and the humanities. It contains social theories, cultural theories, cultural critics, and a whole lot more.">Critical Theory</a> (17)
                    </li>
                    <li class="cat-item cat-item-182">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/human-geography" title="Human geography is the branch of the social sciences that deals with the world, its people and their communities, cultures, economies and interaction with the environment by emphasizing their relations with and across space and place.">Human Geography</a> (11)
                    </li>
                    <li class="cat-item cat-item-221">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/public-sphere" title="The public sphere is an area in social life where individuals can come together to freely discuss and identify societal problems, and through that discussion influence political action. ">Public Sphere</a> (3)
                    </li>
                    <li class="cat-item cat-item-220">
                      <a href="http://rahilpatel.com/blog/category/humanities/philosophy/social-philosophy/social-change" title="Social change refers to an alteration in the social order of a society. Social change may include changes in nature[disambiguation needed], social institutions, social behaviours, or social relations.">Social Change</a> (3)
                    </li>
                  </ul>
                </li>
                
                <li class="cat-item cat-item-167">
                  <a href="http://rahilpatel.com/blog/category/humanities/philosophy/urban-philosophy" title="Urban sociology is the sociological study of life and human interaction in metropolitan areas.">Urban Philosophy</a> (41)
                </li>
              </ul>
            </li>
          </ul>
        </li>
        
        <li class="cat-item cat-item-3">
          <a href="http://rahilpatel.com/blog/category/personal">Personal</a> (181) <ul class='children'>
            <li class="cat-item cat-item-158">
              <a href="http://rahilpatel.com/blog/category/personal/conversation" title="personal conversations, usually e-mails and applications. These are recorded, whereas topical writings should be categorized as essays.">Conversation</a> (6)
            </li>
            <li class="cat-item cat-item-185">
              <a href="http://rahilpatel.com/blog/category/personal/experience">Experience</a> (50) <ul class='children'>
                <li class="cat-item cat-item-137">
                  <a href="http://rahilpatel.com/blog/category/personal/experience/travel" title="could fit under social humanities, maybe literature, as travel writing">Travel</a> (43) <ul class='children'>
                    <li class="cat-item cat-item-218">
                      <a href="http://rahilpatel.com/blog/category/personal/experience/travel/hong-kong">Hong Kong</a> (1)
                    </li>
                    <li class="cat-item cat-item-154">
                      <a href="http://rahilpatel.com/blog/category/personal/experience/travel/japan">Japan</a> (6)
                    </li>
                    <li class="cat-item cat-item-188">
                      <a href="http://rahilpatel.com/blog/category/personal/experience/travel/new-york">New York</a> (2)
                    </li>
                    <li class="cat-item cat-item-217">
                      <a href="http://rahilpatel.com/blog/category/personal/experience/travel/south-korea">South Korea</a> (3)
                    </li>
                    <li class="cat-item cat-item-153">
                      <a href="http://rahilpatel.com/blog/category/personal/experience/travel/taiwan">Taiwan</a> (10)
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            
            <li class="cat-item cat-item-141">
              <a href="http://rahilpatel.com/blog/category/personal/life">Life</a> (42)
            </li>
            <li class="cat-item cat-item-254">
              <a href="http://rahilpatel.com/blog/category/personal/notes">Notes</a> (1)
            </li>
            <li class="cat-item cat-item-186">
              <a href="http://rahilpatel.com/blog/category/personal/organization">Organization</a> (11)
            </li>
            <li class="cat-item cat-item-184">
              <a href="http://rahilpatel.com/blog/category/personal/self-assessment">Self-assessment</a> (12)
            </li>
            <li class="cat-item cat-item-162">
              <a href="http://rahilpatel.com/blog/category/personal/thoughts">Thoughts</a> (102)
            </li>
          </ul>
        </li>
        
        <li class="cat-item cat-item-204">
          <a href="http://rahilpatel.com/blog/category/science" title="Use this for formal sciences, natural sciences, applied sciences, and interdisciplinary things that I feel are more quantitative, including social sciences.">Science</a> (1) <ul class='children'>
            <li class="cat-item cat-item-203">
              <a href="http://rahilpatel.com/blog/category/science/applied-science" title="includes engineering (mechanical, computer [including software], agricultural,) and healthcare, education, and probably subjects in common with applied philosophy.">Applied Science</a> (1) <ul class='children'>
                <li class="cat-item cat-item-138">
                  <a href="http://rahilpatel.com/blog/category/science/applied-science/engineering" title="for actual applications of technology, which is probably most of applied sciences. Things excluded are health, education, etc.">Engineering</a> (1)
                </li>
              </ul>
            </li>
          </ul>
        </li>
        
        <li class="cat-item cat-item-210">
          <a href="http://rahilpatel.com/blog/category/temp" title="temporary tag for post organization">temp</a> (13) <ul class='children'>
            <li class="cat-item cat-item-161">
              <a href="http://rahilpatel.com/blog/category/temp/drafts" title="for times when I post something unfinished">Drafts</a> (1)
            </li>
            <li class="cat-item cat-item-4">
              <a href="http://rahilpatel.com/blog/category/temp/specific-guides" title="Specific knowledge, research, how to guides, etc.">Specific Guides</a> (7)
            </li>
            <li class="cat-item cat-item-1">
              <a href="http://rahilpatel.com/blog/category/temp/uncategorized">Uncategorized</a> (4)
            </li>
          </ul>
        </li>
      </ul>
    </li>
  </ul>
</div>

<!-- widgets_on_page -->