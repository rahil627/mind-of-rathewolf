---
id: 6551
title: The Environmental Effects of Home
date: 2011-12-20T10:03:35-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6551
permalink: /the-environmental-effects-of-home
categories:
  - Environmental Psychology
  - Experience
  - Humanities
  - Personal
  - Philosophy
  - Thoughts
---
> Looking at my daily todo lists, the focus shifts from personal art (gamemaking, filmmaking, cooking) to helping others with often trivial things (buying a camera, fixing a car trunk, fixing PCs).
> 
> Technology has past the point of reason. People buy expensive things without actually using it.  
> <cite>20/12/2011</cite>