---
id: 2134
title: An Attempt to Write Everything I Know
date: 2014-06-27T17:11:19-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2134
permalink: /an-attempt-to-write-everything-i-know
categories:
  - Personal
---
隨機字條：因為寫不是創造的，我也會第一次用中文寫什麼都東西。

兩個月以前我開始設計程式的合同。那時候跟一點以前我做者聽哲學（Great Ideas of Philosophy, 2nd Edition by The Great Courses)。對我說來，我覺得有興趣。我天天聽了很少，只有一到二個演講，我覺得那多少夠了，對我想出來比較多。到那時候我不知道哲學是什麼。只有什麼東西有的學生學。

高中學校以來我總是寫我想出來什麼。我寫了什麼都東西。我感覺我寫了什麼是哲學的調查。

工作的時候我從好動改變消極，合理，不著經歷，沒經歷。所以我決定了我應該寫我知道什麼都。

可是我回來臺北的時候我馬上去附近的書店看哲學的書飯寫。我讀了「西方的哲學」被Bertrand Russell，一點讀別的書，讀Wikipedia。我覺得哲學的歷史很有興趣，尤其很少人好像我：Ludwig Wittgenstein，Francis Bacon，Søren Aabye Kierkegaard，可能John Dewey。

可是我覺得我讀了因為我現在比較懶。我感覺不見哲學對人比較好，理由好像理由我覺得不見藝術比較對人好：如果我讀別的人的書，我的心地好可能狹窄。所以我決定了我得聽讀書，只用我自己的字條寫。寫我怎麼了解什麼都東西。