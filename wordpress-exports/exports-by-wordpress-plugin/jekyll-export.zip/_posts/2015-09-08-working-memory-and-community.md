---
id: 4624
title: Working Memory and Community
date: 2015-09-08T17:04:44-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4624
permalink: /working-memory-and-community
categories:
  - Human Geography
  - Humanities
  - Philosophy
  - Social Philosophy
---
[todo: just publishing old drafts, this one might be worth thinking for human geography]

Old thought.

Working memory is limited. To remind oneself of the community, one must experience it, often. For this reason, living physically close to the community increases physical visibility, which in turn increases physical interaction.

Repeat this and it may become habit.

[I think I was getting at how habit of physical interaction is somewhat required for socialization, maintaining a community]