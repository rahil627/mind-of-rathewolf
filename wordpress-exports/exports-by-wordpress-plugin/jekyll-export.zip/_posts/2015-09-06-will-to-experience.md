---
id: 4637
title: Will to Experience
date: 2015-09-06T15:49:47-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4637
permalink: /will-to-experience
categories:
  - Experience
  - Philosophy
  - Thoughts
---
A bit contrasting to [Will to Make](http://www.rahilpatel.com/blog/will-to-make).

It&#8217;s not about organizing, it&#8217;s about experiencing.

Things that are considered experiences, but not making: talking, performing, physical movement.

The Will to Experience and the Will to Make might be a spectrum. The spectrum might be a major characteristic of culture.