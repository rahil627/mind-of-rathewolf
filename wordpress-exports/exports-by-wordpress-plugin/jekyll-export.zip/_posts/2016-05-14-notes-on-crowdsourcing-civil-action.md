---
id: 6825
title: Notes on Crowdsourcing Civil Action
date: 2016-05-14T05:16:04-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6825
permalink: /notes-on-crowdsourcing-civil-action
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"e15bcb7d6b21";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:77:"https://medium.com/@rahil627/notes-on-crowdsourcing-civil-action-e15bcb7d6b21";}'
categories:
  - Art
  - Civics
  - Design
  - Humanities
  - New Media
  - Personal
  - Philosophy
  - Political Philosophy
  - Thoughts
---
From a somewhat old (1-6 months) paper:

urban planning problem -> [Chris Marker-like] video -> use Facebook comments to talk about it (Facebook comments as forums) -> leads to something?

problems in reality [can be social?] -> media -> create and publish project on a crowdsourcing platform (i.e. Kickstarter) -> implement

examples：  
people don&#8217;t have or wear motorcycle helmets -> Humans of Taiwan photo -> crowdsource petition (to influence companies, law organisations, etc.) -> keep updated  
broken traffic light -> photo -> find correct organization to inform -> create application to automate process (i.e. FixMyStreet)