---
id: 3038
title: Suburbs are Obsolete
date: 2014-11-22T01:26:33-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3038
permalink: /suburbs-are-obsolete
categories:
  - Urban Philosophy
---
> >9/3/13  
> A neighborhood in the city is slow enough. There&#8217;s no reason to live in a suburb. Suburbs are temporary places to be, along with rural areas. Cities have everything.