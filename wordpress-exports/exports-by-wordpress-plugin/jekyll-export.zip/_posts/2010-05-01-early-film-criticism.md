---
id: 6515
title: Early Film Criticism
date: 2010-05-01T09:20:52-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6515
permalink: /early-film-criticism
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:11:"e6d45863461";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:61:"https://medium.com/@rahil627/early-film-criticism-e6d45863461";}'
categories:
  - Art
  - Films
  - Humanities
  - Personal
  - Philosophy of Film
  - Thoughts
---
> [old thought] what seperates a good movie from a bad one is realism. remove the hollywood plot and music. everything must be real &#8211; the character&#8217;s personalities, the outcome, the randomness, everything. add good cinematography, and BAM! you have a good movie.  
> <cite>5/1/2010 (dd/mm/yyyy) After watching Food Inc.</cite>

> Perhaps around college graduation I began to heavily watch films and think quite independently, and soon after, write a little during or after watching them.  
> <cite>5/5/2016</cite>