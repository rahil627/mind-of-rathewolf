---
id: 2831
title: Maximum Time Ethics
date: 2014-11-08T05:59:47-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2831
permalink: /maximum-time-ethics
categories:
  - Ethics
---
Related to my thoughts on [time perception](http://www.rahilpatel.com/blog/time-perception), is life maximized by maximizing time?

In cities, people experience more social interactions.

I wonder how nomadic peoples feel about their perception of time. I imagine they&#8217;d go crazy if you stuffed them in a cubicles.