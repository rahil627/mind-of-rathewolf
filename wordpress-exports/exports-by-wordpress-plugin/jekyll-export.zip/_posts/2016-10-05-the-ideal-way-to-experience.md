---
id: 7913
title: The Ideal Way to Experience
date: 2016-10-05T05:26:16-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=7913
permalink: /the-ideal-way-to-experience
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"16372e4a3dad";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";s:69:"https://medium.com/@rahil627/the-ideal-way-to-experience-16372e4a3dad";}'
categories:
  - Life
---
alternative titles: The Ideal Way to Travel

Perhaps associated with [Time and Space in Anthropology](http://www.rahilpatel.com/blog/time-and-space-in-anthropology) and [The Ideal Work](http://www.rahilpatel.com/blog/the-ideal-work).

notes:  
from a sheet of paper:  
live -> area problem -> *(low) work  
live -> *(high) art  
live -> love (place and people)

daydreams:  
go around Taiwan with a group  
kickstart projects together  
find room  
move to next town  
continue  
[to ideal work]

ideas:  
digital libraries  
&#8211; teach how to use e-reader, read. films. other arts.  
&#8211; in squatter spaces!  
&#8211; [vs public government buildings, such as libraries]  
&#8211; add sign, no cost  
&#8211; comfortable space as self-education  
&#8211; not education / social [? maybe meaning that the space is not social to the locality?]

from another sheet of paper:  
50 days walk, 30km/day  
France to China  
no belongings / small backpack is enough  
&#8211; no tent if enough friends  
&#8211; [hmm. I don’t think this is possible. Need backpack with tent, like Patrick, then hitch.]  
no worry  
&#8211; need traveler friends, need to walk around Taiwan