---
id: 1999
title: Methods of Sustaining Creativity in The Same Place
date: 2014-05-10T04:38:32-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=1999
permalink: /methods-of-sustaining-creativity-in-the-same-place
categories:
  - Art
  - Thoughts
---
[Old draft. Publishing anyway. Needs more work. Update 9/12/15: MIT Media Lab has a [Changing Places research group](https://www.media.mit.edu/research/groups/changing-places) which is based on this idea]

Non-physical &#8212; media.

Physical and alone. Another technique to extend hypomania, and creativity, is to continually create new experiences. One way is to change work places, to change external stimuli. A new park, cafe, shared workspace, street, protest, train, wherever.

Physical and social. A better method is to create new social experiences. Cook dinner for friends, have picnic at a park, play a game, talk, discuss, do something with other people.

[Constant creativity](http://www.rahilpatel.com/blog/constant-art-ethics "Constant Art Ethics") seems to almost require constant consumption.