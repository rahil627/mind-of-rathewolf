---
id: 3061
title: A World without Media
date: 2014-11-25T07:42:08-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3061
permalink: /a-world-without-media
categories:
  - Media
  - Philosophy
  - Thoughts
---
It&#8217;s hard to imagine.

Just a few decades ago, there was only books, newspapers, magazines, comic books, posters, and televisions with a few channels.

I feel that the less information there is, to a certain point, the less likely one will believe at face value, question it, and perhaps, react to it.

Now, that there is so much information, it seems people have become more indifferent to media. Do Americans shrug at imperialism, knowing but not caring? Or is it the discontentment of failed urban planning and a failed government?

I can&#8217;t imagine solidarity in action similar to Taiwan and Hong Kong in America. Does America even have the protest experience and institutions anymore?