---
id: 2973
title: Why Make Art?
date: 2014-11-15T08:34:43-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2973
permalink: /why-make-art
categories:
  - Aesthetics
  - Philosophy
---
> 9/22/14  
> Banksy’s role is to make people aware of what’s hidden in daily modern life, as with many other artists. A good example: the truck with stuffed animals, driving through Hell’s kitchen.

A list:  
To further art aesthetics  
To add something beautiful in the world  
To add something empirically educational  
To add something educational for humanities. If one believes in absolute truths, this is okay. Narrative (film, books) can be destructive a la propaganda.  
To make people aware of the bad things in society. Sounds like the reverse of the above.  
Because one has leisure time, and one is passionate  
To express a thought in a form that a mass amount of people can consume it at any time

combinations:  
to make a beautiful educational experience