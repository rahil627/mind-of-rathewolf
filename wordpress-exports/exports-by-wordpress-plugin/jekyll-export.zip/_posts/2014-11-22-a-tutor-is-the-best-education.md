---
id: 3027
title: A Tutor is the Best Education
date: 2014-11-22T01:06:55-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3027
permalink: /a-tutor-is-the-best-education
categories:
  - Philosophy of Education
---
> <2/9/12 It would have just been easier if I had a great mentor to follow.

Alexander, Montaigne, Descartes, and Russell all had tutors. Aristotle is best. A doctor is good. But even grandmothers who sometimes read books and ask questions are equally good.

The organization of knowledge in the information age is more important than ever.