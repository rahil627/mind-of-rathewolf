---
id: 2060
title: A Sequential List of Game Experiences that I Remember
date: 2014-05-30T18:01:17-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2060
permalink: /a-sequential-list-of-game-experiences-that-i-remember
categories:
  - Games
  - Philosophy of Game
---
todo: fix indenting  
House games:  
&#8211; the floor is lava (also played at playgrounds)  
Playground games  
&#8211; tag, tag variants, four square, HORSE  
Board games:  
&#8211; Carom, Monopoly, Mouse Trap  
Card games:  
&#8211; Speed (aka Slam, Spit)  
Sports  
Early games:  
&#8211; playing video games at Jacob&#8217;s house or at my house  
&#8211; Toejam & Earl, Goof Troop, Earthbound, Track & Field, anything cooperative  
&#8211; playing video games at Andrew&#8217;s house  
&#8211; anything  
&#8211; playing video games at Parth&#8217;s house  
&#8211; Herc&#8217;s Adventures, single player playstation RPG games played cooperatively, anything multiplayer  
Trend games:  
&#8211; CrossFire, that ball with strings in the center and you had to pull wide once the ball came close  
Arcade games  
PC Games:  
Diablo I and II, Starcraft, Caesar III, Settlers II, Age of Empires II, Team Fortress [Classic], Sim City 2000  
Nintendo 64 multiplayer games  
&#8211; Mario Kart 64, Goldeneye, Mario Party  
JRPGs  
&#8211; Final Fantasy VII and IX, Super Mario RPG, Chrono Trigger  
Emulator games:  
&#8211; Harvest Moon, older JRPGs (Secret of Mana, Final Fantasy III)  
Castlevania: Symphony of the Night  
Mario 64  
Pokemon Red and Blue  
[first year college]  
Halo 3  
World of Warcraft  
Team Fortress 2  
[after first year]  
Super Smash Bros. Melee  
Shadow of the Colossus (and Ico)  
Braid  
&#8211; lectures by Jonathan Blow, Jenova Chen, Chris Crawford, EGP, and everything else  
advent of indie games  
&#8211; Jason Rohrer, Anna Antropy, etc.  
IGF games  
playground games revisited  
New York:  
&#8211; lectures by indie artists and professors  
&#8211; Babycastles  
&#8211; every game exhibition  
&#8211; that time where Wu-Tang member had a concert at 285 kent with Pole Riders and MEGA-GIRP in the lobby  
&#8211; Atari game exhibition with lecture by Ian Bogost and that one dude who spilled his heart into making games for Atari  
&#8211; Space Cruiser  
&#8211; that time where Keita Takahashi designed a bunch of games and they made it forreal (was not there, only read article)  
&#8211; many interactive art exhibitions  
And then I started traveling and stopped consuming media, especially games.