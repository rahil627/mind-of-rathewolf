---
id: 3111
title: Social Life in Cities and Suburbs
date: 2014-11-22T22:28:33-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3111
permalink: /social-life-in-cities-and-suburbs
categories:
  - Social Philosophy
  - Thoughts
---
> 9/3/13  
> Seoul was an amazing personal social achievement. I made close friends. I kept them. I balanced time, living and working simultaneously.
> 
> In Seoul I couldn&#8217;t rely on sight-seeing to arouse my senses. I had to talk to people to make it livable.
> 
> My ability to create new friends, or my interest to, in Busan is not good.

> 9/19/13 in Tokyo, Japan  
> In Japan, I failed. With the help of Busan, the suburbs and Tomo&#8217;s house, I lost a lot of ambition and interest in exploration.

In a few days in Seoul, I felt I had a good group of friends. In a few days in Busan, life was hopeless. How the accessibility to other people affects social life is clear.