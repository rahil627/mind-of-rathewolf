---
id: 2768
title: Hourly Ethics
date: 2014-11-08T04:40:20-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2768
permalink: /hourly-ethics
categories:
  - Ethics
  - Philosophy
---
> 10/10/13  
> Prioritize time! Do as much as you can in one day, simultaneously thinking about art, life, and people. Live by the hour.

It&#8217;s nice to think all of the time. But I think it&#8217;s nice to at least think about what you are doing and it&#8217;s result every hour.

This is really great for a liberal education where several disciplines are wanted, as it provides a gestalts. Life, film, non-fiction all come together. Knowledge is confirmed in several forms.

One is also simply less likely to fall into routine slave-like work.