---
id: 2775
title: A Strange Moment during Humans of Taiwan
date: 2014-11-08T04:57:39-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2775
permalink: /a-strange-moment-during-humans-of-taiwan
categories:
  - Humanities
  - Life
  - Personal
  - Philosophy
  - Psychology
  - Schizoid Personality Disorder
  - Social Philosophy
  - Taiwan
  - Travel
---
> 10/10/13  
> I failed to talk to people for the purpose of humans. It was a waste of time. Wanderlust in the city. No social time. No work. No learning. Like the weekends in San Francisco. I need routine. A moment of a schizoid. This only happens when I am alone, otherwise I&#8217;m quick, watching time. In that moment in Wenhua, I was stuck. An extreme care for bums and lower class people. Hesitant of communicating with them. The humans project is a psychological battle.

This was indeed a strange moment.

I was in 萬華區 taking photos for Humans of Taiwan. It&#8217;s the grittiest part of Taiwan. The metro exits into a park full of people. Many not even Taiwanese. It&#8217;s visibly poorer, filthier, with an extremely high density of people.

The past few days I did well in talking to people and taking pictures. This moment changed that. After talking to a few people and taking a picture, at some point I was unable to continue. I couldn&#8217;t talk to some, or anyone anymore. My mind stopped forming Chinese sentences. Perhaps facing the poor caught up to me emotionally, and my care for them stopped me, from doing anything.

I mean, what was I doing anyway? To them I am perceived as a tourist taking a photo with them, or a language student, taking a photo of them. Taiwanese people know how Taiwanese people are. Was I really gaining any unique insight into human nature?

> My bane: Unable to make meaningful social interactions with lower class people while living a higher class one. Extreme care? So powerful that it stops me for hours.