---
id: 4361
title: Working Memory and Creativity
date: 2015-09-08T17:07:20-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4361
permalink: /working-memory-and-creativity
categories:
  - Action
  - Art
  - Design
  - Mind and Matter
  - Philosophy
  - Social Philosophy
---
[todo: just published some old drafts, this is very important for creative work]

[I didn&#8217;t write anything, but I believe I was getting at how creativity depends on the things in working memory, and how that interacts with long-term memory. For example, say you watched neorealism film in the recent past, then you have some intense travel experience, you may want to try to make a neorealist film.

I think I was also thinking about how design jams work. If one has knowledge of sensors in the mind, then has some experience, then forces oneself to try to design something with the experience in the working memory.]

[body]

to read:  
[en.wikipedia.org/wiki/Working_memory](https://en.wikipedia.org/wiki/Working_memory){.autohyperlink}