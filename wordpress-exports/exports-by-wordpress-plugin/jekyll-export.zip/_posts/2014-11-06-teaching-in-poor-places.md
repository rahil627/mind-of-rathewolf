---
id: 2656
title: Teaching in Poor Places
date: 2014-11-06T03:22:45-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2656
permalink: /teaching-in-poor-places
categories:
  - Philosophy of Education
  - Urban Philosophy
---
With today&#8217;s technology, it doesn&#8217;t seem the cost of teaching is much.

I would think a few laptops, internet, a secure public place, and a watchman who can teach how to use the computer to learn suffices. If the people do not know a language, then the teacher must teach them just enough language to use the computer for them self-learn. Perhaps there should be a liberal curriculum too, mainly taught through Wikipedia. For advanced peoples, OpenCourseware. Every populated place should have such a space.

I think curious people would naturally be attracted to it.