---
id: 6220
title: Submitting to Capitalism
date: 2016-03-11T23:43:33-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6220
permalink: /submitting-to-capitalism
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"b12d9b20a30c";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:66:"https://medium.com/@rahil627/submitting-to-capitalism-b12d9b20a30c";}'
categories:
  - Personal
  - Thoughts
---
A thought written yesterday, or the day before:

For once, I feel like accumulating a little capital to build a comfortable home, to survive the change in temperature, the winds, the walks, using the computer to communicate and to generate wealth a la programming. The public is harsh, abiding to their cultured ideas, unwilling to accept new ones. CouchSurfing, voluntary associations, and perhaps entire cities alike. I am best alone, comfortable. The time to actively understand the Other will reappear, but for now, I must survive, stockpile a few gold pieces for the next adventure.

To organize.

&nbsp;&nbsp;&nbsp;&nbsp;To dream beyond what&#8217;s near.

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Before I actualize my dreams again.  
&#8212;

from another paper, probably not too distant in time:

> What now? Live. Live again. Fuck trying to join these petty clubs. Do it all alone. With capitalism. \*Do labor gigs.\* \*Move horizontally.\* Use connections. Gather capital. \*Keep connecting and doing.\* Forget this direction for the moment and just do things. Create. Talk. Learn languages. Learn to forget. Change.
> 
> Hitch to Tainan, or anywhere warm. \*Catch labor gigs.\* \*Only do things for money.\* No [more] volunteer work. \*Abuse 104 along the way.\* Check software gigs in America.
> 
> The feeling of travel is so long ago. The experience. The creativity. It&#8217;s been so long.
> 
> Learn to 104 over my phone while hitchhiking. People want money; that is all that will motivate their actions. Do the work. Get physical. Get dirty. Do it.
> 
> \*These people don&#8217;t care for written language.\* They don&#8217;t care for conversation. They only act in accordance to capital. Capital and consumption. Other directions in life are missing.
> 
> Fuck them all. Fuck this country. They are fake, more fake than SF. More fake than China, Because in China, at least it is obvious. Hence, become your, and continuously take your body, money, and return nothing. Fuck them to hell.

This is the first sign of anger in perhaps 10 years.