---
id: 3095
title: 'Forms of Consumption: Reality and Media'
date: 2014-11-22T21:56:53-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3095
permalink: /forms-of-consumption-reality-and-media
categories:
  - Humanities
  - Media
  - Mind and Matter
  - Philosophy
  - Thoughts
  - Travel
---
> Failing to consume enough on a computer. Nothing beats travel in forms of consumption. To emulate it on a computer, I have to play pimsleur, cafe music, and a sitcom.

Even with all of the current media out there, it is not as sensational as reality.