---
id: 7900
title: 'Culture and [Social] Development'
date: 2016-10-05T04:34:28-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=7900
permalink: /culture-and-development
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"4eac96a58781";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";s:81:"https://medium.com/@rahil627/culture-and-social-development-progress-4eac96a58781";}'
categories:
  - Humanities
  - Philosophy
  - Social Change
  - Social Philosophy
---
transcribed from an old sheet of paper:

travel vs efficiency (medicine, engineer, etc.)  
travel vs system / organization (city, social organization)  
experience vs work  
&#8211; [perhaps I meant, following culture vs working toward social and / or material organization aka development]  
care for culture vs reality  
->  
care for culture  
&#8211; mind  
&#8211; \*\*social reality\*\*  
&#8211; lack intelligence / belief, story  
&#8211; The Act of Killing, cultural problems  
&#8211; \*\*no desire, apolitical, state\*\*  
&#8211; yet happy  
&#8211; aboriginal singing  
&#8211; \*\*non-capitalism\*\*  
&#8211; culture / family [end / category]

reality  
&#8211; education, resource, intelligence / skepticism, empiricism  
&#8211; fix problems, critical  
&#8211; \*\*desire better, political, progress\*\*  
&#8211; yet not happy  
&#8211; Kendrick Lamar  
&#8211; \*\*capitalism?\*\*  
&#8211; society / help all [end / category]

from another sheet of paper:  
[todo: maybe to another post, toward survival-only work, do not care for culture / education, as to allow for all cultures to thrive]  
next sheet:  
Tainan day 1:  
\*brainstorm\*  
straight to Planett  
&#8211; thinking about south / east of Taiwan  
&#8211; development in Tainan vs development in \*south / east\*  
&#8211; SE being simpler, more creative, \*leads to tools for survival\*  
&#8211; can’t stop thinking about this, social relations with place, like tonghua, small towns, neighborhoods  
&#8211; gov, non-gov, community  
&#8211; kickstart vs find / join organization / just live there first?  
&#8211; or design?  
&#8211; vs independent art (myself)  
&#8211; only care for \*survival\* &#8211; engi (social, construction, software tools [personal, commercial, functional], etc.) / medicine (social health / healthcare)  
&#8211; gov vs non-gov?  
&#8211; \*material infrastructure\*  
x/- education / social?  
&#8211; can’t interrupt culture  
&#8211; i saw it. Their schools suck. Just give computer vs local culture.  
&#8211; \*self-learning is best\*

possible further reading:  
[en.wikipedia.org/wiki/Instrumental\_and\_value_rationality](https://en.wikipedia.org/wiki/Instrumental_and_value_rationality){.autohyperlink}