---
id: 2449
title: Touch Me Not
date: 2014-09-20T03:00:09-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2449
permalink: /touch-me-not
categories:
  - Game Design
  - Games
  - New Media
  - New Media Design
---
Some kind of game in which players wear costumes, and parts of their bodies become targets.

Probably inspired by Johann Sebastian Joust.

<div style="text-align: center;">
  <a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/costume-game1.svg"><img src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/costume-game1.svg" alt="costume class=" /></a>
</div>