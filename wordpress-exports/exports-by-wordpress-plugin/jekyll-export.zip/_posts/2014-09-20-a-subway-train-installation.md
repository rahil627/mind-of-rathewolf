---
id: 2465
title: A Subway Train Installation
date: 2014-09-20T06:46:21-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2465
permalink: /a-subway-train-installation
categories:
  - Art
  - New Media
  - New Media Design
---
Provide a button that switches a light on in on the rear window of a subway train.

Who knows what treasure one will see?

<div style="text-align: center;">
  <a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/subway-light.svg"><img src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/subway-light.svg" alt="subway class="alignnone size-large wp-image-2466" /></a>
</div>

Thoughts:  
Probably more effective than those posters that give statistics on how garbage causes delays.

Possible title: New York City Zoo.