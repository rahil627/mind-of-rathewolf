---
id: 6132
title: The World is Yours
date: 2016-01-08T07:05:49-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6132
permalink: /the-world-is-yours
categories:
  - Personal
  - Thoughts
---
> Live on a rooftop, project a film (or just in a public space), politically vandalize, force out bad decisions — political / social, encourage safety and survival, ignore laws, the world is yours**, but it only feels like mine if there are people around. None of these public acts matter if no one is around. I need the city. No act is useful in a society where the acts make no sense to the community. Work is needed in less developed societies, but I desire to do higher level work. It is not satisfying to do any less (of course I can learn from anything), but it feels better to be near my full capability. &#8211; a thought from a note written in Yilan