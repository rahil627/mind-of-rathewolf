---
id: 2805
title: Actions Points Ethics
date: 2014-11-08T05:31:36-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2805
permalink: /actions-points-ethics
categories:
  - Ethics
---
> 10/14/13  
> To avoid wandering, keep talking to people, sleep well, exercise well, play music or audio all of the time.

In order for me to tire myself, I need to do a lot. It normally involves exercise, talking, audio input, and visual input. Eventually, I&#8217;ll poop out.