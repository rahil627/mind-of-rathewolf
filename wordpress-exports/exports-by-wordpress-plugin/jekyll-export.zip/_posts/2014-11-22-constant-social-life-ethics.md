---
id: 3054
title: Constant Social Life Ethics
date: 2014-11-22T01:53:13-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3054
permalink: /constant-social-life-ethics
categories:
  - Ethics
  - Social Philosophy
---
> >9/3/13  
> No learning, just living. Do the computer work and learning at night, or with others.
> 
> You have to either travel or work (in a social environment). There is no other option.

The goal of this ethics is to make every moment social. But there is a problem, one has to either bring others along, or join others ([social determinism](http://www.rahilpatel.com/blog/social-determinism "Social Determinism")?). And even then, it may be impossible if one is quite the dissident.