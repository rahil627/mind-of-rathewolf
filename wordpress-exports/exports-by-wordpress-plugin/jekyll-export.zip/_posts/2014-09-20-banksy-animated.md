---
id: 2389
title: 'Banksy: Animated'
date: 2014-09-20T03:27:27-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2389
permalink: /banksy-animated
categories:
  - New Media
  - New Media Design
---
It would be fun to animate Banksy&#8217;s art, and have them interact with the public.

<div style="text-align: center;">
  <a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-rat.svg"><img class="alignnone size-large wp-image-2390" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-rat.svg" alt="banksy rat" /></a><br /> Maybe the rat does mischievous things when people come near.<br /> &nbsp;<br /> &nbsp;<br /> &nbsp;<br /> <a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/bankst-animated.svg"><img class="alignnone size-large wp-image-2391" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/banksy-thekla.svg" alt="banksy thekla" /></a><br /> Maybe the Thekla can paddle along the river.</p>
</div>