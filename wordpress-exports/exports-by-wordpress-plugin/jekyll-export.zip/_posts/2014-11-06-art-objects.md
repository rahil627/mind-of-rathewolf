---
id: 2663
title: Art Objects
date: 2014-11-06T03:30:03-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2663
permalink: /art-objects
categories:
  - Art
---
[I don&#8217;t know where I was going with this, but I like it.]

> &#8220;the work of art can recapture the lost and thus save it from destruction, at least in our minds. Art triumphs over the destructive power of time.&#8221;

> &#8220;we are all capable of producing art, if by this we mean taking the experiences of life and transforming them in a way that shows understanding and maturity.&#8221;