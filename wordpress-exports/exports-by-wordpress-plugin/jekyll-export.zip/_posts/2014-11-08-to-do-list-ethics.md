---
id: 2812
title: To Do List Ethics
date: 2014-11-08T05:40:58-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2812
permalink: /to-do-list-ethics
categories:
  - Ethics
---
> 10/15/13  
> Don&#8217;t do things because you have to, on a to do list. Do it because you want to.

I often fall for this. Wake up, get in a work zone, create a list of things to do, do them. It&#8217;s routine. But it should never exceed being a day old. Everyday is a new to do list.

I see a lot of people do this in the form of e-mails. Perhaps the digital form of this ethics: e-mail ethics.