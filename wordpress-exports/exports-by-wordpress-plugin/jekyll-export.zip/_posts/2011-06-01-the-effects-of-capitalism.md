---
id: 6553
title: The Effects of Capitalism
date: 2011-06-01T09:30:40-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6553
permalink: /the-effects-of-capitalism
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"5a85573b32aa";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:67:"https://medium.com/@rahil627/the-effects-of-capitalism-5a85573b32aa";}'
categories:
  - Experience
  - Life
  - Personal
  - Thoughts
---
> My two largest internal conflicts:  
> 1. The concern of money  
> 2. Not being able to &#8220;just do it&#8221;  
> <cite>1/6/2011 (dd/mm/yyyy)</cite>