---
id: 677
title: La Planète Sauvage (Fantastic Planet)
date: 2012-03-26T05:41:42-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=677
permalink: /la-planete-sauvage
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"97f06914eb1b";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";s:82:"https://medium.com/@rahil627/la-plan%C3%A8te-sauvage-fantastic-planet-97f06914eb1b";}'
categories:
  - Film Reviews
  - Films
---
[Old draft, just posting without proofreading.]

Fantastic Planet thoughts while watching:  
First, thought about how great it is as a animal rights movie. Placing humans has pets.

Then I thought about how Jonathan Blow mentioned that he liked to read Calvino because it expands his mind. I agree. The book is fantastic for thinking, creating new ideas, as is this film.

Then I started thinking about how primitive ideas are the core of real world problems. Tribes translate to countries. Who cares about airport security or offices. None of that matters.

Then I thought more about how humans can be compared to insects. They multiply, live in undesirable places

Making something universal as this helps it become timeless.

The film reaks of creativity. Other sci-fi films often have only a few alterations compared to real life. This one never stops. If you were to watch a random clip of the film before seeing the entire film, you wouldn&#8217;t be able to comprehend what is going on. You would think the film is strictly for hippies. Once put together, it&#8217;s completely coherent. [Trying to think of others, only Miyazaki comes to mind]

interview with the director:  
Favors ideas over polish.  
He was interested in shadow puppets, and created a film of it with mentally ill patients. That lead to finding an artistic partner, worked on it for 4 years in another country while war was going on, outsourcing work.