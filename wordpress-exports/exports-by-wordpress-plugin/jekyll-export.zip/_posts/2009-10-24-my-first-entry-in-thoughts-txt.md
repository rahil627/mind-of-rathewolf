---
id: 6506
title: My first entry in thoughts.txt
date: 2009-10-24T09:20:44-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6506
permalink: /my-first-entry-in-thoughts-txt
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"2190e39aa958";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:72:"https://medium.com/@rahil627/my-first-entry-in-thoughts-txt-2190e39aa958";}'
categories:
  - Humanities
  - Personal
  - Thoughts
---
> i had to write the following down somewhere, i&#8217;ve gone over these things so many times
> 
> i think it&#8217;s very hard to to grow up in the US and end up being a well-balanced (good judgement) individual
> 
> i think most of the choices you make, to become who you are, are done by genetics, which is sad.
> 
> &#8230;but most of my brown generation have followed a brolife, which is fine&#8230;i guess&#8230;but they&#8217;re not really trying in school or life. just lost souls in a stupid society
> 
> &#8230;and what happened to the learning!? did people lose their ability to learn? now people just say, &#8220;oh this stupid device is broken, and now i have to buy a new one&#8221;. google/wikipedia more! if my 42yr old aunt can come to america, learn english/computers/owning a house/getting and keeping a job, then so can anyone younger than her.
> 
> judgement is probably the trait i value the most. my dad has the best, and i have the second best ^^.
> 
> mom wins in willpower. maybe i&#8217;ll gain some willpower, once i have my own family.
> 
> life and money[:]  
> 0-30 brood creativity &#8211; think of ideas/invent/design
> 
> 31-50 family
> 
> 50+ charity/help family and friends  
> <cite>Rahil, 24/10/2009, <em>thoughts</em></cite>

> maybe if i write down my thoughts, i can think of new ones, since i will feel like these thoughts have been established. [the following was written on 1/22] if i write down my thoughts, i won&#8217;t dwell on the same thoughts either.  
> <cite>Rahil, 31/10/2009(7?), <em>thoughts</em></cite>