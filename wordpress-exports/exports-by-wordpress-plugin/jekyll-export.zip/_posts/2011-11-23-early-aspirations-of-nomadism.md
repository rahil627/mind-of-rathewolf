---
id: 6547
title: Early Aspirations of Nomadism
date: 2011-11-23T10:03:37-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6547
permalink: /early-aspirations-of-nomadism
categories:
  - Ethics
  - Humanities
  - Life
  - Personal
  - Philosophy
  - Thoughts
---
[todo: combine with [early ideal lifestyles](http://www.rahilpatel.com/blog/early-ideal-lifestyles)?]

> Next move? SF, Hawaii, Japan, Canada (Toronto, Vancouver), New Zealand?, Asia? (3 months in each of Japan, China, Korea, Indonesia, etc.),&#8230;  
> <cite>21/11/2011</cite> 

> I&#8217;ve said before, at my core I&#8217;m a vagabond. I like to explore, live, create. This can be seen as greedy as it takes away from family time. I just have to make sure I commnicate with my family and friends while I&#8217;m gone. Start using skype weekly. Go to India with my parents next time.
> 
> I would be okay with living in poverty as long as I&#8217;m doing the things I like. I&#8217;ll only compromise to a desk job if I need the money or social interaction.
> 
> It&#8217;s no different then when I was young. Before, I used to explore neighborhoods on my bike. I still explore neighborhoods on my bike! But now I can go further, around the world. I also now have the confidence to make things. I have a much clearer mind. I&#8217;m healthy.  
> <cite>23/11/2011</cite> 

And now, as I write this on 4/5/2016, I am in poverty, doing the things I like. Well, kind of.