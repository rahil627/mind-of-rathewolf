---
id: 2114
title: Hedonism and Wisdom
date: 2014-06-08T00:42:55-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2114
permalink: /hedonism-and-wisdom
categories:
  - Thoughts
---
One must consume to gain knowledge. But how does one do so without being a hedonist?

[these posts also may go with this: [Methods of Sustaining Creativity in the Same Place](http://www.rahilpatel.com/blog/methods-of-sustaining-creativity-in-the-same-place), [Creativity and Exercise](http://www.rahilpatel.com/blog/creativity-and-exercise)]