---
id: 2836
title: Creativity and Social Life
date: 2014-11-08T07:57:58-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2836
permalink: /creativity-and-social-life
categories:
  - Thoughts
---
> 10/23/13  
> Not creating enough! Need to put self into new social situations constantly.

Talking is creative. It&#8217;s easy to forget, but once one is learning a language, it&#8217;s easier to feel the brain work to put together grammar and memorize words.

It&#8217;s the inscription onto mediums that are painful, because they are not social, and therefore offer little pleasure while in the crafting phase.