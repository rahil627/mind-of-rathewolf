---
id: 2958
title: New Experience Ethics
date: 2014-11-11T05:46:02-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2958
permalink: /new-experience-ethics
categories:
  - Ethics
---
> 11/20  
> Travel to a random place everyday.  
> &#8230;  
> The change in audio and visual is what I need.

I had trouble choosing the middle word of the topic. Experience, stimuli, or external stimuli. I am not sure.

There&#8217;s an interview of Chomsky on the 21st century where he mentioned the effects of modern technology can lead to stimulus addiction (? may not be accurate term).

Stimulus addiction leads to irrational behavior, sure, but [external stimulus invokes creativity](http://www.rahilpatel.com/blog/creativity-external-stimuli-cities-and-suburbs "Creativity, External Stimuli, Cities, and Suburbs"), which seems to be lacking from rational intellectuals.