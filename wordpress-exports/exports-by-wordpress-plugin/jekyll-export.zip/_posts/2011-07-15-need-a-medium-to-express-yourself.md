---
id: 6535
title: Need a Medium to Express Yourself
date: 2011-07-15T10:03:39-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6535
permalink: /need-a-medium-to-express-yourself
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:11:"2dba6768452";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:74:"https://medium.com/@rahil627/need-a-medium-to-express-yourself-2dba6768452";}'
categories:
  - Aesthetics
  - Communication
  - Life
  - Media
  - Personal
  - Philosophy
  - Thoughts
---
> have to find a media [medium] to express myself  
> <cite>?/7/2011</cite>

> You should be able to translate whatever is on your mind in the medium you are most comfortable with. That&#8217;s art. Maybe you&#8217;re currently into capitalism, then make something about it to express your feelings about capitalism. Maybe you just love the feeling of cooking, make something acorrding to that!  
> <cite>15/10/2011</cite>

> Does the medium and artist works on even matter? Whether he writes books, directs films, or draws, the artist&#8217;s expression is still being displayed.
> 
> Does the medium require technical experience before the expression is shown? Many artists first work shows characteristics of expression. It may not be polished, but the idea is still there.
> 
> People shouldn&#8217;t ask, &#8220;what do you do?&#8221;. That&#8217;s limiting. Ideally a person shouldn&#8217;t think &#8220;I&#8217;m going to do these things today&#8221;. It should be more free. On the day of, just wander and explore, then perhaps Later you may feel the need to express or test those explored concepts on a medium.  
> <cite>6/11/2010</cite>

There&#8217;s hint of my early ideals here: of wanting people to be able to be able to freely do as they wish. There&#8217;s also the ability to distinguish art from mass culture. Not bad! And of course, the artist&#8217;s communication through mediums of choice.