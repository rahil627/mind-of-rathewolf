---
id: 3051
title: Mood Swings
date: 2014-11-22T01:50:12-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3051
permalink: /mood-swings
categories:
  - Action
  - Philosophy
  - Psychology
  - Schizoid Personality Disorder
---
> >9/3/13  
> When my creativity and motivation stops, what is the remedy? Travel? Spend time with friends? Meet people?
> 
> What will wake me up?
> 
> What will get me out of depression?

This is quite common for me. Usually on a high for about 3 months, then a low. I usually struggle getting out of the low. It usually results a change in direction, but that doesn&#8217;t fit many societies, when a job may have the length of a year. I finish whatever project I&#8217;m working on, then move on. This leads to me choosing [small projects](http://www.rahilpatel.com/blog/constant-art-ethics "Constant Art Ethics").

Mood swings are probably associated to my [schizoid psychology](http://www.rahilpatel.com/blog/the-life-of-a-nomadic-schizoid "The Life of a Nomadic Schizoid").

> 9/20 in Tokyo, Japan  
> Feeling restless. Not enough social communication. I need friends, work friends, family. Keep creating and talking.
> 
> My heart is going to explode if I don&#8217;t talk to someone.

It really does feel as if my heart were to explode. I desired stimulus that badly. I&#8217;m absolutely restless.

> ~2/14/13 to 8/6/13: in New York  
> Perhaps the slump hits hard only because I previously never had something I was excited about.  
> &#8230;  
> I&#8217;m neither tiring my mind or body enough to sleep. I must not be outing enough work hours in.

I think written closer to winter time.