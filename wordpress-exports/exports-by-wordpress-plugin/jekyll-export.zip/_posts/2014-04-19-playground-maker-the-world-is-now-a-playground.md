---
id: 1889
title: 'Playground Maker: The World is Now a Playground'
date: 2014-04-19T13:04:35-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=1889
permalink: /playground-maker-the-world-is-now-a-playground
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"97552243172c";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:8:"unlisted";s:3:"url";s:88:"https://medium.com/@rahil627/playground-maker-the-world-is-now-a-playground-97552243172c";}'
categories:
  - Game Ideas
  - Games
---
Using [Second Surface](http://www.creativeapplications.net/openframeworks/second-surface-multi-user-spatial-collaboration-system/), one can create playgrounds for others to play in the real world. Only doodles for boundaries are needed to create levels.

later possibilities:  
walls (thick lines) that can be adjusted  
boxes and circles that can be scaled  
add rules to the game, perhaps just writing a doodle at the start is enough  
colors, rules can define what they do: green for good, red for bad, etc.