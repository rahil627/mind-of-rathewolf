---
id: 2845
title: Constant Action Ethics
date: 2014-11-08T06:06:53-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2845
permalink: /constant-action-ethics
categories:
  - Ethics
---
Or Mania?

> 10/10/13  
> I have no idea what life is anymore. You have to keep fighting for time, fighting for life, life, work, family, all of it.

> 10/11/13  
> It is good to have priorities of social things, like learning language, Humans, and Vincent Moon. I feel it provides a more relaxed, yet productive lifestyle. I overwork myself.

> You have to enjoy life at every moment. Don&#8217;t worry so much. Keep living. I can feel the worry of money seeping in

> >6/28/13  
> The trick to traveling is to keep moving. Don&#8217;t choose or research, just go. The trick to living is to travel everyday for a short period of time. No, travel all the time. Everyday is an adventurer.

> >9/3/13You have to stay outside. Never inside. Keep wandering. Keep talking to people. Keep working outside. There&#8217;s nothing inside a building.

> thoughts from Japan before 9/24/13:  
> There&#8217;s no end to life. No settling. An infinite roller coaster.

> 10/25/13  
> I&#8217;d rather live a life of adventure rather than planning.

> 10/26/13  
> After a night out with that girl I met at the concert:  
> &#8230;  
> She did have one point: I don&#8217;t know how to relax, which is something Kate said.
> 
> &#8230;
> 
> The morning sets the pace. That initial push to go out, and stay out, exploring, socializing. It&#8217;s the houses and libraries that make me complacent and unsocial. You have to keep moving and talking. Don&#8217;t stop. Only study during breaks in life.

> ~2/14/13 to 8/6/13 in New York  
> I need to constantly explore. Physically and mentally.  
> &#8230;  
> Don&#8217;t think far in the future. Just think what to do now, and do that, then there will be a less chance of work going to waste.  
> &#8230;  
> Just do it. Make shit all day non stop. 

They may seem to be an irrational ethic, but the body&#8217;s action doesn&#8217;t really matter, it is separate from the mind. The change in external stimuli seem to be key.