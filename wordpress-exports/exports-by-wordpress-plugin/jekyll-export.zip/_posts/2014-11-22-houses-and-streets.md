---
id: 3097
title: Houses and Streets
date: 2014-11-22T22:03:35-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3097
permalink: /houses-and-streets
categories:
  - Action
  - Ethics
  - Humanities
  - Philosophy
  - Social Philosophy
  - Urban Philosophy
---
> >9/3/13  
> My creativity is completely gone. I&#8217;m paying for an expensive hostel without thought of work. I&#8217;m working on old things without thought. I need some inspiration.

Impulsivity dissipates the longer I stay inside a house. This included my parent&#8217;s house, my family&#8217;s house in India, and, a friendly hostel in Seoul.

It&#8217;s surprising I lost impulsivity in the hostel in Seoul. But like Japan, South Korea is nearly entirely developed, with people inside buildings. Even the parks are artificial.

The more time I spend on the street, the more impulsive I am. Travel being the best. This harks Rimbaud&#8217;s biography and Dean Mortiarty as extreme examples.

> >9/3/13Cars are terrible. It&#8217;s like a house on wheels.

When one is inside a car, one doesn&#8217;t interact with the world, only with what&#8217;s inside the car. The difference of a opening a window is huge.