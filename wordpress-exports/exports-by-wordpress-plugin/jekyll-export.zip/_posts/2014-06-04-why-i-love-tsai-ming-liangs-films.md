---
id: 2088
title: 'Why I Love Tsai-Ming Liang&#8217;s Films'
date: 2014-06-04T18:57:51-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2088
permalink: /why-i-love-tsai-ming-liangs-films
categories:
  - Films
  - Philosophy of Film
---
[Could use more work!]

Why do I love Tsai Ming Liang&#8217;s films?

In answering this, I believe I can find what characteristics of aesthetics I personally love.

Because his work is told from a view of a person from the street, a person who has no culture. The perspectives of the lives in his films are rarely shown, especially for such lengths of time. When i am in a state of hypomania, I think about the poor, how they relate to the world, and what they do. When I go to another country there is a layer of alienation brought out by culture: the temples, prayers, customs , food, tv. Culture itself is alien to humans, it&#8217;s acquired; I always question how it came to be. How did the world come to the way it is. Lines of large apartment buildings in China, hours of commute time, betel nut stands, shopping malls, everything. When travelling through diverse areas, from indigenous to city, I keep questioning these things. In Tsai Ming Liang&#8217;s films, I feel I am similarly always questioning. Given a slow pace, the low class humans in society, devoid of culture, almost devoid of life, one gets a fresh travelers perspective again. How did the world come to be? What are people doing, and why?

Few films bring about these questions.

During highly active times of travel, including hypomanic times of being entirely irrational, I couldn&#8217;t stand any form of media because most films assume so much: film cliches, genres, reason films are made, and the most assumed of all: culture. Compared to going outside and actively doing something, only Tsai Ming-Liang was watchable.

Film reviews: