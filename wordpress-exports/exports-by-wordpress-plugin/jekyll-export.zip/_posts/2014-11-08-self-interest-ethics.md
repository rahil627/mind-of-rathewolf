---
id: 2770
title: Self-Interest Ethics
date: 2014-11-08T04:43:45-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2770
permalink: /self-interest-ethics
categories:
  - Ethics
---
> 10/10/13  
> Really want scooter for sunny days. Really need to stop the class and study on my own time. Be social in class, no more.

> 10/15/13  
> Treat my work as work. Stick to my own direction. Its the only thing that makes me happy. It&#8217;s just so rare that my direction is similar to others. Only in New York did that happen.

Indeed, there are many times in my life where self-interest directed my actions over social relationships.