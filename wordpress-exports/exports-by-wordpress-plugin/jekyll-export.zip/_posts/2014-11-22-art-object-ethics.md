---
id: 3019
title: Art Object Ethics
date: 2014-11-22T00:39:46-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3019
permalink: /art-object-ethics
categories:
  - Art
  - Ethics
---
> <2/9/12 Just observe art, make art, and love life.

Probably a result of living in the suburbs.

Not good. One should observe reality, and perhaps use art objects to gain knowledge of other cultures, especially when one is unable to travel.