---
id: 6692
title: The Steps to Do It, with Integrity
date: 2012-02-08T08:59:03-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6692
permalink: /the-steps-to-do-it
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"b1ae82ed99be";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:62:"https://medium.com/@rahil627/do-it-with-integrity-b1ae82ed99be";}'
categories:
  - Ethics
  - Humanities
  - Philosophy
---
> Steps in life.  
> Overcome body influences  
> Overcome time management  
> Overcome the system  
> Overcome the fear of doing  
> Overcome the fear of doing something large
> 
> Control body, time  
> Do it  
> Do it with integrity
> 
> Preface. The following steps are meaningless as any self help book. It is merely a gauge. To learn, you must do it yourself. A large shortcut to a lot of it is to live alone with just two bags.
> 
> Hmmm, it may be that the reason I cannot make something large is my lack of leadership. I need to overcome communication. I need to be able to choose my group and lead to success.
> 
> It would have just been easier if I had a great mentor to follow.
> 
> Post about life lessons.  
> <cite>&#8216;thoughts from iPhone possibly older than 2-9-12.txt&#8217;</cite>