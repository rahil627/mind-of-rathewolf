---
id: 3017
title: Aim for the Highest Ethics
date: 2014-11-22T00:33:34-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3017
permalink: /aim-for-the-highest-ethics
categories:
  - Ethics
---
> The most important problem is not being solved. Why care about anything else?

Ignore everything. Aim for the highest goal.

This is not a bad idea.

This coincides with another phrase, &#8220;have a big idea, then everything else will fall in place.&#8221;