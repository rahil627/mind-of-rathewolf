---
id: 4108
title: Habit and Addiction
date: 2015-07-26T14:33:56-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4108
permalink: /habit-and-addiction
categories:
  - Human Geography
  - Humanities
  - Mind and Matter
  - Philosophy
  - Psychology
  - Social Philosophy
  - Thoughts
  - Urban Philosophy
---
A short thought. Related to awareness.

Addiction is a habit. People tend to create habits. Habits are created from living in the same area. The same area contains the same materials and humans. Moving to a new area alleviates the mind from old habits, uses a little mind power to create new habits