---
id: 2334
title: Underground Music Speaker
date: 2014-09-18T06:00:30-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2334
permalink: /underground-music-speaker
categories:
  - New Media
  - New Media Design
---
Have a speaker in a public place above ground playing music live from a street musician underground. Also have a donation box.

<div style="text-align: center;">
  <a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/underground-music.svg"><img class="alignnone size-large wp-image-2335" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/underground-music.svg" alt="underground music" /></a>
</div>

Design:  
Data input: sound from musician underground  
Data output: sound through speaker overland

Idea:  
Would people dance to a speaker? Would people donate without being able to prove? Would people donate to a speaker? Does the physical body of a musician matter?

Further design: Have speakers outside of an expensive concert play music live. Create a barrier and charge people at the entrance. Charge a fraction. Would people pay?