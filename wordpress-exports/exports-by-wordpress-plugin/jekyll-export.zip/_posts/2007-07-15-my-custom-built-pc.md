---
id: 926
title: My Custom Built PC
date: 2007-07-15T15:04:31-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=926
permalink: /my-custom-built-pc
categories:
  - Specific Guides
  - temp
---
This is a list of components of my custom PC and some peripherals. A lot of research went in when buying this, so I thought I&#8217;d share it.

motherboard: MSI P6N SLI Platinum LGA 775 NVIDIA nForce 650i  
CPU: Intel Core 2 Duo E6420 Conroe 2.13GHz 4M shared L2 Cache @ 3ghz  
heatsink: XIGMATEK HDT-S1283 120mm Rifle CPU Cooler  
DVD burner: SAMSUNG 18X DVD±R DVD Burner with LightScribe SATA SH-S183L  
hard drive: Seagate Barracuda 7200.10 ST3320620AS 320GB 7200RPM SATA 3.0Gb/s  
video card: EVGA 320-P2-N811-AR GeForce 8800 GTS 320MB 320-bit GDDR3  
memory: G.SKILL F2-6400PHU2-2GBHZ 2GB (2 x 1GB) DDR2 800 (PC2 6400)  
PSU: CORSAIR CMPSU-520HX 520W

case: Antec Solo  
fan1: Nexus D12SL-12 120mm Case Fan  
fan2: Antec 761345-75092-9 92mm Case Fan

monitor: Hanns.G HW-191DPB Black 19&#8243; 5ms Widescreen LCD 300 cd/m2 700:1  
speakers: Logitech Z-5500 505 Watts 5.1 Speaker  
mouse: Logitech MX518 2-Tone 8 Buttons 1 x Wheel Wired Optical 1800 dpi  
keyboard: some old HP