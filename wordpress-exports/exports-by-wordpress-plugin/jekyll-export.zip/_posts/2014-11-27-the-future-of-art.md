---
id: 3483
title: The Future of Art
date: 2014-11-27T12:00:30-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3483
permalink: /the-future-of-art
categories:
  - Art
---
Is in machines.