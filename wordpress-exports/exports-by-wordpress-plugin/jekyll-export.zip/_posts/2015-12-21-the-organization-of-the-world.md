---
id: 5839
title: The Organization of the World
date: 2015-12-21T08:47:25-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=5839
permalink: /the-organization-of-the-world
categories:
  - Humanities
  - Personal
  - Philosophy
  - Thoughts
---
The organizing of the world into media is philosophy.

The organizing of the world is politics.

The organizing of ideas is art.

The organizing of a dwelling is survival.

The copying of the world is documentary [film].

The experiencing with the world is life.

The experiencing with the art is not.