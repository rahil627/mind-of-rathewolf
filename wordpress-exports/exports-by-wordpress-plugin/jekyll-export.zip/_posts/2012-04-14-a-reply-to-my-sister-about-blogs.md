---
id: 2015
title: A Reply to My Sister About Blogs
date: 2012-04-14T11:43:46-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2015
permalink: /a-reply-to-my-sister-about-blogs
categories:
  - Conversation
---
> Hah, you&#8217;re way more excited about this then I am. I&#8217;m still not interested.
> 
> My gripe about blogs is that I find 99% of them useless, including my own. I&#8217;ve never followed a blog, I&#8217;ve only stumbled upon specific well-written posts by people that I admire. If &#8220;how to hold a hamburger properly&#8221; was chosen to be &#8220;freshly pressed&#8221; then I deem WordPress&#8217;s standards for content is low, aiming for popularity instead of quality. I don&#8217;t seek popularity; I only care for those few people who actually searched specifically for something I wrote.
> 
> Again, blogging is my lowest priority. Before I can write anything, I have to create/do something first.  
> <cite>[same as publishing date? (14/4/2012)]</cite>