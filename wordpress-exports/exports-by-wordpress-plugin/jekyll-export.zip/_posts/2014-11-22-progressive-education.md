---
id: 2752
title: Progressive Education
date: 2014-11-22T22:38:39-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2752
permalink: /progressive-education
categories:
  - Philosophy of Education
---
> 9/12/13 in Busan  
> No school makes sense. Go by pure motivation. Fuck anything else.

> 9/22/13 in Tokyo, Japan  
> The only way I learn is by creating via motivation. There is no other way. No point of forcing myself to learn.

A thought soon after moving to Taiwan:

> Dont let anyone take you in the wrong direction. You don&#8217;t have to spend time learning chinese with classmates if it doesn&#8217;t motivate you. Learn it in your own way. It&#8217;s more fun, more serious, much more interesting, in my view. See the beauty in the world.

> 10/15/13  
> Learn by doing. There is no other way. There&#8217;s not enough motivation otherwise.

> unknown date:  
> I didn’t need school for stimulation; A city provides that.