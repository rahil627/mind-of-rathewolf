---
id: 6353
title: Media and Action
date: 2016-04-15T22:45:45-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6353
permalink: /media-and-action
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"f109dc25df09";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:58:"https://medium.com/@rahil627/media-and-action-f109dc25df09";}'
categories:
  - Action
  - Art
  - Communication
  - Critical Theory
  - Films
  - Games
  - Humanities
  - Linguistics
  - Media
  - Metaphysics
  - Philosophy
  - Philosophy of Film
  - Philosophy of Game
  - Social Philosophy
---
From a thought today:

> &#8220;&#8230;The second essay is about whether &#8216;personal essays&#8217; ever cause action: has anyone acted upon an _Essai_ by Montaigne[?], as people acted when Blow made _Braid_, or when Vertov made _Man with a Movie Camera_? Did the games and films made in response [to them] merely create more communication, as opposed to action? No [and Yes?]. It&#8217;s the accessibility of the medium that increases the chance of acting in response. &#8216;I read the news today&#8217; is a different experience from watching _Night and Fog_, and that itself different from what I imagine and hope the experience of playing _This War of Mine_. The closer the experience of a medium is to real experience, the greater the chance of acting in response.&#8221;