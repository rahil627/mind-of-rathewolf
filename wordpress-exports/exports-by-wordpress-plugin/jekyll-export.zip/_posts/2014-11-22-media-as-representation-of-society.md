---
id: 3122
title: Media as Representation of Society
date: 2014-11-22T23:06:21-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3122
permalink: /media-as-representation-of-society
categories:
  - Experience
  - Japan
  - Media
  - Personal
  - Social Philosophy
  - Travel
---
> 9/12/13 in Busan  
> The power of media is reminded as people from Mexico say that Korean drama and pop is popular. Meh, I don&#8217;t care for it.

It&#8217;s possible that person was influenced by media to see another society. Unfortunately, the pop media doesn&#8217;t reflect society realistically, and then people are disappointed.

I was somewhat interested in Japan due to games I played as a child, notably, Final Fantasy. After experiencing the life of Southeast Asia, I had no interest in Japan because I felt their culture was insular. When I went, I felt I was in a land of suburbs, where people consume media. The only fantasy was that in the game. The reality was people consuming it.