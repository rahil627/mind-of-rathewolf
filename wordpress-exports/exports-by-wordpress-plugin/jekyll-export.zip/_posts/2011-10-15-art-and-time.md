---
id: 6541
title: Art and Time
date: 2011-10-15T10:03:39-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6541
permalink: /art-and-time
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"94c357814bc1";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:54:"https://medium.com/@rahil627/art-and-time-94c357814bc1";}'
categories:
  - Ethics
  - Humanities
  - Life
  - Personal
  - Philosophy
  - Thoughts
---
> Although I would enjoy learning/doing martial arts, cooking, breakdancing, and other cool somewhat useful skills that are more accessible to learn in a city, I think I&#8217;ll always prioritize work/art over it. Creating video games and film wins my time.  
> <cite>15/10/2011</cite> 

> Experiencing things (reading Wikipedia, watching a film, exploring a city) is good, but it&#8217;s equally important to create things (writing, filmmaking, city planning). Although, creating is an experience itself.  
> <cite>8/12/2011</cite>