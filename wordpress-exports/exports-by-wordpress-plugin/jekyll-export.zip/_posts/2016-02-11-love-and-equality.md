---
id: 6458
title: Love and Equality
date: 2016-02-11T19:30:43-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6458
permalink: /love-and-equality
categories:
  - Uncategorized
---
12/2  
Played with, or was played by a girl. What should I have done different? Should I have left her alone to talk with her friends through Facebook? Bring her water, ask if everything is okay, then leave? Yeah, probably. She would have been fine. Now there&#8217;s the possibility I messed with our friendly relationship. We&#8217;ll see tomorrow.

Turns out I really suck at foreplay. Or, I have at least a little self-control, and decided not to do anything, which translates into being stuck, three-quarters-in-control one-quarter-play, allowing her to touch my face, never going beyond, and me only touching to hold her back. I could have at least practiced some play, at least show that I can play, so that she&#8217;d back off.

Perhaps my non-commitment in life shows in relationships, and even in foreplay. I stay reserved, stoic, romantic. It&#8217;s probably appears very unromantic.

If I had money, was just traveling, would it be the same? No. I really wouldn&#8217;t care for the person as much. I&#8217;d be interested in work, critical theory, helping people. I was caught (stuck) with this girl, because I really like her. I could have played much better if I didn&#8217;t have my financial constraints.

By I like her I mean she&#8217;s a good person. Good, being that undefinable adjective used by Plato. She&#8217;s good in the greatest sense of that word, and that&#8217;s worth being around. Sometimes the rationality is just that simple. It&#8217;s worth being around good people, and helping them.

The reason she&#8217;s stuck here is because of financial constraints. A seemingly male domination. When I saw what her boyfriend said, which he had previously and equally disgustingly said to his sister, I was as appalled as when I saw what my dad said to his servants in India. This feeling is almost the source [of driving force] of my life.

She&#8217;s much better, enjoys creativity, work, and fun; Her freedom is constrained. I adapted and socialized so much since I&#8217;ve been in Yilan, appreciating their simple and cheap lifestyle. Perhaps it&#8217;s the critical part of me that attracts me. Knight helps a slave, to increase he freedom of another person. A simple rationality, despite my philosophic recent past. There&#8217;s a potential that is lost, in her, in humans alike. And it is simply constrained by systems, economic or social, no different. It is unequal.

God, she is the most beautiful girl I&#8217;ve met (maybe exaggerrated by current feelings). She has it all.

The critical part is interesting though. How can a human be stuck with another human, without some kind of relationship, and when that relationship is dominant on one side, isn&#8217;t it effectively inequality? When does it become dominant?* Did it start with domination? Don&#8217;t males play male-dominating dating games with girls? What does an equal relationship look like? Aren&#8217;t friends equals? Hence the difficulty of friends in relationships.

Is it as simple as treating animals? Training females (and other slaves) like pets?

Females can get jobs, so why not break and go with old friends, take a break, work elsewhere when one needs money.

In this case, there is a long relationship, something that I do not have experience of, so very likely, I cannot empirically understand.

I guess I will keep escaping inequality, and conversely, keep striving for equality.

Perhaps this is why artists create so many things about love: because they get a strong feeling and have the desire to express it. My love seems to be more like Plato&#8217;s, which I haven&#8217;t read, but simply, a love for those undefinable traits: equality, freedom, good.

I don&#8217;t need a romantic (in the normative sense) human relationship to evoke that feeling, I&#8217;ve get enough of that from my nomadic lifestyle.  
But it&#8217;s nice to know that romantic human relationships can evoke that feeling.