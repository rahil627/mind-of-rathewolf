---
id: 5833
title: Urban and Suburban Culture
date: 2015-12-21T11:05:10-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=5833
permalink: /urban-and-suburban-culture
categories:
  - Environmental Psychology
  - Humanities
  - Personal
  - Philosophy
  - Thoughts
---
21/12/15

> City culture has space as a factor. Suburban culture does not, [therefore] it relies on media.