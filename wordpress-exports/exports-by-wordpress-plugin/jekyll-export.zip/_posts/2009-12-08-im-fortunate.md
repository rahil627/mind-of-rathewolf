---
id: 6513
title: 'I&#8217;m Fortunate [Early Ethics]'
date: 2009-12-08T09:20:51-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6513
permalink: /im-fortunate
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"dcd2d10fb945";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:54:"https://medium.com/@rahil627/im-fortunate-dcd2d10fb945";}'
categories:
  - Ethics
  - Humanities
  - Personal
  - Philosophy
  - Thoughts
---
> enver told me about pb&j. i don&#8217;t think his problem is due to psychology. he needs to be beaten. real bad. i feel like in this case, he wasn&#8217;t raised right. only in America do these sort of people get by [written later: they wouldn&#8217;t survive elsewhere, they wouldn&#8217;t be allowed to do these things elsewhere].
> 
> genetics or parents, which to blame? it&#8217;s tough to say whether the problem is genetics or the parents, but pb&j is a prime example of a mentally normal human gone awry. how does this happen? at what stage in his life did this occur?
> 
> i need to wikipedia psychology and genetics.  
> i&#8217;m fortunate &#8211; an old thought, but i haven&#8217;t written it yet. i&#8217;m extremely fortunate in every way possible. great parents, top genes (mental and physical), raised well (middle class neighborhood, public schools, great parenting, temple, travel [it&#8217;s better to let a kid explore the world, rather than keeping him in the house]), and i&#8217;m wealthy. it could be the reason that i&#8217;m always happy. if you have what i have, why would you be angry? although, i think the reason i am happy is because i have a &#8216;happy gene&#8217;. if i were raised less fortunate, i beleive i&#8217;d still be happy. sure, there would be more stress, but i think i would prevail =). even further, i think i&#8217;d be more inspired! have more reasons to reach for a more demanding goal.
> 
> oh right, the i&#8217;m fortunate thought comes to mind whenever the life in an undeveloped country is mentioned.  
> <cite>8/12/2009 (dd/mm/yyyy)</cite>