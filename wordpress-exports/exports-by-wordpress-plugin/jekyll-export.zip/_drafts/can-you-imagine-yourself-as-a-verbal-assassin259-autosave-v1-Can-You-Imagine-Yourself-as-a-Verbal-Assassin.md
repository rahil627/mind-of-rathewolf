---
id: 8152
title: Can You Imagine Yourself as a Verbal Assassin?
date: 2020-03-02T19:40:29-05:00
author: Rahil
layout: revision
guid: http://rahilpatel.com/blog/259-autosave-v1
permalink: /259-autosave-v1
---
[Play the game](http://www.rahilpatel.com/verbal_assassin.html).

The title of the post is the theme I chose at my first game jam, [Castle Lab: Parsons x Babycastles](https://www.facebook.com/event.php?eid=261046020606382).

I&#8217;ve also written more about my about experiencing [my first game jam](http://www.rahilpatel.com/blog/my-first-game-jam).

EDIT: To reduce frustration, I added controls to repeat the last command. Subsequently, the game&#8217;s length has been reduced to five seconds!