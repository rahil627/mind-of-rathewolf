---
id: 4213
title: The Ideal Economy
date: 2015-08-27T18:44:33-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4213
permalink: /?p=4213
categories:
  - Uncategorized
---
[economy or society?]

Just guessing this is what all the previous ideal posts of ideal space and city was leading to.