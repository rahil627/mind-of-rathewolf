---
id: 6403
title: Temp List
date: 2016-04-18T04:02:55-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6403
permalink: /?p=6403
categories:
  - Organization
  - Personal
  - temp
---
ignore this!

I&#8217;ve been writing in response to other writings recently, as opposed to experience. Not good. Here are some recent experiences to think and write about:

homeless people in Taiwan  
&#8211; how to fix this  
&#8211; experience of being homeless  
&#8212; exclusion practiced by institutions (unable to sleep at a convenience store, unable to sleep at a train station, not giving a free paper bowl or cup, flip-flops not allowed in certain libraries, passport required for certain libraries, etc.)

a list of cultural problems or ideologies in Taiwan:  
&#8211; racism (foreigner, Asian vs Western privledge for immigrants), over-emphasis for recycling, over-emphasis on education, exclusion, guiding (rules) and inability to make self-judgement, fuze (responsibility, duty?) for social and professional relations (maybe from Confucianism!), disregard for urban planning (ride and park scooters and bikes anywhere, walk anywhere, etc.), disregard for the environment in general instead focusing on something (human behavior and attention, a part of which is capitalistic behavior), ancient exercise routines, dependency on groups, lack of creativity, lack of consumption of media from other countries, over-emphasis of social media, no thought about diet (or animal ethics), no thought in general (lol), etc.  
&#8211; look at thoughts when I first came to Taiwan. Compare with my thoughts in other societies.