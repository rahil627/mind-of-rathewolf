---
id: 7746
title: Organizing People vs Organizing Material
date: 2016-06-22T00:25:03-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=7746
permalink: /?p=7746
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
