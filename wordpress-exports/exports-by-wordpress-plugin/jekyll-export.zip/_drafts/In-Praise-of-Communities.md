---
id: 3945
title: In Praise of Communities
date: 2015-01-12T05:17:06-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3945
permalink: /?p=3945
categories:
  - Uncategorized
---
After leaving the &#8216;burbs. I&#8217;ve lived in two Chinatowns in San Francisco, Clinton Hill in New York, near Tonghua night market in Taipei, and for shorter periods of times: an independent school in ZhongLi, Taiwan; a hostel in Penang, Malaysia; a hostel in Bangkok, Thailand; my parents house in Vadodara, India; a hostel in Bhaktapur, Nepal; and a hostel in Seoul, Korea.