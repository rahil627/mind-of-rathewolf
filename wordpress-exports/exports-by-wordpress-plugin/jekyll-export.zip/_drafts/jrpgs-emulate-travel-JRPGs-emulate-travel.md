---
id: 2314
title: JRPGs emulate travel
date: 2014-08-03T07:11:40-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=2314
permalink: /?p=2314
categories:
  - Uncategorized
---
In and old post, [link to post], I had a very weak argument for games [blah blah].

During my last week in Taiwan, I decided to travel the east coast, I was blown by the sublimity of Taiwan&#8217;s nature &#8212; karst mountains alongside a beach which erodes giant rocks in the most beautiful way. And as I went through different landscapes it triggered the memory that JRPGs evoked: travel.

JRPGs are terrible because the mechanics are terrible. But simply being able to walk, explore, talk to NPCs, simulates travel. You go through cities, suburbs, countryside, and the people that inhabit them.

These places and people exist. Art imitates nature.

But I don&#8217;t think ever connected that as much as I do now, after traveling so much.

So although the games suck because they are not experimental, as a medium to consume, I don&#8217;t think they are bad.

and during the time, l learned I couldn&#8217;t talk to myself forever and relied on media. I hadn&#8217;t listened to music for quite some time. I use 8tracks [link to why 8tracks is better than AI] to find some J