---
id: 6834
title: The Desire to Alter the Environment
date: 2016-06-01T01:49:57-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6834
permalink: /?p=6834
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
> In nature, or village like settlements, there is freedom because there is space, to build and accumulate. In the city, there is not. Instead, one spends more time restructuring [altering] the [existing] natural and space, instead of building. That \*\*is\*\* the creative replacement. To rethink space within an already built environment, because the city currently is the best form it can be.  
> <cite>from a paper before 5/2016, perhaps several months before</cite>