---
id: 3761
title: The City as a Community
date: 2014-12-13T15:03:45-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3761
permalink: /?p=3761
categories:
  - Uncategorized
---
> Perhaps I chose the wrong direction, or I should have moved on immediately. [shouldn’t have chosen to stop at a house]
> 
> The towns in Nepal and Darjeeling are easy to explore and social. They’re small with tons of cafes, nice surroundings, and cool weather. I also live in the city, so I go out more, build routine with local shops, do everything outside — eat, laundry, internet cafe, tea, and work. In Baroda, I do everything inside. That’s the difference. I need to live outside. Or, perhaps, In red to live with people [that I want to partake in activities with].

> Still thinking about why my time in Nepal and Darjeeling felt so great compared to Baroda. In those areas I spent my first six to eight hours outside. I talked to the hostel owners, travelers, local people, and was more open to talk to people, to meet people. I planned to go out somewhere once a day. I still wake up late, but it was okay. I spent every sunlight hour under it. Even at night in Darjeeling, I’d spend an hour or two at a bar because I wanted to be with people. It felt good. I did my work at night.
> 
> In baroda, I lost my activity, motivation to do things very early. I could go to Mt. Abu, or other surrounding areas. I could meet people. I could be outside, although, I can’t work on a laptop outside because it is too hot, and the cafes are expensive, and just not very local. I could see farms, learn to farm, do some yoga, eat at local gujarati thali places, explore the city, explore the surroundings, making one day trip per day, but I didn’t. I was too focused on work, my next direction, that I lived less, not seizing the moment. Stuck at the house doing meaningless things.

> I’ve been in the house for too many hours. I always compare to how much life I lied in Nepal and Darjeeling. I need to be outside the house for as many hours as possible. I need to live for the first hour of the day, like Vidya, take a hike to a temple. I’m not as alert as I was before. My work is at the house, and it is killing me. I need to be like Fred. Live several lives per day. I have to keep walking and talking around town. Keep consuming, meeting people, and working.