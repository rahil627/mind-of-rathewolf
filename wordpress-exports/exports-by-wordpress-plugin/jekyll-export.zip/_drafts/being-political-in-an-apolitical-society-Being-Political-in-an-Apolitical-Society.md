---
id: 6845
title: Being Political in an Apolitical Society
date: 2016-06-01T02:03:08-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=6845
permalink: /?p=6845
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
> today&#8217;s good feelings. shower, bike, summer weather, holiday, kids play. Love it. A different world from Xizhi. Eating at the church felt fine because the weather [is great] and [because] my body is fine. I think less of others.  
> <cite>written after intense writing of <a href="http://www.rahilpatel.com/blog/a-study-plan">a study plan</a> in Xizhi, whilst being homeless at Taida</cite>