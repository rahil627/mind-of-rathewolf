---
id: 3823
title: Autonomism in Taiwan
date: 2015-09-08T17:00:25-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3823
permalink: /?p=3823
categories:
  - Uncategorized
---
Night Markets as entrepreneurship:  
Towards the end of the Tang Dynasty, economic expansion led to less state regulation and restrictions being lifted on Night Markets. During the Song Dynasty (960-1279), Night Markets played a central role in Chinese nightlife. These markets were found in corners of large cities. Some stayed open for twenty- four hours. Song period Night Markets are also known to have included restaurants and brothels due to being frequently located near business districts and red light districts.

The serving of xiaochi foods attracted Taiwan&#8217;s local elite. Stories were formed of how well-known politicians and intellectuals visited Night Market stalls.

Night Markets started to embody the local and the global modern popular culture because of commercial industries. Because of the global recession in the 1970s, canceled imports created more opportunities for vendors selling light industry and family made goods. This was due to more products becoming available to local markets. Night Marketing Networks were formed and sold Taiwan&#8217;s light industry goods.

Night Markets changed from places that sold traditional snack food and handicrafts to modern centers of popular culture. Markets rapidly responded to new trends by producing their own versions of popular goods, especially in the 1990s, when copyright and intellectual property laws were only loosely enforced.