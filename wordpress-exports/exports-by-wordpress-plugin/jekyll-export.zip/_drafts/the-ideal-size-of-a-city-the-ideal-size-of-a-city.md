---
id: 4184
title: the ideal size of a city
date: 2015-08-13T16:40:27-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4184
permalink: /?p=4184
categories:
  - Urban Philosophy
---
[todo: THIS IS A DRAFT]

A part of [the ideal city](http://www.rahilpatel.com/blog/the-ideal-city).

> A Pattern Language:
> 
> This book is very close to what I outlined to do, and moreover, it is written like a treatise, with each paragraph numbered and carefully leading to the next.  
> I listened to some while scootering from Hualien to Yilan. The first paragraph mentioned a hierarchy of socio-political groups, from region to family. 2. Each group makes decisions about the land it shares in common, between neighborhoods, land between houses, living room. And thus it set out.  
> One argument I remember is the size of a city. Where there is an upper bound to management. That one should be able to easily participate in civil decision-making, and not sink into beauracracy. I wondered about my tensions of living in big cities, and my comfort in small towns. How hectic Taipei is, seemingly unmanageable. It argues for small dense cities but with access to rural areas. I agree, and hence love Taiwan&#8217;s towns and cities. There is no better feeling than being able to bike or scooter from one&#8217;s house to a rural area, as I felt in Yilan, Bhaktapur, Penang, and elsewhere.  
> Though public transport such as trains and buses are swell, the freedom of being able to quickly go from house to rural with a personal transportation is quite different.

Todo: think and write more on this.