---
id: 3873
title: The Power of Public Transportation
date: 2015-01-01T02:09:51-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3873
permalink: /?p=3873
categories:
  - Uncategorized
---
In a [past post where I try to decide which place is better, New York and Taiwan](http://www.rahilpatel.com/blog/new-york-and-taiwan "New York and Taiwan"), I wrote:

> &#8220;Taiwan feels it goes further though. I can go to other cities, towns, or farms, beautiful natural places. This is because Taiwan has a fantastic train system that goes around the country at every hour, whereas the public transportation of America is limited to the metro system and infrequent buses with no stops on the coasts.The train has a huge enabling effect. I have a friend who works on in one city and commutes to another one-quarter across the island. It was very easy for me to move to another city and work. There’s a feeling that one could work anywhere on the island, save the mountains in the middle, because of it, and people do. Many people in Taipei school or work for a short period, or even commute from other cities everyday. Low-cost trains have such a strong effect that I bet if America was linked by trains, the suburbs would have died much quicker, having people move into cities.*&#8221;

When o

Another post:  
Civic Engagement  
Urban Planning for Connectivity  
Civic Engagement in an Autonomist Society