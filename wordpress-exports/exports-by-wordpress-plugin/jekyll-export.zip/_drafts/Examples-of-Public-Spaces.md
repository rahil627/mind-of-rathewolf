---
id: 4737
title: Examples of Public Spaces
date: 2015-09-13T16:57:30-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4737
permalink: /?p=4737
categories:
  - Uncategorized
---
[itp.nyu.edu/edcamp/about-itp/](https://itp.nyu.edu/edcamp/about-itp/){.autohyperlink}  
D&T

topics  
physical computing  
&#8211; [itp.nyu.edu/physcomp/](https://itp.nyu.edu/physcomp/){.autohyperlink}  
&#8211; also contains many other topics related  
see D&T courses  
etc.