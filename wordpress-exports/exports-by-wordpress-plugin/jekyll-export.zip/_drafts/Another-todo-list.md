---
id: 4113
title: Another todo list
date: 2015-09-17T09:37:09-04:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=4113
permalink: /?p=4113
categories:
  - Uncategorized
---
時間再到了，我在感覺我得

It&#8217;s that time again where I find myself in a capitalistic society, and must participate in inhuman activities to survive. The result? Another todo list! Let&#8217;s jam.

1. 寫現在的全動機  
2. 查思想，茶做什麼成功，做那事  
3. 用努力讓工作比較社會的

current motives:  
&#8211; choose a cheap, calm place to live in the city (Richmond / Sunset of SF or Queens / Sunset Park of NY) with cheap food and access to Fablab and Hackerspace and Pan&#8217;s meeting room.  
&#8211; keep an eye out for apartments which could double as a public space  
&#8211; create a schedule of courses and discussions in these spaces, using the appropriate Google Calendar,  
&#8211; be a part of my local community &#8212; create an online post and physical sign on a local bulletin board and a physical sign outside the apartment I live in that lists my skills (babysit, work, computers, websites, marketing, etc.), my belongings (to share), my space (to share and talk), and my interests

make everything I do social or profitable:

funny neighborhood profitable ideas:  
&#8211; make and sell Indian food  
&#8211; ask buffet lady  
&#8211; can make day or night stand for special items  
&#8211; make and sell various ready to drink teas, including chai  
&#8211; game-making night market stand  
&#8211; go to the east coast (nature) and make useful items from natural or recycled materials and sell it at the market &#8212; insect repellent, body wash, shampoo, deodorant, travel gear (light and heavy travel)

self-education made social:  
&#8211; self-made book curriculum with discussions of topics  
&#8211; self-made film curriculum shown at my apartment

things to be done in spaces:  
&#8211; choose courses of choice from master&#8217;s programs I like, and create groups at the matching space, i.e. D&T studio at Fablab, play with software workshops at hackerspace?

civic ideas:  
&#8211; create several maps for Taipei  
&#8211; neighborhoods  
&#8211; write the biographies of local vendors  
&#8211; continue Humans of Taipei?  
&#8211; graffiti for urban planning causes, until I learn how to organize  
&#8211; try MIT media software to facilitate community building  
&#8211; see news for problem-solution ideas  
&#8211; fix walking / biking / scootering path problem  
&#8211; create and give no-vehicle signs to day and night market entrances

learn about Taipei&#8217;s organizations