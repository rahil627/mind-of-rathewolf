---
id: 3521
title: Life Traps
date: 2014-11-28T18:45:56-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3521
permalink: /?p=3521
categories:
  - Uncategorized
---
> ~2/14/13 to 8/6/13 in New York:  
> Remember to take a morning off to travel and think. Bring a book to read and a composition book to write ideas. Then go home and complete an idea.