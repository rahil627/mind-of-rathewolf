---
id: 5200
title: Why move?
date: 2015-12-02T08:15:03-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=5200
permalink: /?p=5200
categories:
  - Uncategorized
---
If the [Will to Take Care of Locality](http://www.rahilpatel.com/blog/will-to-take-care-of-locality) exists, then why would one ever move?