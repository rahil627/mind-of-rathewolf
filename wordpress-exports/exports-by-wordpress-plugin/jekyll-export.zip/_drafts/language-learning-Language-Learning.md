---
id: 3272
title: Language Learning
date: 2014-11-25T08:34:38-05:00
author: Rahil
layout: post
guid: http://www.rahilpatel.com/blog/?p=3272
permalink: /?p=3272
categories:
  - Uncategorized
---
[meh, can do later.]

points:  
school provides an environment make mistakes, but is not interesting as practical use, and is likely not as interesting as talking to people in real life

it&#8217;s best to just quickly go over flash cards and grammar, then try to use them in real life. One use the grammar book&#8217;s activities which repeat the vocab and existing knowledge, but what&#8217;s the point? One should do the same with new grammar, as there may be several ways to to use the new grammar, and check with someone who knows the language.

also a grammar book to quickly go through all the uses of grammar.

[lifehacker.com/5903288/i-learned-to-speak-four-languages-in-a-few-years-heres-how](http://lifehacker.com/5903288/i-learned-to-speak-four-languages-in-a-few-years-heres-how){.autohyperlink}

[www.flashcardlearner.com/articles/learning-a-language-the-10-most-effective-learning-strategies/](http://www.flashcardlearner.com/articles/learning-a-language-the-10-most-effective-learning-strategies/){.autohyperlink}