---
id: 6518
title: Early Ideal Lifestyles
date: 2010-02-18T09:30:45-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6518
permalink: /early-ideal-lifestyles/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"2b7f1a3c5dd7";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:64:"https://medium.com/@rahil627/early-ideal-lifestyles-2b7f1a3c5dd7";}'
categories:
  - Life
  - Personal
  - Thoughts
---
<blockquote>the ideal life - move to a different country every few years. this would allow me to learn a new language, culture, and way of life, for every move. the problem is income. what job would allow me to live this lifestyle? can i run businesses in foreign countries? i would have to be the owner, with a top notch manager. even then, i wouldn't be a good owner, since i'm not near my business. i'd have to settle in one country for some time (10-18 years?), when i have children.
<cite>18/2/2010</cite>
</blockquote>

Can see the nomadic instincts here already.