---
id: 2676
title: 'Medicine: An Alternative Path to the Good Life'
date: 2014-11-07T00:48:47-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2676
permalink: /medicine-an-alternative-path-to-the-good-life/
categories:
  - Thoughts
---
A thought:
<blockquote>After a brief Wikipedia browsing of ziprasodone, anti-psychotics, schizophrenia, pyschosis, and sensory deprivation, it seems science is slowly proving what a healthy life requires -- sensory stimuli, social interaction, happiness, a good life.</blockquote>

Medicine has passed the point where basic life actions such as social interaction, diet, and exercise, are being replaced by medicine. 

Surely there must be some kind of general rule that practitioners follow that states not to give medicine if natural lifestyle changes could solve the problem.

Unfortunately, I don't feel it exists.