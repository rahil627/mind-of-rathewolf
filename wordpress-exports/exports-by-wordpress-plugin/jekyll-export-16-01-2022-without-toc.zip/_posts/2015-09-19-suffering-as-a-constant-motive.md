---
id: 4816
title: Suffering as a Constant Motive
date: 2015-09-19T14:04:57-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4816
permalink: /suffering-as-a-constant-motive/
categories:
  - Personal
  - Thoughts
---
<blockquote>The terrible suffering this represents can produce political reactions that tip humankind further down the slope toward outright barbarism - Alex Callinicos, The Revolutionary Ideas of Karl Marx.</blockquote>