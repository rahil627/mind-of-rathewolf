---
id: 2849
title: Households and Inaction
date: 2014-11-08T06:08:36-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2849
permalink: /households-and-inaction/
categories:
  - Social Philosophy
  - Urban Philosophy
---
<blockquote>
10/26/13
I lost my sense of adventure, enthusiasm, excitement. I just go home and sleep now. It's fucking stupid. There's so much to do in the world, yet I do nothing.</blockquote>

The idea of going home and being at home results in less action, and more likely to passively consume. This is because only one's housemates exist in the house, and media. Only if one lived with housemates whom one wants to take action with would going home lead to more action. <a href="http://www.rahilpatel.com/blog/experience-and-action">Though with technology one can talk which may result in fruitful actions, it is less likely than physically being together</a>. This is apparent in the suburbs, but even in the city, once one has a house, one can becomes quite lazy spending time in it.

One's home should only be use for private time, to get away from the world.