---
id: 3058
title: The Public is Stimulating
date: 2014-11-23T03:19:47-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3058
permalink: /the-public-is-stimulating/
categories:
  - Social Philosophy
  - Thoughts
---
<blockquote>in Seoul:
Yesterday felt great, simply wandering the subways and streets of Seoul. Everyone was busy, except me. I just watched, talking to the non-busy ones.</blockquote>

The public is a simple pleasure, and offers infinite inspiration.