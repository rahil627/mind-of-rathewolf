---
id: 2431
title: An Installation for Cart Life
date: 2014-09-20T04:58:13-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2431
permalink: /an-installation-for-cart-life/
categories:
  - Games
  - New Media
  - New Media Design
---
Install <a href="http://www.richardhofmeier.com/cartlife/">Cart Life</a>, a video game, on a street vendor, duh!

<div style="text-align: center;">
<a href="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/cart-life-installation.svg"><img src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/cart-life-installation.svg" alt="cart life installation" class="alignnone size-large wp-image-2432" /></a>
</div>