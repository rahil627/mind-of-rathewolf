---
id: 1520
title: '愛情萬歲 (Vive L&#8217;Amour)'
date: 2014-01-12T13:36:45-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=1520
permalink: /vive-lamour/
categories:
  - Film Reviews
  - Films
---
I watched Vive L'Amour (愛情萬歲; Live Love) at a coincidental time. Just a few weeks ago, I was extremely social. I had class, friends within the locality, always eating with people, not spending more than an hour without talking to someone. Now, I'm in a large house, staying up late to take on personal endeavors, with no social life. The sudden change in social life caused bed-ridden depression instantly, but I eventually adapted to live alone, again.

In Vive L'Amour, there are only three characters. Nothing else. We just watch them, without distractions -- sound and dialog. It feels as if so much time is going by in their lives without doing anything. Sometimes I felt as if I'm not doing anything. Yet, it is enthralling to watch, think, and feel. Although, admittedly, I took breaks to handle the extremely slow pace, I never fast forwarded.

The setting is naturalistic. One character sells coffins, another illegally sells clothes, and the last is a real estate agent. The rest of the world feels bleak. The bland side of Taiwan: ugly condos and cars. It's how I feel whenever I think about the Xinyi district in Taipei.

The actions characters take are novel [to me], adding to realism. bowling a watermelon, stealing keys to an apartment and then sleeping in it. Other scenes are relatable. The younger male character (acted by Lee Kang Sheng) takes actions not uncommon during puberty: masturbating and wearing girl's clothes.

The dramatic tension caused by the characters being close, yet anonymous, is great to experience. The climax is unbreathably tense and thrilling. The final scene ends it well, with a long shot of an desolate park, then the female character quietly uncontrollably cries, finally physically displaying the real emotion beneath all of the characters: extreme loneliness.

I felt that Tsai Ming-Liang [the director] figured out what worked in Rebels of the Neon God, and stripped everything else, which wasn't much, out. The audience now focuses only on the action, often of just one character. It's rather surprising to think how great a minimal film can be, and how few resources is required to make one. It's a success.