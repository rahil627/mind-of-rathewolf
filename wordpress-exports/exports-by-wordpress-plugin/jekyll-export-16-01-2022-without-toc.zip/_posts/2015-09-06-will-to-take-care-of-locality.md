---
id: 4630
title: Will to Take Care of Locality
date: 2015-09-06T15:41:21-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4630
permalink: /will-to-take-care-of-locality/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"fdeb941d22f3";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:71:"https://medium.com/@rahil627/will-to-take-care-of-locality-fdeb941d22f3";}'
categories:
  - Human Geography
  - Philosophy
  - Thoughts
---
Related to Working Memory and Community [todo: need link], <a href="http://www.rahilpatel.com/blog/will-to-make">Will to Make</a>, <a href="http://www.rahilpatel.com/blog/will-to-experience">Will to Experience</a>.

[todo: should try to complete!]

The locality is a specific area in space undefinable boundaries. It contains materials, including the living and non-living.

A living thing begins in a locality.

The living thing makes contact with locality. It has an experience with the locality. It may continue, or it may stay.

If the living thing stays, it will take care of the locality.

It may move and stay again and again.

todo:
Hmmm, this doesn't quite work for living things that trash or destroy places that is not their place.

I think I was trying to define a kind of land ethics often belonging to indigenous peoples, or generally anyone not confined to a very small space i.e. dwelling.

Hmmm, this also seems like a good starting point for private / public locality, property, conduct, and perhaps more.***

Hmmm, my current locality seems to be this blog.

[todo:
<blockquote>14/5/2016
from paper, not very recent, perhaps from April, or even March:
Showered. Daydreamed of living in tonghua jie, peacefully, doing chores for my neighbors for gift exchange, sometimes for money (take care of elderly, take care of night market stand, take care of children). I document some of the work (farmer getting load from farm via train) to allow others to see the lives of my neighbors.

Local gigs. Walking distance. Feels at home. No alienation.
</blockquote>
]
