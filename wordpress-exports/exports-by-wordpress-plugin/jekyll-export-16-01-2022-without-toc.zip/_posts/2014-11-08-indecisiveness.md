---
id: 2787
title: Indecisiveness
date: 2014-11-08T05:08:36-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2787
permalink: /indecisiveness/
categories:
  - Action
  - Ethics
---
<blockquote>10/10/13
It's the indecision that kills me. Apartment hunting. Fucking indecision. Just keep on living!</blockquote>

When one has the will to do anything, making decisions becomes rather difficult.

<blockquote>in Korea:
Searching for something that doesn't exist</blockquote>

Along with indecisiveness is the search for the ideal. Always looking for something better, as opposed to making with what one is given.