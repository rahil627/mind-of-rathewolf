---
id: 1293
title: 'I&#8217;m a Schizoid'
date: 2013-09-05T06:51:41-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=1293
permalink: /im-a-schizoid/
categories:
  - Psychology
  - Schizoid Personality Disorder
  - Thoughts
---
[Old draft, posting anyway. Not a bad start!]

Confidence swings from a Ai Wei Wei to a suburbanite in the same day. Lack of personal image in the perspectives of others blocks the gauging of relationships. If I have work, I don't care. It's only when I stop working, when I start to think of it. Then, I pick my shit up and continue.

<blockquote>The theory of mind (ToM) impairment describes a difficulty someone would have with perspective taking. This is also sometimes referred to as mind-blindness. This means that individuals with a ToM impairment would have a hard time seeing things from any other perspective than their own. Individuals who experience a theory of mind deficit have difficulty determining the intentions of others, lack understanding of how their behavior affects others, and have a difficult time with social reciprocity. ToM deficits have been observed in people with autism spectrum disorders, people with schizophrenia, people with attention deficit disorder, persons under the influence of alcohol and narcotics, sleep-deprived persons, and persons who are experiencing severe emotional or physical pain.
<cite><em>Wikipedia</em>,<a href="http://en.wikipedia.org/wiki/Theory_of_mind#Deficits">Theory of Mind, Deficits section</a>
</blockquote>



