---
id: 3090
title: Absurdism
date: 2014-11-22T21:48:55-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3090
permalink: /absurdism/
categories:
  - Ethics
  - Philosophy
  - Thoughts
---
<blockquote>>9/3/13
It's extremely important to choose great jobs. The highest of design. Learn languages as quick as possible. Be social. Practice. Take it seriously. Learning is key for the future. Don't just think about the poor, do something about it!</blockquote>

I often experience something that evokes a strong emotional response, but don't know how to rationally react to it, and rather want to create art out of it. Is it absurdity or ignorance?

<blockquote>9/19/13 in Japan
I was at my height of senses in Hong Kong because I was transitioning from a developing county to a developed one. That is how I should think all of the time. But then, if I did, I wouldn't have friends. It's tough to live in that state of mind. One has to step down. </blockquote>

Absurdity is hit often when I go from a developed country to a developing country, and vice versa. For some reason, <a href="http://www.rahilpatel.com/blog/adaptation" title="Adaptation">my brain takes a lot longer to make sense of society</a>, the role of technology, and just what the heck people are doing.