---
id: 4634
title: Will to Make
date: 2015-09-06T15:47:08-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4634
permalink: /will-to-make/
categories:
  - Art
  - Design
  - Human Geography
  - Philosophy
  - Thoughts
---
A thought from reading the title of a book, Will to Architecture.

The thought reoccured from Place: A Short Introduction:
<blockquote>All over the world people are engaged in place-making activities.</blockquote>

Humans will to make material and digital things. To materially put together a better world; To design a better world.

This is a subset of <a href="http://www.rahilpatel.com/blog/will-to-experience">Will to Experience</a>. Making is an experience, but one does not have to make to have an experience.