---
id: 7784
title: '蛍火の杜へ (~Into the Forest of Fireflies&#8217; Light)'
date: 2016-09-07T08:08:00-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=7784
permalink: /into-the-forest-of-fireflies-light/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"d0a0502a6b38";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:12:"7a04709b0155";s:6:"status";s:6:"public";s:3:"url";s:141:"https://medium.com/@rahil627/%E8%9B%8D%E7%81%AB%E3%81%AE%E6%9D%9C%E3%81%B8-hotarubi-no-mori-e-into-the-forest-of-fireflies-light-d0a0502a6b38";}'
categories:
  - Art
  - Film Reviews
  - Films
  - Humanities
  - Life
  - Personal
---
Japanese: 蛍火の杜へ
romanization: Hotarubi no Mori e
literal: Into the Forest of Fireflies' Light
English: [none]

<h2>during-film thoughts</h2>

Suburban house, missing the in-between in life
Noisy insects!
--
...ended up just watching the entire thing as I did as when I was young.

<h2>post-film thoughts</h2>

A similar story to Spirited Away. Perhaps they root from some ancient Japanese source story.

The film is slow, dreamy, like Totoro. It has its magic. It's predictable, yet I was happy to watch it, and it made me happy, optimistic.

For the simple things. Memories. Good times. Summers. Natural joy. Picnics. Talking. Sharing. Time.

I think of all those memories I created in Taiwan, and elsewhere. A happier place. Instead of my cultural theory, I take in the youthful joy. Of the Chinese class, of her, of my trip in Asia, of New York, of the fatkids, of College Park, of my youth. So many memories. It's beautiful to think about.

I've been so focused lately that I've recently stopped thinking. This free-thinking is what makes me happy. Ignore reality, and be happy.
  - Perhaps not ignore reality, rather, stop organizational behaviors and live!