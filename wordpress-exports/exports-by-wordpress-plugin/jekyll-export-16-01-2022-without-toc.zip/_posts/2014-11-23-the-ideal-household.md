---
id: 2801
title: The Ideal Household
date: 2014-11-23T14:48:54-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2801
permalink: /the-ideal-household/
categories:
  - Social Philosophy
  - Thoughts
  - Urban Philosophy
---
<blockquote>10/13/13
Perhaps I should live alone in a shitty room in Tonghua.</blockquote>

Unlike the <a href="http://www.rahilpatel.com/blog/the-ideal-neighborhood" title="The Ideal Neighborhood">neighborhood</a>, the household doesn't matter much.

If one is single, it could be just a small space to safely keep belongings and sleep in. If the country doesn't provide cheap and healthy food, then there must be a kitchen.

If one has roommates, then perhaps it would have a living room that has an appearance similar to one's dream cafe.

If one a family, then I still think it should resemble a dream cafe, with more play space.
