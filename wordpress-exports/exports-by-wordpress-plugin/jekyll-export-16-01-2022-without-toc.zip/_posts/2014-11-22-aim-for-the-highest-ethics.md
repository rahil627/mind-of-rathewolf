---
id: 3017
title: Aim for the Highest Ethics
date: 2014-11-22T00:33:34-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3017
permalink: /aim-for-the-highest-ethics/
categories:
  - Ethics
---

<blockquote>The most important problem is not being solved. Why care about anything else?</blockquote>

Ignore everything. Aim for the highest goal.

This is not a bad idea.

This coincides with another phrase, "have a big idea, then everything else will fall in place."