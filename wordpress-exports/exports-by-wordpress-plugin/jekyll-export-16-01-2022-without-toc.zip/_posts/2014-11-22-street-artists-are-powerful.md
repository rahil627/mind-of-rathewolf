---
id: 3049
title: Street Artists are Powerful
date: 2014-11-22T01:45:38-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3049
permalink: /street-artists-are-powerful/
categories:
  - Action
  - Aesthetics
  - Philosophy
---
<blockquote>>9/3/13The only time I stop is when a street musician is playing.</blockquote>

The combination of a human, performing, in public, is powerful.

More powerful than any media. More powerful than any performance in an artificial environment.

These are humans. They are performing. There is no place in society for them to act this way, or, they don't feel they belong to such a place in society, or, they simply want to perform directly toward humans, so they do it in the public.

The most powerful effect is direct human interaction. Any distance between lessens the effect, and the chance one reacts.