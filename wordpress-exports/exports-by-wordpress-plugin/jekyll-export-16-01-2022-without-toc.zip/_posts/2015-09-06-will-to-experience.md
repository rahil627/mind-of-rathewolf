---
id: 4637
title: Will to Experience
date: 2015-09-06T15:49:47-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4637
permalink: /will-to-experience/
categories:
  - Experience
  - Philosophy
  - Thoughts
---
A bit contrasting to <a href="http://www.rahilpatel.com/blog/will-to-make">Will to Make</a>.

It's not about organizing, it's about experiencing.

Things that are considered experiences, but not making: talking, performing, physical movement.

The Will to Experience and the Will to Make might be a spectrum. The spectrum might be a major characteristic of culture.