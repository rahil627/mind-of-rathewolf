---
id: 6547
title: Early Aspirations of Nomadism
date: 2011-11-23T10:03:37-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6547
permalink: /early-aspirations-of-nomadism/
categories:
  - Ethics
  - Humanities
  - Life
  - Personal
  - Philosophy
  - Thoughts
---
[todo: combine with <a href="http://www.rahilpatel.com/blog/early-ideal-lifestyles">early ideal lifestyles</a>?]

<blockquote>Next move? SF, Hawaii, Japan, Canada (Toronto, Vancouver), New Zealand?, Asia? (3 months in each of Japan, China, Korea, Indonesia, etc.),...
<cite>21/11/2011</cite>
</blockquote>

<blockquote>I've said before, at my core I'm a vagabond. I like to explore, live, create. This can be seen as greedy as it takes away from family time. I just have to make sure I commnicate with my family and friends while I'm gone. Start using skype weekly. Go to India with my parents next time.

I would be okay with living in poverty as long as I'm doing the things I like. I'll only compromise to a desk job if I need the money or social interaction.

It's no different then when I was young. Before, I used to explore neighborhoods on my bike. I still explore neighborhoods on my bike! But now I can go further, around the world. I also now have the confidence to make things. I have a much clearer mind. I'm healthy.
<cite>23/11/2011</cite>
</blockquote>

And now, as I write this on 4/5/2016, I am in poverty, doing the things I like. Well, kind of.