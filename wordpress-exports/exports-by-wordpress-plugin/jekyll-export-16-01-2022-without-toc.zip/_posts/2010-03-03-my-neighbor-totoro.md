---
id: 6716
title: となりのトト (My Neighbor Totoro)
date: 2010-03-03T10:01:08-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6716
permalink: /my-neighbor-totoro/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"1a82eedcf967";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:60:"https://medium.com/@rahil627/my-neighbor-totoro-1a82eedcf967";}'
categories:
  - Art
  - Film Reviews
  - Films
  - Humanities
  - Life
  - Personal
  - Thoughts
---
<blockquote>it would be nice to raise a family in a rural area. the family would be close, and there would be an appreciation for nature. we could still keep computers (and media) in the house, and the kids would attend a school nearby, so it wouldn't be completely isolated from the developed world.

maybe i could work in america, but spend vacations at the farm. even college park had ditches filled with tadpoles, old bridges, and dirt trails alongside the modern world of electronics.

the offset could be less learning about the developed world. there wouldn't be nearly as much wikipedia'ing, internet browsing, political terms, or home services. although, this would lead to a more independent lifestyle, with the will to learn.

if i grew up elsewhere, i still think i would still have the same mindset, due to my genes.

living in a rural settings would change the way kids spend free time, from video games to real life activities (tag, sports, nature, helping family/neighborhood, etc.). i played a mixture of both.
<cite>3/2/2010 (dd/mm/yyy) after watching My Neighbor Totoro</cite>
</blockquote>

<blockquote>college park was the perfect place to grow up. people (and their personalities), culture, sports, crime, adventure, and infinite fun. you can learn everything you need to know in a neighborhood like that. it forces you to be raised correctly, with much less parenting.
<cite>4/3/2010</cite>
</blockquote>

<blockquote>The dream of living in the country, perhaps influenced by growing up in College Park, and later reinforced by Miyazaki films. I still dream of such a place at times, on the west coast of Taiwan, near the mountains, perhaps not too dissimilar from the hostel in Yilan; raising adopted aboriginals, playing video games, going on adventures. It was my childhood, but it seems so far from the reality of a neighborhood in Taipei. Yet, contrarily, seemingly quite easily possible. Yes. Do it!
<cite>5/4/2016</cite>
</blockquote>