---
id: 2845
title: Constant Action Ethics
date: 2014-11-08T06:06:53-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2845
permalink: /constant-action-ethics/
categories:
  - Ethics
---
Or Mania?

<blockquote>
10/10/13
I have no idea what life is anymore. You have to keep fighting for time, fighting for life, life, work, family, all of it.</blockquote>

<blockquote>
10/11/13
It is good to have priorities of social things, like learning language, Humans, and Vincent Moon. I feel it provides a more relaxed, yet productive lifestyle. I overwork myself.</blockquote>

<blockquote>You have to enjoy life at every moment. Don't worry so much. Keep living. I can feel the worry of money seeping in</blockquote>

<blockquote>>6/28/13
The trick to traveling is to keep moving. Don't choose or research, just go. The trick to living is to travel everyday for a short period of time. No, travel all the time. Everyday is an adventurer.</blockquote>

<blockquote>>9/3/13You have to stay outside. Never inside. Keep wandering. Keep talking to people. Keep working outside. There's nothing inside a building.</blockquote>


<blockquote>thoughts from Japan before 9/24/13:
There's no end to life. No settling. An infinite roller coaster.</blockquote>



<blockquote>
10/25/13
I'd rather live a life of adventure rather than planning.</blockquote>



<blockquote>10/26/13
After a night out with that girl I met at the concert:
...
She did have one point: I don't know how to relax, which is something Kate said.

...

The morning sets the pace. That initial push to go out, and stay out, exploring, socializing. It's the houses and libraries that make me complacent and unsocial. You have to keep moving and talking. Don't stop. Only study during breaks in life.</blockquote>

<blockquote>~2/14/13 to 8/6/13 in New York
I need to constantly explore. Physically and mentally.
...
Don't think far in the future. Just think what to do now, and do that, then there will be a less chance of work going to waste.
...
Just do it. Make shit all day non stop.
</blockquote>

They may seem to be an irrational ethic, but the body's action doesn't really matter, it is separate from the mind. The change in external stimuli seem to be key.