---
id: 2971
title: Asceticism Ethics
date: 2014-11-15T08:26:43-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2971
permalink: /asceticism-ethics/
categories:
  - Ethics
---
<blockquote>
9//20/14
This article for Design for this Century doesn’t excite me at all. It’s about internet advertising. Should this be knowledge I should know? Why? I’d rather live a simple life.

Perhaps I could use the knowledge and awareness from Design for this Century to create art to make people aware of those things.</blockquote>

Ignore the material world, live simply, and do good. Surely nothing <em>wrong</em> with these ethics. Great if charity is included.

Until someone bad influences them. Or a disease is introduced. Maybe limit entering a high-tech society when something weird happens for help?

Burma must have been an other worldly sight.