---
id: 3754
title: Epicureanism and Location
date: 2014-12-08T16:56:18-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3754
permalink: /epicureanism-and-location/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"721b75ac0f56";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";s:67:"https://medium.com/@rahil627/epicureanism-and-location-721b75ac0f56";}'
categories:
  - Ethics
  - Human Geography
  - Philosophy
  - Philosophy of Education
---
[todo: just publishing old drafts]

Often, people have the ethics to try to gain a knowledge whilst being happy. The methods one uses to gain knowledge depends on location. If one is restricted to the confines of a single house, then the knowledge must exist in the house. First people are used, then media is used. If there are no confines, then knowledge can be gained directly from experience.

[I think I was trying to get at the restrictions of organized knowledge based on location...]