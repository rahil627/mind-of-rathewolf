---
id: 2319
title: Traditional Music Games
date: 2014-09-18T05:24:20-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2319
permalink: /traditional-music-games/
categories:
  - Game Design
  - New Media
  - New Media Design
---
Connect Taiko No Tatsujin to tablas using Makey Makey at a Gurudwara.

<div style="text-align: center;">
<img class="alignnone size-large wp-image-2324" src="http://www.rahilpatel.com/blog/wp-content/uploads/2014/09/traditional-games1.svg" alt="traditional games" />
</div>

Thoughts:
Foreigners will have to go to a Gurudwara, take off their shoes, perhaps pray, then play. Perhaps kids who play it will be inspired to learn to play traditional instruments.

Further design:
Perhaps can think of other traditional instrument, game, and place of worship combinations.




notes:
Drawing digitally is a waste of time. I thought it would convey designs better, but perhaps paper is better if I can find a good workflow.