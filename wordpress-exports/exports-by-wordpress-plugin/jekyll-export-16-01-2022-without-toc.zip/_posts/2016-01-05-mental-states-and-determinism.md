---
id: 6056
title: Mental States and Determinism
date: 2016-01-05T10:40:03-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6056
permalink: /mental-states-and-determinism/
categories:
  - Uncategorized
---
A thought from a conversation with someone.

She argues that it isn't about the place, weather, or anything material, perhaps an exception of people. She believes it's entirely about the mind, psychology, having a good mental state.