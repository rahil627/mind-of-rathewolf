---
id: 3097
title: Houses and Streets
date: 2014-11-22T22:03:35-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3097
permalink: /houses-and-streets/
categories:
  - Action
  - Ethics
  - Humanities
  - Philosophy
  - Social Philosophy
  - Urban Philosophy
---
<blockquote>>9/3/13
My creativity is completely gone. I'm paying for an expensive hostel without thought of work. I'm working on old things without thought. I need some inspiration.</blockquote>

Impulsivity dissipates the longer I stay inside a house. This included my parent's house, my family's house in India, and, a friendly hostel in Seoul.

It's surprising I lost impulsivity in the hostel in Seoul. But like Japan, South Korea is nearly entirely developed, with people inside buildings. Even the parks are artificial.

The more time I spend on the street, the more impulsive I am. Travel being the best. This harks Rimbaud's biography and Dean Mortiarty as extreme examples.

<blockquote>>9/3/13Cars are terrible. It's like a house on wheels.</blockquote>

When one is inside a car, one doesn't interact with the world, only with what's inside the car. The difference of a opening a window is huge.