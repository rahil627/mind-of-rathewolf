---
id: 3244
title: Homeless East Asians
date: 2014-11-25T06:58:11-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3244
permalink: /homeless-asians/
categories:
  - Essays
  - Literature
  - Social Philosophy
  - Thoughts
  - Urban Philosophy
---
<blockquote>
~2/14/13 to 8/6/13 in New York
Why do bums live on?</blockquote>

Homeless East Asians are special. Testaments of the crime-less, thrifty ethics of East Asians; Modest modern scavengers of urban waste a la recyclables, they fertilize the city's sidewalks every night, take care of the city like under-appreciated mothers do their shit-spewing babies.

I've always had a fascination with bums since I first moved to a city. A fascination for the human condition perhaps. They are incredible beings.

The Asian kind, especially. I feel no difference between the Asian recycling ladies of New York and certain night market vendors of Taipei whom clean the streets every night. Perhaps they are the same. I walk down the streets with them, comforted by their presence, inspired.

Wherever I settle, I hope they are always near.