---
id: 2831
title: Maximum Time Ethics
date: 2014-11-08T05:59:47-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2831
permalink: /maximum-time-ethics/
categories:
  - Ethics
---
Related to my thoughts on <a href=" http://www.rahilpatel.com/blog/time-perception ">time perception</a>, is life maximized by maximizing time?

In cities, people experience more social interactions.

I wonder how nomadic peoples feel about their perception of time. I imagine they'd go crazy if you stuffed them in a cubicles.