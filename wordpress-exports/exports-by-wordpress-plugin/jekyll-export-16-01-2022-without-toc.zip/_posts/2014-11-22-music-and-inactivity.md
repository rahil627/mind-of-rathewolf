---
id: 3047
title: Music and Inactivity
date: 2014-11-22T01:43:40-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3047
permalink: /music-and-inactivity/
categories:
  - Action
  - Philosophy
---
<blockquote>>9/3/13Music is what kept me working. I'm unsure if its good or bad. I was happy working in both San Francisco and New York despite a very unsocial life, but I could have done so much more with people.</blockquote>

During high school, college, and my first two jobs, I used music as an aid to do work.

This is wrong. One should constantly think (talking to oneself inside one's head) and/or consume, to stimulate brain, and increase chance for reaction.

It's quite easy to simultaneously work and think of something completely different. For my last gig, I was programming while listening to lectures, paying no attention to my work.

I am unsure whether I should consider myself during those years as a human or slave. Music could be a powerful tool for slave-masters.