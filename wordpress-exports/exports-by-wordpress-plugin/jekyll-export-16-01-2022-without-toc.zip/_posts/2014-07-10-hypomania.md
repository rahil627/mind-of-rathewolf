---
id: 2119
title: Hypomania
date: 2014-07-10T08:27:17-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2119
permalink: /hypomania/
categories:
  - Personal
  - Schizoid Personality Disorder
  - Thoughts
  - Travel
---
[Did not read this, but it seems I wrote it during my travels. TODO: need to read and expand. Also see, <a href="http://www.rahilpatel.com/blog/korea-and-the-apex-of-spd" title="Korea and The Apex of SPD">SPD in Korea</a>]

During much of my time in Asia (Taipei, Taiwan, Bangkok, Kuala Lumpur, Penang, India, and Taipei again) I experienced high anxiety, loss of reality, and unimaginable happiness.

At first, I figured it was simply the effect of weather [link to effects of weather] on dopamine. Clearly high temperature and sunlight affected me. After reading a few articles of Wikipedia, I re-diagnosed this time as mania.

I experienced all of the effects of Mania: extroverted characteristics, pressured speech, racing thoughts, unable to work for long periods of time without external stimuli, ADHD; problems with physiology: sleeping less, more active lifestyle.

During travel in Asia, I'd wake up, rush to figure out what to do, then somewhat execute it, making up trip along the way. Every hour of travel was a new experience, something to consume, extending time [link to time]. I was at awe and wonder throughout, meeting people, exploring, deeply thinking about the things around me (how things have come to be, anthropology, etc.), and thinking about ways for me to produce something from my interactions. 

I didn't talk to people. I extract the information I wanted from them. Or, explored together. I was a monster and information from external sources was my food.

All I had to do was spend time moving around outside, seeing the public for a few hours during the heat and sunlight to satisfy my body. I'd often return to a hostel late at night socialize.

Perhaps in countries I could not interact with locals, I substituted with observing.