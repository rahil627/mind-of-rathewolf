---
id: 1891
title: 'Pokemon Snap: People are Now Pokemon'
date: 2014-04-19T13:13:10-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=1891
permalink: /pokemon-snap-people-are-now-pokemon/
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";s:74:"https://cdn-images-1.medium.com/fit/c/200/200/1*dmbNkD5D-u45r44go_cf0g.png";s:10:"author_url";s:28:"https://medium.com/@rahil627";s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";s:12:"afb3ff3f044e";s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:8:"unlisted";s:3:"url";s:77:"https://medium.com/@rahil627/pokemon-snap-people-are-now-pokemon-afb3ff3f044e";}'
categories:
  - Art
  - Game Ideas
  - Games
  - Humanities
  - New Media
---
People use their phone cameras to find pokemon and take pictures of them.

implementation:
Choose pokemon based on facial features or body shape or both.
After the pokemon is identified, begin tracking the movement of it
When the human body turns, the pokemon also turns
Track certain parts of human to mirror skeletal movement of pokemon (arms, legs, body turn, head turning)

later possibilities:
upload pictures to a database (in-app and website) where people can rate them for certain characteristics, awarding them with badges
