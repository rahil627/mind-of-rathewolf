---
id: 4842
title: Social Impact and Location
date: 2015-09-22T04:40:06-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4842
permalink: /social-impact-and-location/
categories:
  - Ethics
  - Human Geography
  - Humanities
  - Social Philosophy
---
This is the desire to constantly make a social impact wherever one is.

It usually coincides with <a href="http://www.rahilpatel.com/blog/epicureanism-and-location">Epicureanism and Location</a>.