---
id: 3544
title: Creative Programming
date: 2013-06-28T20:41:54-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3544
permalink: /creative-programming/
categories:
  - Design
  - New Media
  - New Media Design
  - Thoughts
---
<blockquote>
Creative programming is the ability to implement any design imagined.
<cite>~2/14/13 to 8/6/13: San Francisco: the second time</cite>
</blockquote>
It's kind of a powerful feeling.