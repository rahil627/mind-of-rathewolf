---
id: 761
title: Extra Things
date: 2012-04-25T04:43:09-04:00
author: rahil627
layout: page
guid: http://www.rahilpatel.com/blog/?page_id=761
inline_featured_image:
  - "0"
---
These things could help make finding things more easy.

<h2>Things that I often change or keep up to date, or should</h2>
<a href="http://www.rahilpatel.com/blog/a-curriculum-of-experience">A Curriculum of Experience</a>
  - <a href="http://www.rahilpatel.com/blog/a-liberal-arts-self-study-curriculum">A Liberal Arts Self Study Curriculum</a>
<a href="http://www.rahilpatel.com/blog/a-self-assessment">A Self-Assessment</a>
<a href="http://www.rahilpatel.com/blog/a-self-assessment-ii">A Self-Assessment II</a>

[widgets_on_pages id=1]