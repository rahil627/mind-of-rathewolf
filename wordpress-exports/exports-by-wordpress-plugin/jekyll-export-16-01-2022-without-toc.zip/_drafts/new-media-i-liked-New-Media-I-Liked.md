---
id: 2909
title: New Media I Liked
date: 2014-11-10T02:09:30-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=2909
permalink: /?p=2909
categories:
  - New Media
  - New Media Design
---
[meh, can do later. Should fill up as going through thoughts.]

a thought from Japan:
<blockquote>At NTT ICC: Audio tapes slowly unwinds slowly above a beautiful pillar, when the unwinding ends, it winds and plays, revealing the audio track, and the fact that sound was playing the entire time. A very Braid feel.
</blockquote>

I found <a href="http://www.ntticc.or.jp/Archive/2013/Openspace2013/Works/Toki_Ori_Ori_Nasu_ver_2.html">it</a> on the internet!

<a href="https://www.youtube.com/watch?v=RVoY1KXn1L0">Banksy's meat truck</a>.

<blockquote>
~2/14/13 to 8/6/13 in San Francisco
Quayola, strata #4</blockquote>


