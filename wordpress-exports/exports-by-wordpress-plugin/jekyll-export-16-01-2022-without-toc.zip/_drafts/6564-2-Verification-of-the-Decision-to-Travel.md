---
id: 6564
title: Verification of the Decision to Travel
date: 2016-04-26T23:43:11-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6564
permalink: /?p=6564
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
11/7/2012(?)
An email to an awesome group of people:

Heyo.
I've got a really funky question that can't be answered by nearly any family or friends at home (I don't have a cool artsy Mom, but she does make yummy food!).
But first, a quick update:
I left NY to go to SF. In SF I tried to seek out a similar game scene and failed to find anything near the level of NY. It's only when you leave Babycastles (and NY in general) you realize how world class the people [and their works] really are. And how business-oriented SF is. I generally just attended events I was interested in (not just game related) and explored parts of the city, as usual. Most of the time, I've been working on a game with a friend in NY (Jon Stokes!). I recently left SF to come home and am currently experiencing some funky mini-depression via reverse culture shock after living away for ~2 years. Home is too comfortable. Anyway, that's not the point!

NOW:
I've been thinking about traveling abroad for some time, but I'm now questioning the reasoning behind it, although there isn't much rational to begin with. The idea is to live in a few places either in Asia or Europe, stop in India (where my parents own a home and travel to often), and continue around the world. At the end of it, I imagine crawling back to NY. I'll eventually have to get yet another full-time job to pay my debt to my Dad. Hurray upper-class Indian families in the hospitality business! Also, hurray high-paying programming full-time jobs which bought me time [at the expense of soul shards] to do things that I want. I guess this assumes all of my projects commercially fail. It's likely.

I'm not the kind of person to travel "into the wild"; I need to work. I think I would be able to work on my own projects. When I'm excited, I'm productive. The problem is that I doubt I would be able to do anything meaningful with other people, as I have a meaningless background, I don't speak the language, and it's likely illegal. I imagine it's basically be me trying to make stuff while exploring. Not much else.

THE QUESTIONs: Is simply having the feeling to live in certain countries enough of a reason to do so? And would the experience be worth it? Or is this all non-sense?

[To me,] the more rational decision would be to come back to NY, the place that inspired me, and be as active as possible in everything, like you guys. Then again, I'd work for the Man again to take this trip.

Hrmm, I guess this is more of a reality-check.

LOL. Sorry to throw this on you two, after failing to complete trollkit and everything else. In hindsight, I think I was in an overly excited state of mind. Babycastles is too exciting! At the time I failed to find a cool job and decided not take up another day job and somehow felt making games [and film] was more valuable of my time, my first creative endeavor ever. Oh so crazy.

Thanks for your time,
I really do idolize Babycastles

replies:
Kunal:

Hey Rahil - my phone broke so my half answer is bust.
It's a bummer, because I'm not sure when I'll have time again!
But I'm going to emphatically say:
If for whatever reason, you can afford to travel in any way, even uncomfortably, under-the-table jobs (more possible in some countries than others and that's very real), you should do it.   I worked in India as a shitty journalist for half a year, I cleaned bathtubs in Japan for a very long time, in Ireland I just did freelance programming gigs I acquired in the US from abroad, etc. I just wasted money in Providence, Rhode Island right after college too, that I had earned in a high-paying job I immediately quit.  Being somewhere is just a really good, good idea.  Being stationary is just ignorance, and attachment to insular principles and conversation that need shaking up.  I think that's just a straightforward truth. Go for it!

Syed:
If you have the privilege to travel then you should totally do it. My parents are both kinda of old and sick and don't have health insurance so i've had to stay close to the tri-state area most of my life. Apart from familial finical obligations whatever money I had left would go to rent and food. The only time i've travelled overseas was to visit my mom's family on my mom's birthday in the UK, that's also after i had a high paying job that i had just quit, but since then the only time i get to go anywhere is if people are paying for my accommodations.
If you're in a place where your parents can help you out a little and you can take care of the rest then you should totally do it.
Also I have this idea for this TV show that I want to pitch to IGN. It's like "Anthony Bourdain's No Reservations" but with game culture (independent or otherwise) around the world. The host will be Dan Alongi. If you'd like to help us write a treatment for and pitch it to our contact at IGN then maybe that might facilitate your need to get out of this country. An we'll all go on this great adventure.

a very objective perspective of vagabonding

&nbsp; - http://studenomics.com/application/how-to-travel-the-world/