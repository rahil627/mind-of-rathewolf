---
id: 6032
title: Anarchy and Taiwan
date: 2016-01-22T00:56:55-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6032
permalink: /?p=6032
categories:
  - Uncategorized
---
[1/4 todo: A thought from a conversation with someone:

I think this post was intended to be about how Taiwanese people tend to be more anarchic: desire freedom, pure creativity, appearing to have a simple life but in reality having a very complex one (in their thoughts)

...perhaps restricted to take action by the social system (social norms) and economic system (capitalism) and the lack of money]




possible resources:
https://www.ciaonet.org/attachments/27104/uploads
http://homepage.ntu.edu.tw/~msho/book.files/J40.pdf

experiences from non-natives:
http://mariodian.com/post/104659383891/anarchy-in-taiwan