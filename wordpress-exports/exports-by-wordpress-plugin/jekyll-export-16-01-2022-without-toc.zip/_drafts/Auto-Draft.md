---
id: 8229
title: Auto Draft
date: 2022-01-13T14:02:02-05:00
author: rahil627
layout: post
guid: http://rahilpatel.com/blog/?p=8229
permalink: /?p=8229
inline_featured_image:
  - "0"
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";N;s:2:"id";N;s:21:"follower_notification";N;s:7:"license";N;s:14:"publication_id";N;s:6:"status";N;s:3:"url";N;}'
---
