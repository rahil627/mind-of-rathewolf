---
id: 6097
title: Being Political and Not
date: 2016-01-06T17:10:38-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6097
permalink: /?p=6097
categories:
  - Uncategorized
---
[todo: Thought of because I am currently in a less political mode, merely consuming, as opposed to having a strong desire to alter the world (people, material, society). Perhaps this is because I am isolated from the city, reliant on media, able to choose whom I communicate with. If I am political now, it would be through media, which is probably not very effective.

Otherwise, I'm normally very politically inclined, wanted to create a positive impact wherever I am. Take action. Talk to local social organizers. When I am physically separated from the area in which I would like to take action, I may talk it out with critical theorists, documentaries, etc.
...

To be a part of society, must one be political?

Well, as long as one lives within reach of another human, the communication (oral, media) will very likely affect the life of the other. Whether it is intentionally political or not is difficult to distinguish.]

