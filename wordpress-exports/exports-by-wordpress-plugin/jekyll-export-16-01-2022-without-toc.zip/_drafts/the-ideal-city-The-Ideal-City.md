---
id: 4179
title: The Ideal City
date: 2015-07-16T16:08:48-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4179
permalink: /?p=4179
categories:
  - Uncategorized
---
[todo: THIS IS A DRAFT]
thoughts:
<a href="http://www.rahilpatel.com/blog/the-ideal-size-of-a-city">ideal size of city</a>
<a href="http://www.rahilpatel.com/blog/large-and-small-communities">Is Nature Necessary?</a>
<a href="http://www.rahilpatel.com/blog/large-and-small-communities">Large and Small Communities</a>
The Power of Public Transportation
<a href="http://www.rahilpatel.com/blog/epicureanism-in-the-suburbs">Epicureanism in the Suburbs</a>

components:<a href="http://www.rahilpatel.com/blog/the-ideal-size-of-a-city">
ideal public space
</a>

Also mention the human want to build a communal place for all.

The want to design a place for all. (Taiwan, developing countries, survival values).