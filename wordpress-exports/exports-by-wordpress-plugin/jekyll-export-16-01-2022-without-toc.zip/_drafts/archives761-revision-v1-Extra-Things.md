---
id: 8222
title: Extra Things
date: 2022-01-02T07:42:30-05:00
author: rahil627
layout: revision
guid: http://rahilpatel.com/blog/761-revision-v1/
permalink: /761-revision-v1/
---
These things could help make finding things more easy.

<h2>Things that I often change or keep up to date, or should</h2>
<a href="http://www.rahilpatel.com/blog/a-curriculum-of-experience">A Curriculum of Experience</a>
  - <a href="http://www.rahilpatel.com/blog/a-liberal-arts-self-study-curriculum">A Liberal Arts Self Study Curriculum</a>
<a href="http://www.rahilpatel.com/blog/a-self-assessment">A Self-Assessment</a>
<a href="http://www.rahilpatel.com/blog/a-self-assessment-ii">A Self-Assessment II</a>

[widgets_on_pages id=1]