---
id: 6847
title: On Homelessness
date: 2016-06-01T01:51:46-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6847
permalink: /?p=6847
medium_post:
  - 'O:11:"Medium_Post":11:{s:16:"author_image_url";N;s:10:"author_url";N;s:11:"byline_name";N;s:12:"byline_email";N;s:10:"cross_link";s:2:"no";s:2:"id";N;s:21:"follower_notification";s:3:"yes";s:7:"license";s:19:"all-rights-reserved";s:14:"publication_id";s:2:"-1";s:6:"status";s:6:"public";s:3:"url";N;}'
categories:
  - Uncategorized
---
<blockquote>need shower
<cite>written after showering after a few days and feeling great</cite>
</blockquote>


<blockquote>need material for flooring</blockquote>
With it, everywhere becomes sleepable. As a person who sleeps in the baby-position, and often only sleeps well in that position, I need to sleep on the floor, therefore, I need material to sleep on, so that my sides are comfortable.


<blockquote>Sleeping at night absolutely useless. Only the hours from 7-12pm felt good. At the not so cold air conditioned OK Mart and outside in the park. That park and NTU sports being the best places to sleep.</blockquote>