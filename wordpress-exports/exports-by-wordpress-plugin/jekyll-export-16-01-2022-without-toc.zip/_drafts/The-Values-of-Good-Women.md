---
id: 6062
title: The Values of Good Women
date: 2016-01-06T14:57:07-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=6062
permalink: /?p=6062
categories:
  - Uncategorized
---
[todo: this post was thought after thinking about a good girl I recently had good conversations with, which reminded me of all the other great-valued women I've met in my life, and perhaps imparted in me some values, or at least, served as an ideally good person. I then thought about writing to the girls that affected me much, especially to the girls that affected me but do not know.]

people:
find the text file which includes influential people / models:

motherly:
Mom
Dollyben
Shila

sisterly:
Sheetal

female friends:
Sarah* [summer classmate, VA]
Kate[*] [ODU classmate, VA]
Molly & Andrea [roommates, SF]
Jen[*] & Lauren & Ida[*] [BC, NY]
Rice [JV's Hostel, Taipei, Taiwan]
Mandy* [DaDa School, Zhongli, Taiwan]
?* [kArts, Seoul, Korea]
Kim[*] [The Warehouse, Kuala Lumpur, Malaysia]
couple [Kimchee hostel, Seoul, Korea]
Vee [hostel, Chiang Mai, Thailand]
Sheila and Harshita [hostel, Darjeeling, India]
Rice (again) & Ann [JV's Hostel and apartment, Taipei, Taiwan]
Kumiko* & Minyoung[*] [CCU Chinese class, Taipei, Taiwan]
Emily [roomate in Songshan apartment, Taipei, Taiwan]
Pig* [Yilan, Taiwan]

* denotes an attraction possibly existed beyond good friendship
[*] denotes an attraction that I did not pursue
others are likely familial (sisterly, motherly)

older:
Qing (and John)
Kate
couple [hostel, Mae Sot]
Vanessa
? & ? [CCU Chinese class teacher and older Korean classmate]
--

I should write to each of them, and what values they imparted in me.
--

There was also a thought about my asexual life, and writing a bit about that.
--
--

In comparison, I think, there are fewer males that have imparted such values. Often, the males that have imparted some value in me are the partners of the females. I begin contact with the women and later become friends with the male, and also share a kind of homogamy (John).

Perhaps it is because my male friends have imparted values that are more instrumental. They are friends of shared interests rather than shared values.
--
to read:
https://en.wikipedia.org/wiki/Love *
https://en.wikipedia.org/wiki/Platonic_love
https://en.wikipedia.org/wiki/Romance_(love)
https://en.wikipedia.org/wiki/Lovestruck
https://en.wikipedia.org/wiki/Philia
https://en.wikipedia.org/wiki/Storge
https://en.wikipedia.org/wiki/Homogamy_(sociology)
https://en.wikipedia.org/wiki/Eros_(concept)
https://en.wikipedia.org/wiki/Attachment_theory


] (end of todo)