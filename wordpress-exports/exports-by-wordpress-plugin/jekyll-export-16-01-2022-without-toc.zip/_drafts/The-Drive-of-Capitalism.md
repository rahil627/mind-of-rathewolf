---
id: 4559
title: The Drive of Capitalism
date: 2015-09-03T16:21:41-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4559
permalink: /?p=4559
categories:
  - Uncategorized
---
How it established deadlines for me. How I created many ideas with a little profit in mind (joining a company to make money, service jobs to fit my wants in education at that specific time, self-service work),