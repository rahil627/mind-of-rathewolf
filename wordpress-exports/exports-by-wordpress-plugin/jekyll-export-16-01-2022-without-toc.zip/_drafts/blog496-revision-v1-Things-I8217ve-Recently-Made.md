---
id: 8220
title: 'Things I&#8217;ve Recently Made'
date: 2022-01-02T07:40:28-05:00
author: rahil627
layout: revision
guid: http://rahilpatel.com/blog/496-revision-v1/
permalink: /496-revision-v1/
---
