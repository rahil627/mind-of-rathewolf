---
id: 4737
title: Examples of Public Spaces
date: 2015-09-13T16:57:30-04:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=4737
permalink: /?p=4737
categories:
  - Uncategorized
---
https://itp.nyu.edu/edcamp/about-itp/
D&T

topics
physical computing
  - https://itp.nyu.edu/physcomp/
    - also contains many other topics related
see D&T courses
etc.