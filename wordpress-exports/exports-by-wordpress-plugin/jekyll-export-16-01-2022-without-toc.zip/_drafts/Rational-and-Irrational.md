---
id: 3533
title: Rational and Irrational
date: 2014-11-28T19:10:18-05:00
author: rahil627
layout: post
guid: http://www.rahilpatel.com/blog/?p=3533
permalink: /?p=3533
categories:
  - Uncategorized
---
Sensory deprivation and over-stimulation.

Consuming media as opposed to living life.