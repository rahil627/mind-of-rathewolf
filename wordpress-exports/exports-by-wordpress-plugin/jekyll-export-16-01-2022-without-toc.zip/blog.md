---
id: 496
title: Recent Things
date: 2012-02-07T02:32:59-05:00
author: rahil627
layout: page
guid: http://www.rahilpatel.com/blog/?page_id=496
inline_featured_image:
  - "0"
---
